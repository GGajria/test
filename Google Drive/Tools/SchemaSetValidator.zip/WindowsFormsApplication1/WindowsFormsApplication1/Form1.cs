﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;
using System.Configuration;
using Redbox.OpenServices.Contracts;
using System.ServiceModel.Description;
using System.Xml.Serialization;
using System.IO;
using ServiceCallerHelper;
using System.Diagnostics;
using System.Xml;
using System.Net;

namespace ServiceCaller
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        

        



        

       


        
        //validate against XSD
        private void Validate_Click_1(object sender, EventArgs e)
        {



            Dictionary<string, string> schemas = new Dictionary<string, string>();
            try
            {
                XmlDocument xDoc = new XmlDocument();
                xDoc.Load(XmlPath.Text);

                if (xDoc.FirstChild.NodeType == XmlNodeType.XmlDeclaration)
                    xDoc.RemoveChild(xDoc.FirstChild);


                var csvs = XslPath.Text;
                var xsds = csvs.Remove(csvs.Length - 1).Split(',');
                
                foreach (var xsd in xsds)
                {
                    if (!schemas.ContainsKey(xsd))
                        schemas.Add(xsd, xsd);
                }
                Helper.validate(xDoc.OuterXml, schemas);
                if (Helper.err.ErrorsCount > 0)
                {
                    textBox1.Text = Helper.err.ErrorMessage;
                    
                }
                else
                {
                    textBox1.Text = "Validated Successfully";
                }
            }
            catch (Exception ex)
            {
                textBox1.Text = "Error: " + ex.ToString();
            }
            finally
            {
                XmlPath.Text = String.Empty;
                XslPath.Text = String.Empty;
                schemas = new Dictionary<string, string>();
                Helper.err.ErrorMessage = String.Empty;
                Helper.err.ErrorsCount = 0;
            }
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

            XmlPath.Text = openFileDialog1.FileName;
        }

        private void Browse1_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "XML Files | *.xml";
            openFileDialog1.ShowDialog();
        }

        private void Browse2_Click(object sender, EventArgs e)
        {
            openFileDialog2.Multiselect = true;
            openFileDialog2.Filter = "XSD Files | *.xsd";
            openFileDialog2.ShowDialog();
        }

        private void openFileDialog2_FileOk(object sender, CancelEventArgs e)
        {
            string[] str = openFileDialog2.FileNames;
            foreach (var file in str)
            {
                XslPath.Text += file + ",";//file.Substring(file.LastIndexOf("\\")+1) + " ";
            }


        }

        //service call
        private void callService_button_Click(object sender, EventArgs e)
        {
            var url = textBox3.Text;
            var body = textBox2.Text;
            var method = comboBox1.Text;
            var contentType = textBox4.Text;
            string response;
            Helper.createWebRequest(url, method, body, contentType, out response);
            
 
            
            textBox1.Text = response;

        }

        private void XPath_Evaluate_Button_Click(object sender, EventArgs e)
        {
            var xmlStr = textBox1.Text;
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(xmlStr);
            
            var nodes = xmlDoc.SelectNodes(XPathEntry_textBox.Text);
            StringBuilder sb = new StringBuilder(); 
            for (int i = 0; i < nodes.Count; i++)
            {
                sb.Append(nodes.Item(i).OuterXml);
            }
            MessageBox.Show(sb.ToString());
        }


    }
}

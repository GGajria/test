﻿namespace ServiceCaller
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.XmlPath = new System.Windows.Forms.TextBox();
            this.XslPath = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Validate = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.Browse1 = new System.Windows.Forms.Button();
            this.Browse2 = new System.Windows.Forms.Button();
            this.openFileDialog2 = new System.Windows.Forms.OpenFileDialog();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.callService_button = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.XPathEntry_textBox = new System.Windows.Forms.TextBox();
            this.XPath_Evaluate_Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(334, 46);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(393, 451);
            this.textBox1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 153);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Request Body";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(334, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Output";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 18;
            this.label3.Text = "Service";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(9, 169);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox2.Size = new System.Drawing.Size(302, 83);
            this.textBox2.TabIndex = 6;
            // 
            // XmlPath
            // 
            this.XmlPath.Location = new System.Drawing.Point(110, 391);
            this.XmlPath.Name = "XmlPath";
            this.XmlPath.Size = new System.Drawing.Size(84, 20);
            this.XmlPath.TabIndex = 21;
            // 
            // XslPath
            // 
            this.XslPath.Location = new System.Drawing.Point(110, 420);
            this.XslPath.Name = "XslPath";
            this.XslPath.Size = new System.Drawing.Size(84, 20);
            this.XslPath.TabIndex = 22;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 401);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 13);
            this.label5.TabIndex = 23;
            this.label5.Text = "XML Path";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 427);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 13);
            this.label6.TabIndex = 24;
            this.label6.Text = "XSD Path(CSV)";
            // 
            // Validate
            // 
            this.Validate.Location = new System.Drawing.Point(110, 460);
            this.Validate.Name = "Validate";
            this.Validate.Size = new System.Drawing.Size(188, 23);
            this.Validate.TabIndex = 25;
            this.Validate.Text = "Validate";
            this.Validate.UseVisualStyleBackColor = true;
            this.Validate.Click += new System.EventHandler(this.Validate_Click_1);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // Browse1
            // 
            this.Browse1.Location = new System.Drawing.Point(219, 391);
            this.Browse1.Name = "Browse1";
            this.Browse1.Size = new System.Drawing.Size(75, 23);
            this.Browse1.TabIndex = 26;
            this.Browse1.Text = "Browse";
            this.Browse1.UseVisualStyleBackColor = true;
            this.Browse1.Click += new System.EventHandler(this.Browse1_Click);
            // 
            // Browse2
            // 
            this.Browse2.Location = new System.Drawing.Point(219, 420);
            this.Browse2.Name = "Browse2";
            this.Browse2.Size = new System.Drawing.Size(75, 23);
            this.Browse2.TabIndex = 27;
            this.Browse2.Text = "Browse";
            this.Browse2.UseVisualStyleBackColor = true;
            this.Browse2.Click += new System.EventHandler(this.Browse2_Click);
            // 
            // openFileDialog2
            // 
            this.openFileDialog2.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog2_FileOk);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(12, 46);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(302, 20);
            this.textBox3.TabIndex = 28;
            this.textBox3.Text = "Enter you URL here";
            // 
            // callService_button
            // 
            this.callService_button.Location = new System.Drawing.Point(9, 127);
            this.callService_button.Name = "callService_button";
            this.callService_button.Size = new System.Drawing.Size(75, 23);
            this.callService_button.TabIndex = 29;
            this.callService_button.Text = "Call";
            this.callService_button.UseVisualStyleBackColor = true;
            this.callService_button.Click += new System.EventHandler(this.callService_button_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 371);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 13);
            this.label4.TabIndex = 30;
            this.label4.Text = "XSD Validation";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "GET",
            "POST",
            "PUT",
            "DELETE",
            "HEAD"});
            this.comboBox1.Location = new System.Drawing.Point(126, 101);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(118, 21);
            this.comboBox1.TabIndex = 31;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(12, 101);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(108, 20);
            this.textBox4.TabIndex = 32;
            this.textBox4.Text = "text/xml";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 85);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 13);
            this.label7.TabIndex = 33;
            this.label7.Text = "Content-Type";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 286);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 13);
            this.label8.TabIndex = 34;
            this.label8.Text = "XPath";
            // 
            // XPathEntry_textBox
            // 
            this.XPathEntry_textBox.Location = new System.Drawing.Point(9, 314);
            this.XPathEntry_textBox.Name = "XPathEntry_textBox";
            this.XPathEntry_textBox.Size = new System.Drawing.Size(305, 20);
            this.XPathEntry_textBox.TabIndex = 35;
            // 
            // XPath_Evaluate_Button
            // 
            this.XPath_Evaluate_Button.Location = new System.Drawing.Point(15, 341);
            this.XPath_Evaluate_Button.Name = "XPath_Evaluate_Button";
            this.XPath_Evaluate_Button.Size = new System.Drawing.Size(75, 23);
            this.XPath_Evaluate_Button.TabIndex = 36;
            this.XPath_Evaluate_Button.Text = "Evaluate";
            this.XPath_Evaluate_Button.UseVisualStyleBackColor = true;
            this.XPath_Evaluate_Button.Click += new System.EventHandler(this.XPath_Evaluate_Button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(768, 509);
            this.Controls.Add(this.XPath_Evaluate_Button);
            this.Controls.Add(this.XPathEntry_textBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.callService_button);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.Browse2);
            this.Controls.Add(this.Browse1);
            this.Controls.Add(this.Validate);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.XslPath);
            this.Controls.Add(this.XmlPath);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "OpenAPI Service";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox XmlPath;
        private System.Windows.Forms.TextBox XslPath;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Validate;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button Browse1;
        private System.Windows.Forms.Button Browse2;
        private System.Windows.Forms.OpenFileDialog openFileDialog2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button callService_button;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox XPathEntry_textBox;
        private System.Windows.Forms.Button XPath_Evaluate_Button;
    }
}


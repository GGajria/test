﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ServiceCaller
{
    public class dummy
    {
        public List<ID> obj;
    }

    public class ID
    {
        public string id;
        public string name;
        public string type;
    }
}

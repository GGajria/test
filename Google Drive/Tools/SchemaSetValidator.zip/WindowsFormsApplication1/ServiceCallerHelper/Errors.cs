﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ServiceCallerHelper
{
    public class Errors
    {
        public string ErrorMessage { get; set; }
        public int ErrorsCount { get; set; }

    }
}

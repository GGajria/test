﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Packaging;
using System.IO;

namespace Zipper
{
    class Program
    {
        //zip file path
        static string path = @"E:\temp\test.zip";

        //directory to compress
        static string srcDirectory = @"E:\temp\test";

        static void Main(string[] args)
        {
            DirectoryInfo di = new DirectoryInfo(srcDirectory);
            compressDirectory(di,true, "");
        }

        private static void compressDirectory(DirectoryInfo directory,Boolean copyDeep, string prefix)
        {

            //if sub directories
            if (copyDeep && directory.GetDirectories().Count() > 0)
            {
                foreach (var d in directory.GetDirectories())
                {
                    if (String.IsNullOrWhiteSpace(prefix))
                    {
                        compressDirectory(d, true, directory.Name);
                    }
                    else
                    {
                        compressDirectory(d, true,  prefix + "/" + directory.Name);
                    }
                }
            }

            //if files
            foreach (FileInfo f in directory.GetFiles())
            {
                if (String.IsNullOrWhiteSpace(prefix))
                {
                    zipFile(path, f, directory.Name);
                }
                else
                {
                    zipFile(path, f, prefix + "/" + directory.Name);
                }
            }

        }

        /// <summary>
        /// Adds the file to the supplied zip 
        /// </summary>
        /// <param name="zipPath">Absolute path to the zip file</param>
        /// <param name="file">File to add</param>
        /// <param name="prefix">Prefix in the archive</param>
        private static void zipFile(string zipPath, FileInfo file, string prefix)
        {
            using (Package zip = Package.Open(zipPath, System.IO.FileMode.OpenOrCreate))
            {
                Uri u;
                if (String.IsNullOrWhiteSpace(prefix))
                {
                    u = new Uri("/" + file.Name.Replace(' ', '_'), UriKind.Relative);
                }
                else
                {
                    u = new Uri("/" + prefix + "/" + file.Name.Replace(' ', '_'), UriKind.Relative);
                }

                if (zip.PartExists(u))
                {
                    zip.DeletePart(u);
                }

                PackagePart p = zip.CreatePart(u, "", CompressionOption.Normal);
                using (FileStream fs = file.OpenRead())
                {
                    CopyStream(fs, p.GetStream());
                }
            }
        }

        /// <summary>
        /// Copies source stream to the destination stream
        /// </summary>
        /// <param name="source">Source stream to copy from</param>
        /// <param name="target">Destination stream to copy to</param>
        private static void CopyStream(Stream source, Stream target)
        {
            const int bufSize = 0x1000;
            byte[] buf = new byte[bufSize];
            int bytesRead = 0;
            while ((bytesRead = source.Read(buf, 0, bufSize)) > 0)
                target.Write(buf, 0, bytesRead);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.IO;
using System.ServiceModel.Activation;

namespace WcfService1
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class FakeAPIGeeServiceClass : FakeAPIGeeService
    {
        public Boolean Test(Stream XML)
        {
            var data = new StreamReader(XML).ReadToEnd();
            return true;
        }

        public Boolean Alive()
        {
            return true;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.IO;

namespace WcfService1
{
    [ServiceContract]
    public interface FakeAPIGeeService
    {

        [OperationContract]
        [WebInvoke(BodyStyle=WebMessageBodyStyle.Bare,
            Method="POST",
            ResponseFormat=WebMessageFormat.Xml,
            UriTemplate="/")]
        Boolean Test(Stream XML);

        [OperationContract]
        [WebInvoke(BodyStyle = WebMessageBodyStyle.Bare,
            Method = "GET",
            ResponseFormat = WebMessageFormat.Xml,
            UriTemplate = "/")]
        Boolean Alive();
    }
}

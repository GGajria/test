﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;
using System.Configuration;
using Redbox.OpenServices.Contracts;
using System.ServiceModel.Description;
using System.Xml.Serialization;
using System.IO;
using ServiceCallerHelper;
using System.Diagnostics;
using System.Xml;
using System.Net;

namespace ServiceCaller
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)//movies
        {
            try
            {
                //start timer
                var myBinding = new WebHttpBinding();
                myBinding.SendTimeout = TimeSpan.MaxValue;
                myBinding.MaxReceivedMessageSize = int.MaxValue;
                textBox1.Text = string.Empty;
                XmlSerializer a = new XmlSerializer(typeof(Products));
                StringWriter b = new StringWriter(new StringBuilder());
                //Change the endpoint address to point to the service URL
                var URL = "http://localhost:55383/Products";
                var myEndpoint =
                    new EndpointAddress(URL);
                var myChannelFactory =
                    new ChannelFactory<IProductService>(
                        myBinding, myEndpoint);
                myChannelFactory.Endpoint.Behaviors.Add(new WebHttpBehavior());
                // Create a channel.
                var wcfClient1 = myChannelFactory.CreateChannel();
                var movies = wcfClient1.GetMovies();
                ((IClientChannel)wcfClient1).Close();
                a.Serialize(b, movies);
                textBox1.Text = b.ToString();
                return;
            }
            catch (Exception ex)
            {
                textBox1.Text = ex.ToString();
                return;
            }
        }

        private void button2_Click(object sender, EventArgs e)//stores
        {
            try
            {
                //start timer
                XmlSerializer a = new XmlSerializer(typeof(Stores));
                StringWriter b = new StringWriter(new StringBuilder());
                textBox1.Text = string.Empty;
                var myBinding = new WebHttpBinding();
                myBinding.SendTimeout = TimeSpan.MaxValue;
                myBinding.MaxReceivedMessageSize = int.MaxValue;
                var URL = "http://localhost:55383/Stores";
                var myEndpoint =
                    new EndpointAddress(URL);
                var myChannelFactory =
                    new ChannelFactory<IStoreService>(
                        myBinding, myEndpoint);
                myChannelFactory.Endpoint.Behaviors.Add(new WebHttpBehavior());
                // Create a channel.
                var wcfClient1 = myChannelFactory.CreateChannel();
                var stores = wcfClient1.GetStores();
                ((IClientChannel)wcfClient1).Close();
                a.Serialize(b, stores);
                textBox1.Text = b.ToString();


                return;
            }
            catch (Exception ex)
            {
                textBox1.Text = ex.ToString();
                return;
            }
        }

        private void button3_Click(object sender, EventArgs e)//Top20
        {
            //try
            //{
            //    //start timer
            //    var myBinding = new WebHttpBinding();
            //    myBinding.SendTimeout = TimeSpan.MaxValue;
            //    myBinding.MaxReceivedMessageSize = int.MaxValue;
            //    textBox1.Text = string.Empty;
            //    XmlSerializer a = new XmlSerializer(typeof(Top20));
            //    StringWriter b = new StringWriter(new StringBuilder());

            //    var URL = "http://localhost:55383/Top20/";
            //    var myEndpoint =
            //        new EndpointAddress(URL);
            //    var myChannelFactory =
            //        new ChannelFactory<ITop20Service>(
            //            myBinding, myEndpoint);
            //    myChannelFactory.Endpoint.Behaviors.Add(new WebHttpBehavior());
            //    // Create a channel.
            //    var wcfClient1 = myChannelFactory.CreateChannel();
            //    var Top20 = wcfClient1.GetTop20(int.Parse(comboBox1.SelectedItem.ToString()));
            //    ((IClientChannel)wcfClient1).Close();
            //    a.Serialize(b, Top20);
            //    textBox1.Text = b.ToString();

            //    return;
            //}
            //catch (Exception ex)
            //{
            //    textBox1.Text = ex.ToString();
            //    return;
            //}
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    //start timer
            //    var myBinding = new WebHttpBinding();
            //    myBinding.SendTimeout = TimeSpan.MaxValue;
            //    myBinding.MaxReceivedMessageSize = int.MaxValue;
            //    textBox1.Text = string.Empty;
            //    XmlSerializer resSer = new XmlSerializer(typeof(Products));
            //    XmlSerializer reqSer = new XmlSerializer(typeof(MovieBrowseRequest));
            //    StringWriter resWriter = new StringWriter(new StringBuilder());
            //    StringWriter reqWriter = new StringWriter(new StringBuilder());
            //    //Change the endpoint address to point to the service URL
            //    var URL = "http://localhost:55383/Products";
            //    var myEndpoint =
            //        new EndpointAddress(URL);
            //    var myChannelFactory =
            //        new ChannelFactory<IProductService>(
            //            myBinding, myEndpoint);
            //    myChannelFactory.Endpoint.Behaviors.Add(new WebHttpBehavior());
            //    // Create a channel.
            //    var wcfClient1 = myChannelFactory.CreateChannel();
            //    //FileStream fs = new FileStream(@"D:\test.txt", FileMode.Open);
            //    List<string> str = new List<string>();
            //    str.Add("57c5cf15-80fc-43f6-affc-0b9a60f9d290");
            //    str.Add("1627aea5-8e0a-4371-9022-9b504344e724");
            //    str.Add("57f55702-dffd-4697-b8ba-76776a25d741");
            //    str.Add("10b6a27c-1a8d-4a9c-9e38-7e81b4712315");


            //    var mbr = new MovieBrowseRequest { ProductId = str };
            //    var movies = wcfClient1.GetMoviesFull(mbr);
            //    ((IClientChannel)wcfClient1).Close();
            //    resSer.Serialize(resWriter, movies);
            //    reqSer.Serialize(reqWriter, mbr);
            //    textBox2.Text = reqWriter.ToString();
            //    textBox1.Text = resWriter.ToString();
            //    return;
            //}
            //catch (Exception ex)
            //{
            //    textBox1.Text = ex.ToString();
            //    return;
            //}
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    //start timer
            //    var myBinding = new WebHttpBinding();
            //    myBinding.SendTimeout = TimeSpan.MaxValue;
            //    myBinding.MaxReceivedMessageSize = int.MaxValue;
            //    textBox1.Text = string.Empty;
            //    XmlSerializer resSer = new XmlSerializer(typeof(Products));
            //    StringWriter resWriter = new StringWriter(new StringBuilder());
            //    //Change the endpoint address to point to the service URL
            //    var URL = "http://localhost:55383/Products";
            //    var myEndpoint =
            //        new EndpointAddress(URL);
            //    var myChannelFactory =
            //        new ChannelFactory<IProductService>(
            //            myBinding, myEndpoint);
            //    myChannelFactory.Endpoint.Behaviors.Add(new WebHttpBehavior());
            //    // Create a channel.
            //    var wcfClient1 = myChannelFactory.CreateChannel();
            //    var movies = wcfClient1.GetMoviesAll();
            //    ((IClientChannel)wcfClient1).Close();
            //    resSer.Serialize(resWriter, movies);
            //    textBox1.Text = resWriter.ToString();
            //    return;
            //}
            //catch (Exception ex)
            //{
            //    textBox1.Text = ex.ToString();
            //    return;
            //}
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    //start timer
            //    var myBinding = new WebHttpBinding();
            //    myBinding.SendTimeout = TimeSpan.MaxValue;
            //    myBinding.MaxReceivedMessageSize = int.MaxValue;
            //    textBox1.Text = string.Empty;
            //    XmlSerializer resSer = new XmlSerializer(typeof(Products));
            //    StringWriter resWriter = new StringWriter(new StringBuilder());
            //    //Change the endpoint address to point to the service URL
            //    var URL = "http://localhost:55383/Products";
            //    var myEndpoint =
            //        new EndpointAddress(URL);
            //    var myChannelFactory =
            //        new ChannelFactory<IProductService>(
            //            myBinding, myEndpoint);
            //    myChannelFactory.Endpoint.Behaviors.Add(new WebHttpBehavior());
            //    // Create a channel.
            //    var wcfClient1 = myChannelFactory.CreateChannel();
            //    var movies = wcfClient1.GetMovie("57f55702-dffd-4697-b8ba-76776a25d741");
            //    ((IClientChannel)wcfClient1).Close();
            //    resSer.Serialize(resWriter, movies);
            //    textBox1.Text = resWriter.ToString();
            //    return;
            //}
            //catch (Exception ex)
            //{
            //    textBox1.Text = ex.ToString();
            //    return;
            //}
        }

        private void button7_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    //start timer
            //    var myBinding = new WebHttpBinding();
            //    myBinding.SendTimeout = TimeSpan.MaxValue;
            //    myBinding.MaxReceivedMessageSize = int.MaxValue;
            //    textBox1.Text = string.Empty;
            //    XmlSerializer a = new XmlSerializer(typeof(Top20));
            //    StringWriter b = new StringWriter(new StringBuilder());

            //    var URL = "http://localhost:55383/Top20/";
            //    var myEndpoint =
            //        new EndpointAddress(URL);
            //    var myChannelFactory =
            //        new ChannelFactory<ITop20Service>(
            //            myBinding, myEndpoint);
            //    myChannelFactory.Endpoint.Behaviors.Add(new WebHttpBehavior());
            //    // Create a channel.
            //    var wcfClient1 = myChannelFactory.CreateChannel();
            //    wcfClient1.TestCounters();
            //    ((IClientChannel)wcfClient1).Close();

            //    return;
            //}
            //catch (Exception ex)
            //{
            //    textBox1.Text = ex.ToString();
            //    return;
            //}
        }

        private void button8_Click(object sender, EventArgs e)
        {
            try
            {
                //start timer
                var myBinding = new WebHttpBinding();
                myBinding.SendTimeout = TimeSpan.MaxValue;
                myBinding.MaxReceivedMessageSize = int.MaxValue;
                textBox1.Text = string.Empty;
                XmlSerializer resSer = new XmlSerializer(typeof(PricedCartResponse));
                //XmlSerializer reqSer = new XmlSerializer(typeof(CartIn));
                StringWriter resWriter = new StringWriter(new StringBuilder());
                //StringWriter reqWriter = new StringWriter(new StringBuilder());
                //Change the endpoint address to point to the service URL
                var URL = ConfigurationManager.AppSettings["ReservationURL"];
                var myEndpoint =
                    new EndpointAddress(URL);
                var myChannelFactory =
                    new ChannelFactory<IReservationService>(
                        myBinding, myEndpoint);
                myChannelFactory.Endpoint.Behaviors.Add(new WebHttpBehavior());
                // Create a channel.
                var wcfClient1 = myChannelFactory.CreateChannel();
                //FileStream fs = new FileStream(@"D:\test.txt", FileMode.Open);
                //var inCart = new CartIn()
                //{
                //    CardCVV = "547",
                //    CardId = "908",
                //    DiscountsApplied = new List<DiscountsApplied>(){
                //      {new DiscountsApplied(){ 
                //        DiscountType = DiscountType.WebCredit, NumDiscountsApplied = 23}
                //      },
                //      {
                //      new DiscountsApplied(){
                //        DiscountType= DiscountType.PromoCode, NumDiscountsApplied = 34}
                //      }
                //    },
                //    ProductRef = new List<string>() { { "123" },
                //                                      { "345" },
                //                                      { "289" },
                //                                      { "127" },
                //                                      { "234" },},
                //    StoreRef = "234",
                //    UserId = "test@gmail.com"
                //};

                var stringInput = @"<Cart xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns=""http://api.redbox.com/Reservations/v2"">
  <UserId>2089408</UserId>
  <StoreRef>1511</StoreRef>
  <CardId>8216705</CardId>
    <CardCVV></CardCVV>
    <NameOnCard>Girish</NameOnCard>
    <CardNo4>4260</CardNo4>
    <ExpirationMonth>05</ExpirationMonth>
    <ExpirationYear>24</ExpirationYear>
    <PostalCode>60602</PostalCode>
    <CardType>MasterCard</CardType>
    <UserNameEmail>girish.bharat@saggezza.com</UserNameEmail>
<ProductRef>2804</ProductRef>
  <DiscountsApplied>
    <DiscountApplication>
      <DiscountType>WebCredit</DiscountType>
      <NumDiscountsApplied>23</NumDiscountsApplied>
      <NumDiscountsAvailable>0</NumDiscountsAvailable>
    </DiscountApplication>
    <DiscountApplication>
      <DiscountType>PromoCode</DiscountType>
      <NumDiscountsApplied>34</NumDiscountsApplied>
      <NumDiscountsAvailable>0</NumDiscountsAvailable>
    </DiscountApplication>
  </DiscountsApplied>
</Cart>";

                //                <ProductRef>461</ProductRef>

                //<ProductRef>1463</ProductRef> 


                //reqSer.Serialize(reqWriter, inCart);
                textBox2.Text = stringInput;

                //var movies = wcfClient1.ExecuteReservationPricingPipeline(stringInput);
                //((IClientChannel)wcfClient1).Close();
                //resSer.Serialize(resWriter, movies);
                //textBox1.Text = resWriter.ToString();
                return;
            }
            catch (Exception ex)
            {
                textBox1.Text = ex.ToString();
                return;
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            try
            {
                //start timer
                var myBinding = new WebHttpBinding();
                myBinding.SendTimeout = TimeSpan.MaxValue;
                myBinding.MaxReceivedMessageSize = int.MaxValue;
                textBox1.Text = string.Empty;
                XmlSerializer resSer = new XmlSerializer(typeof(ReservationResponse));
                //XmlSerializer reqSer = new XmlSerializer(typeof(PricedCart));
                StringWriter resWriter = new StringWriter(new StringBuilder());
                //StringWriter reqWriter = new StringWriter(new StringBuilder());
                //Change the endpoint address to point to the service URL
                var URL = ConfigurationManager.AppSettings["ReservationURL"];
                var myEndpoint =
                    new EndpointAddress(URL);
                var myChannelFactory =
                    new ChannelFactory<IReservationService>(
                        myBinding, myEndpoint);
                myChannelFactory.Endpoint.Behaviors.Add(new WebHttpBehavior());
                // Create a channel.
                var wcfClient1 = myChannelFactory.CreateChannel();
                //FileStream fs = new FileStream(@"D:\test.txt", FileMode.Open);
                //var inCart = new PricedCart()
                //{
                //    CardCVV = "234",
                //    CardId = "234",
                //    CartItem = new List<CartItems>(){
                //           {new CartItems(){ Discount=22, DiscountedPrice=23, ExtraPrice=23, Format="DVD", ImageUrl="", ItemStatus="Valid", Name="", Price=34, ProductRef="234", ProductType="Movie", Rating=Rating.G }},
                //           {new CartItems(){ Discount=34, DiscountedPrice=34, ExtraPrice=23, Format="BluRay", ImageUrl="", ItemStatus="Valid", Name="", Price=34, ProductRef="245", ProductType="Movie", Rating=Rating.G }}
                //    },
                //    DiscountedSubTotal = 23,
                //    GrandTotal = 45,
                //    Online = true,
                //    StoreRef = "234",
                //    SubTotal = 345,
                //    Tax = 23,
                //    UserId = "23"
                //};

                //5341311827224260
                var inString = @"<?xml version=""1.0"" encoding=""utf-8""?>
<PricedCart xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns=""http://api.redbox.com/Reservations/v2"">
 <UserId>2084435</UserId>    
<StoreRef>1511</StoreRef>
    <Online>true</Online>
    <CardId>8216705</CardId>
    <CardCVV></CardCVV>
    <NameOnCard>Girish</NameOnCard>
    <CardNo4>4260</CardNo4>
    <ExpirationMonth>05</ExpirationMonth>
    <ExpirationYear>24</ExpirationYear>
    <PostalCode>60602</PostalCode>
    <CardType>MasterCard</CardType>
    <UserNameEmail>girish.bharat@saggezza.com</UserNameEmail>
    <CartItems>
      <CartItem ProductRef=""1463"" ProductType=""Movie"" Price=""1"" ImageUrl=""http://api.redbox.com/Reservations/1.jpg"" Discount=""0"" DiscountedPrice=""1"" ExtraPrice=""0"" Format=""0"" ItemStatus=""Valid"" Rating=""G"" />
    </CartItems>
    <SubTotal>1</SubTotal>
    <DiscountedSubTotal>1</DiscountedSubTotal>
    <GrandTotal>1.08</GrandTotal>
    <Tax>0.08</Tax>
    <DiscountsApplied />
</PricedCart>";
                //2804
                //5483694164960465
                //<CartItem ProductRef=""1463"" ProductType=""Movie"" Price=""1"" ImageUrl="""" Discount=""0"" DiscountedPrice=""1"" ExtraPrice=""0"" Format=""0"" ItemStatus=""Valid"" Rating=""G"" />
                //          <CartItem ProductRef=""461"" ProductType=""Movie"" Price=""1"" ImageUrl="""" Discount=""0"" DiscountedPrice=""1"" ExtraPrice=""0"" Format=""0"" ItemStatus=""Valid"" Rating=""G"" />
                //


                //reqSer.Serialize(reqWriter, inCart);
                textBox2.Text = inString;

                //var movies = wcfClient1.CheckOut(inString);
                //((IClientChannel)wcfClient1).Close();
                //resSer.Serialize(resWriter, movies);
                //textBox1.Text = resWriter.ToString();
                return;
            }
            catch (Exception ex)
            {
                textBox1.Text = ex.ToString();
                return;
            }
        }

        //Inventory Service
        private void button10_Click(object sender, EventArgs e)
        {
            try
            {
                var wcfClient = Helper.createChannel<IInventoryService>(typeof(Inventory),
                                              ConfigurationManager.AppSettings["InventoryURL"]
                                              );
                Timer a = new Timer();
                a.Start();
                var movies = wcfClient.GetInventory();
                a.Stop();
                ((IClientChannel)wcfClient).Close();
                textBox1.Text = a.Interval + "ms \r\n" + Helper.serialize<Inventory>(movies);
                return;
            }
            catch (Exception ex)
            {
                textBox1.Text = ex.ToString();
                return;
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox3.Items.Clear();
            switch (comboBox2.Text)
            {
                case "Product Service":
                    comboBox3.Items.Add("FullRefresh");
                    comboBox3.Items.Add("GetMovies");
                    break;
                case "Stores Service":
                    comboBox3.Items.Add("FullRefresh");
                    comboBox3.Items.Add("GetStores");
                    break;
                case "Top20 Service":
                    comboBox3.Items.Add("FullRefresh");
                    comboBox3.Items.Add("Top20");
                    break;
                case "Inventory Service":
                    comboBox3.Items.Add("FullRefresh");
                    comboBox3.Items.Add("GetInventory");
                    comboBox3.Items.Add("GetInventoryChanged");
                    break;
                case "Reservation Service":
                    comboBox3.Items.Add("ExecutePricingPipeline");
                    comboBox3.Items.Add("CheckOut");
                    comboBox3.Items.Add("ILTest");
                    //comboBox3.Items.Add("ListTest");
                    //comboBox3.Items.Add("DictTest");
                    //comboBox3.Items.Add("HashTest");

                    break;
                default:
                    break;
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";

            Top20Form a = new Top20Form();
            switch (comboBox2.Text)
            {

                case "Product Service":
                    #region Product Service
                    var PSchannel = Helper.createChannel<IProductService>(typeof(void),
                                ConfigurationManager.AppSettings["ProductURL"]);
                    switch (comboBox3.Text)
                    {
                        case "FullRefresh":
                            PSchannel.FullRefresh();
                            break;
                        case "GetMovies":
                            var products = PSchannel.GetMovies();
                            textBox1.Text = Helper.serialize<Products>(products);
                            break;
                        default:
                            break;
                    }
                    #endregion
                    break;


                case "Stores Service":
                    #region Stores Service
                    var Schannel = Helper.createChannel<IStoreService>(typeof(void),
                                ConfigurationManager.AppSettings["StoresURL"]);
                    switch (comboBox3.Text)
                    {
                        case "FullRefresh":
                            Schannel.FullRefresh();
                            break;
                        case "GetStores":
                            var stores = Schannel.GetStores();
                            textBox1.Text = Helper.serialize<Stores>(stores);
                            break;
                        default:
                            break;
                    }
                    #endregion
                    break;


                case "Top20 Service":
                    #region Top20 Service
                    var Tchannel = Helper.createChannel<ITop20Service>(typeof(void),
                                ConfigurationManager.AppSettings["Top20URL"]);
                    switch (comboBox3.Text)
                    {
                        case "FullRefresh":
                            Tchannel.FullRefresh();
                            break;
                        case "Top20":
                            var val = getTop20period();
                            var top20 = Tchannel.GetTop20(val);
                            textBox1.Text = Helper.serialize<Top20>(top20);
                            break;
                        default:
                            break;
                    }
                    #endregion
                    break;


                case "Inventory Service":
                    #region Inventory Service
                    var Ichannel = Helper.createChannel<IInventoryService>(typeof(void),
                                ConfigurationManager.AppSettings["InventoryURL"]);
                    Inventory inv = null;
                    switch (comboBox3.Text)
                    {
                        case "FullRefresh":
                            Ichannel.FullRefresh();
                            break;
                        case "GetInventory":
                            try
                            {
                                inv = Ichannel.GetInventory();
                            }

                            catch (Exception ef)
                            {
                                EventLog.WriteEntry("Inventory Test Client", "Error in getting inventory result: " + ef.ToString());
                            }

                            //textBox1.Text = Helper.serialize<Inventory>(inv);
                            XmlDocument xmlDoc = new XmlDocument();
                            try
                            {
                                //xmlDoc = new XmlDocument();
                                //xmlDoc.LoadXml(Helper.serialize<Inventory>(inv));
                                //xmlDoc.Save("inv.xml");
                                Helper.serialize<Inventory>(inv);
                            }
                            catch (Exception ef)
                            {
                                EventLog.WriteEntry("Inventory Test Client", "Error in serializing inv result: " + ef.ToString());
                                EventLog.WriteEntry("Inventory Test Client", "Error in serializing inv StackTrace: " + ef.StackTrace);
                                EventLog.WriteEntry("Inventory Test Client", "Error in serializing inv Message: " + ef.Message);
                                EventLog.WriteEntry("Inventory Test Client", "Error in serializing inv Data: " + ef.Data);
                                EventLog.WriteEntry("Inventory Test Client", "Error in serializing inv InnerException: " + ef.InnerException);
                                EventLog.WriteEntry("Inventory Test Client", "Error in serializing inv Source: " + ef.Source);
                            }
                            EventLog.WriteEntry("Inventory Test Client", "Success");
                            break;
                        //case "GetInventoryChanged":
                        //    var getObject = getInventoryChangedInputs();
                        //    var invChanged = Ichannel.GetInventoryChanged(getObject.productID,
                        //        getObject.storeId,
                        //        int.Parse(getObject.reservableCount),
                        //        int.Parse(getObject.inCirculationCount),
                        //        getObject.datetime,
                        //        getObject.delFlag);
                        //    textBox1.Text = Helper.serialize<InventoryChangesMessage>(invChanged);
                        //    break;
                        default:
                            break;
                    }
                    #endregion
                    break;

                case "Reservation Service":
                    #region Reservation Service
                    var Rchannel = Helper.createChannel<IReservationService>(typeof(void),
                                            ConfigurationManager.AppSettings["ReservationURL"]);
                    switch (comboBox3.Text)
                    {
                        case "ExecutePricingPipeline":
                            {
                                //var pricingXML = getReservationInput(1);
                                //var resp = Rchannel.ExecuteReservationPricingPipeline(pricingXML);
                                //textBox1.Text = Helper.serialize<PricedCartResponse>(resp);
                                break;
                            }

                        case "CheckOut":
                            {
                                //var checkoutXML = getReservationInput(2);
                                //var resp = Rchannel.CheckOut(checkoutXML);
                                //textBox1.Text = Helper.serialize<ReservationResponse>(resp);
                                break;
                            }
                        case "ILTest":
                            {
                                var list2 = Stopwatch.StartNew();
                                testList(2);
                                list2.Stop();

                                var list1002 = Stopwatch.StartNew();
                                testList(1002);
                                list1002.Stop();

                                textBox1.Text = string.Format("List1 took {0} ms and list2 took {1} ms", list2.ElapsedTicks, list1002.ElapsedTicks);
                                break;


                            }
                        case "ListTest":
                            {
                                List<Helper.test> testlist = new List<Helper.test>();
                                var teststr = new List<string>();

                                //for (int i = 0; i < 10; i++)
                                //{
                                //    testlist.Add(new Helper.test() { it = i, its = i.ToString() });
                                //    teststr.Add(i.ToString());
                                //}
                                var testhash = new HashSet<Helper.test>(testlist);

                                testlist.Capacity = 2;

                                testlist.Add(new Helper.test() { it = 1, its = "1" });
                                testlist.Add(new Helper.test() { it = 2, its = "2" });
                                testlist.Add(new Helper.test() { it = 3, its = "3" });
                                testlist.Add(new Helper.test() { it = 4, its = "4" });
                                testlist.Add(new Helper.test() { it = 5, its = "5" });

                                teststr.Add("1");
                                teststr.Add("3");
                                teststr.Add("4");
                                teststr.Add("5");

                                var abclist = new List<Helper.testmerge>();


                                for (var i = 6; i < 10000; i++)
                                {
                                    testlist.Add(new Helper.test() { it = i, its = i.ToString() });
                                }
                                Stopwatch timer = new Stopwatch();
                                timer.Start();
                                foreach (var item in testlist)
                                {

                                    var newItem = new Helper.testmerge()
                                    {
                                        test = item
                                    };
                                    if (teststr.Contains(item.it.ToString()))
                                    {
                                        newItem.test1 = item.it.ToString();
                                    }
                                    abclist.Add(newItem);
                                }
                                if (testlist.Contains(new Helper.test() { it = 9999, its = "9999" }))
                                {
                                    var atest = 1;
                                }
                                DateTime end = DateTime.Now;
                                timer.Stop();

                                textBox1.Text = timer.ElapsedTicks.ToString();
                                break;


                            }
                        case "DictTest":
                            {
                                var testlist = new List<Helper.test>();
                                var teststr = new List<string>();

                                //for (int i = 0; i < 10; i++)
                                //{
                                //    testlist.Add(new Helper.test() { it = i, its = i.ToString() });
                                //    teststr.Add(i.ToString());
                                //}

                                testlist.Add(new Helper.test() { it = 1, its = "1" });
                                testlist.Add(new Helper.test() { it = 2, its = "2" });
                                testlist.Add(new Helper.test() { it = 3, its = "3" });
                                testlist.Add(new Helper.test() { it = 4, its = "4" });

                                teststr.Add("1");
                                teststr.Add("3");
                                teststr.Add("4");
                                teststr.Add("5");

                                var abclist = new List<Helper.testmerge>();

                                Dictionary<int, Helper.test> dict = new Dictionary<int, Helper.test>();
                                dict.Add(1, new Helper.test() { it = 1, its = "1" });
                                dict.Add(2, new Helper.test() { it = 2, its = "2" });
                                dict.Add(3, new Helper.test() { it = 3, its = "3" });
                                dict.Add(4, new Helper.test() { it = 4, its = "4" });
                                dict.Add(5, new Helper.test() { it = 5, its = "5" });
                                for (var i = 6; i < 10000; i++)
                                {
                                    dict.Add(i, new Helper.test() { it = i, its = i.ToString() });
                                }
                                Stopwatch timer = new Stopwatch();
                                timer.Start();
                                foreach (var item in dict)
                                {

                                    var newItem = new Helper.testmerge()
                                    {
                                        test = item.Value
                                    };
                                    if (teststr.Contains(item.Key.ToString()))
                                    {
                                        newItem.test1 = item.Key.ToString();
                                    }
                                    abclist.Add(newItem);
                                }
                                if (dict.ContainsKey(9999))
                                {
                                    var atest = 1;
                                }
                                DateTime end = DateTime.Now;
                                timer.Stop();

                                textBox1.Text = timer.ElapsedTicks.ToString();
                                break;


                            }
                        case "HashTest":
                            {
                                var testlist = new List<Helper.test>();
                                var teststr = new List<string>();

                                testlist.Add(new Helper.test() { it = 1, its = "1" });
                                testlist.Add(new Helper.test() { it = 2, its = "2" });
                                testlist.Add(new Helper.test() { it = 3, its = "3" });
                                testlist.Add(new Helper.test() { it = 4, its = "4" });

                                teststr.Add("1");
                                teststr.Add("3");
                                teststr.Add("4");
                                teststr.Add("5");

                                var abclist = new List<Helper.testmerge>();


                                var hash = new HashSet<Helper.test>();
                                hash.Add(new Helper.test() { it = 1, its = "1" });
                                hash.Add(new Helper.test() { it = 2, its = "2" });
                                hash.Add(new Helper.test() { it = 3, its = "3" });
                                hash.Add(new Helper.test() { it = 4, its = "4" });
                                hash.Add(new Helper.test() { it = 5, its = "5" });
                                for (var i = 6; i < 10000; i++)
                                {
                                    hash.Add(new Helper.test() { it = i, its = i.ToString() });
                                }
                                Stopwatch timer = new Stopwatch();
                                timer.Start();
                                foreach (var item in hash)
                                {

                                    var newItem = new Helper.testmerge()
                                    {
                                        test = item
                                    };
                                    if (teststr.Contains(item.it.ToString()))
                                    {
                                        newItem.test1 = item.it.ToString();
                                    }
                                    abclist.Add(newItem);
                                }
                                if (hash.Contains(new Helper.test() { it = 9999, its = "9999" }))
                                {
                                    var atest = 1;
                                }

                                timer.Stop();
                                textBox1.Text = timer.ElapsedTicks.ToString();

                                break;
                            }
                        default:
                            break;
                    }
                    #endregion
                    break;

                case "Trailer Service":
                    var Trchannel = Helper.createChannel<ITrailerService>(typeof(void),
                                ConfigurationManager.AppSettings["TrailerURL"]);
                    switch (comboBox3.Text)
                    {
                        case "GetTrailers":
                            var resp = Trchannel.GetTrailers();
                            textBox1.Text = Helper.serialize<MovieTrailers>(resp);
                            break;
                        default:
                            break;
                    }
                    break;
                default: break;
            }
        }

        private static void testList(int capacity)
        {
            List<Helper.test> test = new List<Helper.test>();
            test.Capacity = capacity;

            for (int i = 0; i < 1000; i++)
            {
                test.Add(new Helper.test()
                {
                    it = i,
                    its = i.ToString()
                });

            }

        }

        #region Top20 Helpers
        private string getTop20period()
        {
            var old = ActiveForm;
            Top20Form inpForm = new Top20Form();
            old.Hide();
            inpForm.ShowDialog();
            old.Show();
            return inpForm.textBox1.Text;
        }
        #endregion

        #region Inventor Helpers
        public class inventoryChangedObject
        {
            public string productID { get; set; }
            public string storeId { get; set; }
            public string reservableCount { get; set; }
            public string inCirculationCount { get; set; }
            public DateTime datetime { get; set; }
            public bool delFlag { get; set; }
        }
        private inventoryChangedObject getInventoryChangedInputs()
        {
            inventoryChangedObject onj = new inventoryChangedObject();
            var old = ActiveForm;
            InvChangedForm inpForm = new InvChangedForm();
            old.Hide();
            inpForm.ShowDialog();
            old.Show();
            return new inventoryChangedObject
            {
                datetime = inpForm.dateTimePicker1.Value,
                delFlag = inpForm.checkBox1.Checked,
                inCirculationCount = inpForm.textBox4.Text,
                productID = inpForm.textBox1.Text,
                reservableCount = inpForm.textBox3.Text,
                storeId = inpForm.textBox2.Text
            };
        }
        #endregion

        private string getReservationInput(int flag)
        {
            var old = ActiveForm;
            ReservationForm resForm = new ReservationForm();
            if (flag == 1)
                resForm.label1.Text = "ExecutePricingPipeline Input string";
            else if (flag == 2)
            {
                resForm.label1.Text = "Checkout Input string";
            }
            old.Hide();
            resForm.ShowDialog();
            old.Show();

            return resForm.textBox1.Text;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            switch (comboBox2.Text)
            {

                case "Product Service":
                    #region Product Service
                    var PSchannel = Helper.createChannel<IProductService>(typeof(void),
                                ConfigurationManager.AppSettings["ProductURL"]);
                    switch (comboBox3.Text)
                    {
                        case "FullRefresh":
                            PSchannel.FullRefresh();
                            break;
                        case "GetMovies":
                            var products = PSchannel.GetMovies();
                            textBox1.Text = Helper.serialize<Products>(products);
                            break;
                        default:
                            break;
                    }
                    #endregion
                    break;


                case "Stores Service":
                    #region Stores Service
                    var Schannel = Helper.createChannel<IStoreService>(typeof(void),
                                ConfigurationManager.AppSettings["StoresURL"]);
                    switch (comboBox3.Text)
                    {
                        case "FullRefresh":
                            Schannel.FullRefresh();
                            break;
                        case "GetStores":
                            var stores = Schannel.GetStores();
                            textBox1.Text = Helper.serialize<Stores>(stores);
                            break;
                        default:
                            break;
                    }
                    #endregion
                    break;


                case "Top20 Service":
                    #region Top20 Service
                    var Tchannel = Helper.createChannel<ITop20Service>(typeof(void),
                                ConfigurationManager.AppSettings["Top20URL"]);
                    switch (comboBox3.Text)
                    {
                        case "FullRefresh":
                            Tchannel.FullRefresh();
                            break;
                        case "Top20":
                            var val = getTop20period();
                            var top20 = Tchannel.GetTop20(val);
                            textBox1.Text = Helper.serialize<Top20>(top20);
                            break;
                        default:
                            break;
                    }
                    #endregion
                    break;


                case "Inventory Service":
                    #region Inventory Service
                    switch (comboBox3.Text)
                    {
                        case "FullRefresh":
                            break;
                        case "GetInventory":
                            HttpWebRequest request = WebRequest.Create(ConfigurationManager.AppSettings["GetInventoryURL"]) as HttpWebRequest;
                            request.Timeout = int.MaxValue;
                            request.Headers = new WebHeaderCollection();
                            //request.Headers.Add(HttpRequestHeader.Accept, "text/xml");
                            request.Accept = "text/xml";
                            request.Headers.Add(HttpRequestHeader.AcceptEncoding, "gzip");
                            using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
                            {
                                if (response.StatusCode != HttpStatusCode.OK)
                                {
                                    textBox1.Text = string.Format("Response-> {0}:{1}", response.StatusCode, response.StatusDescription);
                                }
                                textBox1.Text = response.ContentLength.ToString();
                                var fs = File.Create(@"c:\invencrypted.xml");
                                response.GetResponseStream().CopyTo(fs);
                                fs.Close();
                            }
                            break;
                        case "GetInventoryChanged":
                            break;
                        default:
                            break;
                    }
                    #endregion
                    break;

                case "Reservation Service":
                    #region Reservation Service
                    var Rchannel = Helper.createChannel<IReservationService>(typeof(void),
                                            ConfigurationManager.AppSettings["ReservationURL"]);
                    switch (comboBox3.Text)
                    {
                        case "ExecutePricingPipeline":
                            {
                                //var pricingXML = getReservationInput(1);
                                var inCart = new CartIn()
                                {
                                    ProductRef = new List<string>() { { "497b7223-7ef6-4348-904b-26c8b11cd43c" } },
                                    StoreRef = "179C6537-FC1E-4947-A443-3CC90428B971",
                                    UserId = "1690412",
                                    //CardId = "8216705"
                                    CardId = "57758084756894"//"64825678041750"
                                };
                                var b = Helper.serialize<CartIn>(inCart);
                                var resp = Rchannel.ExecuteReservationPricingPipeline(inCart);
                                textBox1.Text = Helper.serialize<PricedCartResponse>(resp);
                                break;
                            }

                        case "CheckOut":
                            {
                                var inCart = new PricedCart()
                                {

                                    CardId = "18368475739307",
                                    CartItem = new List<CartItems>(){
                                           {new CartItems(){ Discount=0, DiscountedPrice=1, ExtraPrice=0, Format="DVD", ImageUrl="", ItemStatus="Valid", Name="Kick-Ass", Price=1, ProductRef="497b7223-7ef6-4348-904b-26c8b11cd43c", ProductType="Movie", Rating=Rating.G }
                                           }
                                    },
                                    DiscountedSubTotal = 1,
                                    GrandTotal = 1.08m,
                                    Online = true,
                                    StoreRef = "179C6537-FC1E-4947-A443-3CC90428B971",
                                    SubTotal = 1,
                                    Tax = 0.08m,
                                    UserId = "2074989"
                                };
                                var b = Helper.serialize<PricedCart>(inCart);
                                //storeRef":1527,"items":[{"id":3,"productRef":3974
                                var resp = Rchannel.CheckOut(inCart);
                                textBox1.Text = Helper.serialize<ReservationResponse>(resp);
                                break;
                            }
                        case "ILTest":
                            {
                                var list2 = Stopwatch.StartNew();
                                testList(2);
                                list2.Stop();

                                var list1002 = Stopwatch.StartNew();
                                testList(1002);
                                list1002.Stop();

                                textBox1.Text = string.Format("List1 took {0} ms and list2 took {1} ms", list2.ElapsedTicks, list1002.ElapsedTicks);
                                break;


                            }
                        case "ListTest":
                            {
                                List<Helper.test> testlist = new List<Helper.test>();
                                var teststr = new List<string>();

                                //for (int i = 0; i < 10; i++)
                                //{
                                //    testlist.Add(new Helper.test() { it = i, its = i.ToString() });
                                //    teststr.Add(i.ToString());
                                //}
                                var testhash = new HashSet<Helper.test>(testlist);

                                testlist.Capacity = 2;

                                testlist.Add(new Helper.test() { it = 1, its = "1" });
                                testlist.Add(new Helper.test() { it = 2, its = "2" });
                                testlist.Add(new Helper.test() { it = 3, its = "3" });
                                testlist.Add(new Helper.test() { it = 4, its = "4" });
                                testlist.Add(new Helper.test() { it = 5, its = "5" });

                                teststr.Add("1");
                                teststr.Add("3");
                                teststr.Add("4");
                                teststr.Add("5");

                                var abclist = new List<Helper.testmerge>();


                                for (var i = 6; i < 10000; i++)
                                {
                                    testlist.Add(new Helper.test() { it = i, its = i.ToString() });
                                }
                                Stopwatch timer = new Stopwatch();
                                timer.Start();
                                foreach (var item in testlist)
                                {

                                    var newItem = new Helper.testmerge()
                                    {
                                        test = item
                                    };
                                    if (teststr.Contains(item.it.ToString()))
                                    {
                                        newItem.test1 = item.it.ToString();
                                    }
                                    abclist.Add(newItem);
                                }
                                if (testlist.Contains(new Helper.test() { it = 9999, its = "9999" }))
                                {
                                    var atest = 1;
                                }
                                DateTime end = DateTime.Now;
                                timer.Stop();

                                textBox1.Text = timer.ElapsedTicks.ToString();
                                break;


                            }
                        case "DictTest":
                            {
                                var testlist = new List<Helper.test>();
                                var teststr = new List<string>();

                                //for (int i = 0; i < 10; i++)
                                //{
                                //    testlist.Add(new Helper.test() { it = i, its = i.ToString() });
                                //    teststr.Add(i.ToString());
                                //}

                                testlist.Add(new Helper.test() { it = 1, its = "1" });
                                testlist.Add(new Helper.test() { it = 2, its = "2" });
                                testlist.Add(new Helper.test() { it = 3, its = "3" });
                                testlist.Add(new Helper.test() { it = 4, its = "4" });

                                teststr.Add("1");
                                teststr.Add("3");
                                teststr.Add("4");
                                teststr.Add("5");

                                var abclist = new List<Helper.testmerge>();

                                Dictionary<int, Helper.test> dict = new Dictionary<int, Helper.test>();
                                dict.Add(1, new Helper.test() { it = 1, its = "1" });
                                dict.Add(2, new Helper.test() { it = 2, its = "2" });
                                dict.Add(3, new Helper.test() { it = 3, its = "3" });
                                dict.Add(4, new Helper.test() { it = 4, its = "4" });
                                dict.Add(5, new Helper.test() { it = 5, its = "5" });
                                for (var i = 6; i < 10000; i++)
                                {
                                    dict.Add(i, new Helper.test() { it = i, its = i.ToString() });
                                }
                                Stopwatch timer = new Stopwatch();
                                timer.Start();
                                foreach (var item in dict)
                                {

                                    var newItem = new Helper.testmerge()
                                    {
                                        test = item.Value
                                    };
                                    if (teststr.Contains(item.Key.ToString()))
                                    {
                                        newItem.test1 = item.Key.ToString();
                                    }
                                    abclist.Add(newItem);
                                }
                                if (dict.ContainsKey(9999))
                                {
                                    var atest = 1;
                                }
                                DateTime end = DateTime.Now;
                                timer.Stop();

                                textBox1.Text = timer.ElapsedTicks.ToString();
                                break;


                            }
                        case "HashTest":
                            {
                                var testlist = new List<Helper.test>();
                                var teststr = new List<string>();

                                testlist.Add(new Helper.test() { it = 1, its = "1" });
                                testlist.Add(new Helper.test() { it = 2, its = "2" });
                                testlist.Add(new Helper.test() { it = 3, its = "3" });
                                testlist.Add(new Helper.test() { it = 4, its = "4" });

                                teststr.Add("1");
                                teststr.Add("3");
                                teststr.Add("4");
                                teststr.Add("5");

                                var abclist = new List<Helper.testmerge>();


                                var hash = new HashSet<Helper.test>();
                                hash.Add(new Helper.test() { it = 1, its = "1" });
                                hash.Add(new Helper.test() { it = 2, its = "2" });
                                hash.Add(new Helper.test() { it = 3, its = "3" });
                                hash.Add(new Helper.test() { it = 4, its = "4" });
                                hash.Add(new Helper.test() { it = 5, its = "5" });
                                for (var i = 6; i < 10000; i++)
                                {
                                    hash.Add(new Helper.test() { it = i, its = i.ToString() });
                                }
                                Stopwatch timer = new Stopwatch();
                                timer.Start();
                                foreach (var item in hash)
                                {

                                    var newItem = new Helper.testmerge()
                                    {
                                        test = item
                                    };
                                    if (teststr.Contains(item.it.ToString()))
                                    {
                                        newItem.test1 = item.it.ToString();
                                    }
                                    abclist.Add(newItem);
                                }
                                if (hash.Contains(new Helper.test() { it = 9999, its = "9999" }))
                                {
                                    var atest = 1;
                                }

                                timer.Stop();
                                textBox1.Text = timer.ElapsedTicks.ToString();

                                break;
                            }
                        default:
                            break;
                    }
                    #endregion
                    break;

                case "Trailer Service":
                    var Trchannel = Helper.createChannel<ITrailerService>(typeof(void),
                                ConfigurationManager.AppSettings["TrailerURL"]);
                    switch (comboBox3.Text)
                    {
                        case "GetTrailers":
                            var resp = Trchannel.GetTrailers();
                            textBox1.Text = Helper.serialize<MovieTrailers>(resp);
                            break;
                        default:
                            break;
                    }
                    break;
                default: break;
            }
        }

        private void Validate_Click_1(object sender, EventArgs e)
        {
            try
            {
                XmlDocument xDoc = new XmlDocument();
                xDoc.Load(XmlPath.Text);
                var csvs = XslPath.Text;
                var xsds = csvs.Remove(csvs.Length-1).Split(',');
                Dictionary<string, string> schemas = new Dictionary<string, string>();
                foreach (var xsd in xsds)
                {
                    schemas.Add(xsd, xsd);


                }
                Helper.validate(xDoc.OuterXml, schemas);
                if (Helper.err.ErrorsCount > 0)
                {
                    MessageBox.Show(Helper.err.ErrorMessage);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Error: " + ex.ToString());
            }
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

            XmlPath.Text = openFileDialog1.FileName;
        }

        private void Browse1_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "XML Files | *.xml";
            openFileDialog1.ShowDialog();
        }

        private void Browse2_Click(object sender, EventArgs e)
        {
            openFileDialog2.Multiselect = true;
            openFileDialog2.Filter = "XSD Files | *.xsd";
            openFileDialog2.ShowDialog();
        }

        private void openFileDialog2_FileOk(object sender, CancelEventArgs e)
        {
            string[] str = openFileDialog2.FileNames;
            foreach (var file in str)
	{
        XslPath.Text += file + ",";//file.Substring(file.LastIndexOf("\\")+1) + " ";
            }

            
        }


    }
}

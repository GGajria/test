﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DBTest
{
    public class GetInventory_Result
    {
        public virtual ID id { get; set; }
        public virtual string StoreGuid { get; set; }
        public virtual long Reservable_Cnt { get; set; }
        public virtual long InCirculation_Cnt { get; set; }
        public virtual string LastUpdated_Dt { get; set; }
    }
    
    //Contains the composite key
    [Serializable]
    public class ID
    {
        public virtual long Store_Id { get; set; }
        public virtual long Product_Nbr { get; set; }
        
        //to match equality (required by nHibernate)
        public override bool Equals(object obj)
        {
            ID a = obj as ID;
            if ( (Store_Id == a.Store_Id) &&
                 (Product_Nbr == a.Product_Nbr)
                )
            {
                return true;
            }
            else
                return false;
        }

        //return hashcode (required by nHibernate)
        public override int GetHashCode()
        {
            return ( this.Product_Nbr.ToString() + "|" +
                    this.Store_Id.ToString()
                    ).GetHashCode();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Sql;
using System.Data.SqlClient;
using NHibernate;
using NHibernate.Cfg;


namespace DBTest
{
    class Program
    {
        static void Main(string[] args)
        {


            Console.WriteLine("Using datareader..");
            var timer = System.Diagnostics.Stopwatch.StartNew();
            datareaderMethod();
            Console.WriteLine("{0} ms for GetInventory", timer.ElapsedMilliseconds);
            
            Console.WriteLine("Using dataset..");
            var timer3 = System.Diagnostics.Stopwatch.StartNew();
            datasetMethod();
            Console.WriteLine("{0} ms for GetInventory", timer3.ElapsedMilliseconds);
            
            Console.WriteLine("Using nHibernate..");
            var timer2 = System.Diagnostics.Stopwatch.StartNew();
            nhibernateMethod();
            Console.WriteLine("{0} ms for GetInventory", timer2.ElapsedMilliseconds);
            Console.ReadLine();


            

        }

        private static void datareaderMethod()
        {
            SqlConnection db = new SqlConnection("Data Source=DEVPSDB02;Initial Catalog=ODS;Integrated Security=True");
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = db;
            cmd.CommandText = "Openapi.GetInventory";
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            db.Open();
            //SqlDataAdapter da = new SqlDataAdapter(cmd);
            //var ds = new System.Data.DataSet();
            var dr = cmd.ExecuteReader();
            while (dr.Read())
            {
             
            };
            dr.Close();
            //da.Fill();
            //da.Dispose();
            //ds.Dispose();
            cmd.Dispose();
            db.Dispose();
        }

        private static void datasetMethod()
        {
            SqlConnection db = new SqlConnection("Data Source=DEVPSDB02;Initial Catalog=ODS;Integrated Security=True");
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = db;
            cmd.CommandText = "Openapi.GetInventory";
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            var ds = new System.Data.DataSet();
            da.Fill(ds);
            da.Dispose();
            ds.Dispose();
            cmd.Dispose();
            db.Dispose();
        }

        private static void nhibernateMethod()
        {
            Configuration cfg = new Configuration();
            cfg.AddAssembly(typeof(GetInventory_Result).Assembly);
            var fact = cfg.BuildSessionFactory();
            var sess = fact.OpenSession();
            var qry = sess.GetNamedQuery("GetInventory");
            //var qry = sess.CreateSQLQuery("select 1");
            var res = qry.List();
            sess.Close();
            fact.Close();
        }
    }
}

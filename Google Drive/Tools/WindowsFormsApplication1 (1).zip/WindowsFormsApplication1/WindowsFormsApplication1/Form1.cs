﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;
using System.Configuration;
using Redbox.OpenServices.Contracts;
using System.ServiceModel.Description;
using System.Xml.Serialization;
using System.IO;

namespace ServiceCaller
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)//movies
        {
            try
            {
                //start timer
                var myBinding = new WebHttpBinding();
                myBinding.SendTimeout = TimeSpan.MaxValue;
                myBinding.MaxReceivedMessageSize = int.MaxValue;
                textBox1.Text = string.Empty;
                XmlSerializer a = new XmlSerializer(typeof(Products));
                StringWriter b = new StringWriter(new StringBuilder());
                //Change the endpoint address to point to the service URL
                var URL = "http://localhost:55383/Products";
                var myEndpoint =
                    new EndpointAddress(URL);
                var myChannelFactory =
                    new ChannelFactory<IProductService>(
                        myBinding, myEndpoint);
                myChannelFactory.Endpoint.Behaviors.Add(new WebHttpBehavior());
                // Create a channel.
                var wcfClient1 = myChannelFactory.CreateChannel();
                var movies = wcfClient1.GetMovies();
                ((IClientChannel)wcfClient1).Close();
                a.Serialize(b, movies);
                textBox1.Text = b.ToString();
                return;
            }
            catch (Exception ex)
            {
                textBox1.Text = ex.ToString();
                return;
            }
        }

        private void button2_Click(object sender, EventArgs e)//stores
        {
            try
            {
                //start timer
                XmlSerializer a = new XmlSerializer(typeof(Stores));
                StringWriter b = new StringWriter(new StringBuilder());
                textBox1.Text = string.Empty;
                var myBinding = new WebHttpBinding();
                myBinding.SendTimeout = TimeSpan.MaxValue;
                myBinding.MaxReceivedMessageSize = int.MaxValue;
                var URL = "http://localhost:55383/Stores";
                var myEndpoint =
                    new EndpointAddress(URL);
                var myChannelFactory =
                    new ChannelFactory<IStoreService>(
                        myBinding, myEndpoint);
                myChannelFactory.Endpoint.Behaviors.Add(new WebHttpBehavior());
                // Create a channel.
                var wcfClient1 = myChannelFactory.CreateChannel();
                var stores = wcfClient1.GetStores();
                ((IClientChannel)wcfClient1).Close();
                a.Serialize(b, stores);
                textBox1.Text = b.ToString();


                return;
            }
            catch (Exception ex)
            {
                textBox1.Text = ex.ToString();
                return;
            }
        }

        private void button3_Click(object sender, EventArgs e)//Top20
        {
            try
            {
                //start timer
                var myBinding = new WebHttpBinding();
                myBinding.SendTimeout = TimeSpan.MaxValue;
                myBinding.MaxReceivedMessageSize = int.MaxValue;
                textBox1.Text = string.Empty;
                XmlSerializer a = new XmlSerializer(typeof(Top20));
                StringWriter b = new StringWriter(new StringBuilder());

                var URL = "http://localhost:55383/Top20/";
                var myEndpoint =
                    new EndpointAddress(URL);
                var myChannelFactory =
                    new ChannelFactory<ITop20Service>(
                        myBinding, myEndpoint);
                myChannelFactory.Endpoint.Behaviors.Add(new WebHttpBehavior());
                // Create a channel.
                var wcfClient1 = myChannelFactory.CreateChannel();
                var Top20 = wcfClient1.GetTop20(int.Parse(comboBox1.SelectedItem.ToString()));
                ((IClientChannel)wcfClient1).Close();
                a.Serialize(b, Top20);
                textBox1.Text = b.ToString();

                return;
            }
            catch (Exception ex)
            {
                textBox1.Text = ex.ToString();
                return;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    //start timer
            //    var myBinding = new WebHttpBinding();
            //    myBinding.SendTimeout = TimeSpan.MaxValue;
            //    myBinding.MaxReceivedMessageSize = int.MaxValue;
            //    textBox1.Text = string.Empty;
            //    XmlSerializer resSer = new XmlSerializer(typeof(Products));
            //    XmlSerializer reqSer = new XmlSerializer(typeof(MovieBrowseRequest));
            //    StringWriter resWriter = new StringWriter(new StringBuilder());
            //    StringWriter reqWriter = new StringWriter(new StringBuilder());
            //    //Change the endpoint address to point to the service URL
            //    var URL = "http://localhost:55383/Products";
            //    var myEndpoint =
            //        new EndpointAddress(URL);
            //    var myChannelFactory =
            //        new ChannelFactory<IProductService>(
            //            myBinding, myEndpoint);
            //    myChannelFactory.Endpoint.Behaviors.Add(new WebHttpBehavior());
            //    // Create a channel.
            //    var wcfClient1 = myChannelFactory.CreateChannel();
            //    //FileStream fs = new FileStream(@"D:\test.txt", FileMode.Open);
            //    List<string> str = new List<string>();
            //    str.Add("57c5cf15-80fc-43f6-affc-0b9a60f9d290");
            //    str.Add("1627aea5-8e0a-4371-9022-9b504344e724");
            //    str.Add("57f55702-dffd-4697-b8ba-76776a25d741");
            //    str.Add("10b6a27c-1a8d-4a9c-9e38-7e81b4712315");


            //    var mbr = new MovieBrowseRequest { ProductId = str };
            //    var movies = wcfClient1.GetMoviesFull(mbr);
            //    ((IClientChannel)wcfClient1).Close();
            //    resSer.Serialize(resWriter, movies);
            //    reqSer.Serialize(reqWriter, mbr);
            //    textBox2.Text = reqWriter.ToString();
            //    textBox1.Text = resWriter.ToString();
            //    return;
            //}
            //catch (Exception ex)
            //{
            //    textBox1.Text = ex.ToString();
            //    return;
            //}
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    //start timer
            //    var myBinding = new WebHttpBinding();
            //    myBinding.SendTimeout = TimeSpan.MaxValue;
            //    myBinding.MaxReceivedMessageSize = int.MaxValue;
            //    textBox1.Text = string.Empty;
            //    XmlSerializer resSer = new XmlSerializer(typeof(Products));
            //    StringWriter resWriter = new StringWriter(new StringBuilder());
            //    //Change the endpoint address to point to the service URL
            //    var URL = "http://localhost:55383/Products";
            //    var myEndpoint =
            //        new EndpointAddress(URL);
            //    var myChannelFactory =
            //        new ChannelFactory<IProductService>(
            //            myBinding, myEndpoint);
            //    myChannelFactory.Endpoint.Behaviors.Add(new WebHttpBehavior());
            //    // Create a channel.
            //    var wcfClient1 = myChannelFactory.CreateChannel();
            //    var movies = wcfClient1.GetMoviesAll();
            //    ((IClientChannel)wcfClient1).Close();
            //    resSer.Serialize(resWriter, movies);
            //    textBox1.Text = resWriter.ToString();
            //    return;
            //}
            //catch (Exception ex)
            //{
            //    textBox1.Text = ex.ToString();
            //    return;
            //}
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    //start timer
            //    var myBinding = new WebHttpBinding();
            //    myBinding.SendTimeout = TimeSpan.MaxValue;
            //    myBinding.MaxReceivedMessageSize = int.MaxValue;
            //    textBox1.Text = string.Empty;
            //    XmlSerializer resSer = new XmlSerializer(typeof(Products));
            //    StringWriter resWriter = new StringWriter(new StringBuilder());
            //    //Change the endpoint address to point to the service URL
            //    var URL = "http://localhost:55383/Products";
            //    var myEndpoint =
            //        new EndpointAddress(URL);
            //    var myChannelFactory =
            //        new ChannelFactory<IProductService>(
            //            myBinding, myEndpoint);
            //    myChannelFactory.Endpoint.Behaviors.Add(new WebHttpBehavior());
            //    // Create a channel.
            //    var wcfClient1 = myChannelFactory.CreateChannel();
            //    var movies = wcfClient1.GetMovie("57f55702-dffd-4697-b8ba-76776a25d741");
            //    ((IClientChannel)wcfClient1).Close();
            //    resSer.Serialize(resWriter, movies);
            //    textBox1.Text = resWriter.ToString();
            //    return;
            //}
            //catch (Exception ex)
            //{
            //    textBox1.Text = ex.ToString();
            //    return;
            //}
        }

        private void button7_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    //start timer
            //    var myBinding = new WebHttpBinding();
            //    myBinding.SendTimeout = TimeSpan.MaxValue;
            //    myBinding.MaxReceivedMessageSize = int.MaxValue;
            //    textBox1.Text = string.Empty;
            //    XmlSerializer a = new XmlSerializer(typeof(Top20));
            //    StringWriter b = new StringWriter(new StringBuilder());

            //    var URL = "http://localhost:55383/Top20/";
            //    var myEndpoint =
            //        new EndpointAddress(URL);
            //    var myChannelFactory =
            //        new ChannelFactory<ITop20Service>(
            //            myBinding, myEndpoint);
            //    myChannelFactory.Endpoint.Behaviors.Add(new WebHttpBehavior());
            //    // Create a channel.
            //    var wcfClient1 = myChannelFactory.CreateChannel();
            //    wcfClient1.TestCounters();
            //    ((IClientChannel)wcfClient1).Close();

            //    return;
            //}
            //catch (Exception ex)
            //{
            //    textBox1.Text = ex.ToString();
            //    return;
            //}
        }

        private void button8_Click(object sender, EventArgs e)
        {
            try
            {
                //start timer
                var myBinding = new WebHttpBinding();
                myBinding.SendTimeout = TimeSpan.MaxValue;
                myBinding.MaxReceivedMessageSize = int.MaxValue;
                textBox1.Text = string.Empty;
                XmlSerializer resSer = new XmlSerializer(typeof(PricedCartResponse));
                //XmlSerializer reqSer = new XmlSerializer(typeof(CartIn));
                StringWriter resWriter = new StringWriter(new StringBuilder());
                //StringWriter reqWriter = new StringWriter(new StringBuilder());
                //Change the endpoint address to point to the service URL
                var URL = ConfigurationManager.AppSettings["ReservationURL"];
                var myEndpoint =
                    new EndpointAddress(URL);
                var myChannelFactory =
                    new ChannelFactory<IReservationService>(
                        myBinding, myEndpoint);
                myChannelFactory.Endpoint.Behaviors.Add(new WebHttpBehavior());
                // Create a channel.
                var wcfClient1 = myChannelFactory.CreateChannel();
                //FileStream fs = new FileStream(@"D:\test.txt", FileMode.Open);
                //var inCart = new CartIn()
                //{
                //    CardCVV = "547",
                //    CardId = "908",
                //    DiscountsApplied = new List<DiscountsApplied>(){
                //      {new DiscountsApplied(){ 
                //        DiscountType = DiscountType.WebCredit, NumDiscountsApplied = 23}
                //      },
                //      {
                //      new DiscountsApplied(){
                //        DiscountType= DiscountType.PromoCode, NumDiscountsApplied = 34}
                //      }
                //    },
                //    ProductRef = new List<string>() { { "123" },
                //                                      { "345" },
                //                                      { "289" },
                //                                      { "127" },
                //                                      { "234" },},
                //    StoreRef = "234",
                //    UserId = "test@gmail.com"
                //};

                var stringInput = @"<Cart xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns=""http://api.redbox.com/Reservations/v1"">
  <UserId>test@gmail.com</UserId>
  <StoreRef>234</StoreRef>
  <CardId>908</CardId>
  <CardCVV>547</CardCVV>
  <ProductRef>123</ProductRef>
  <ProductRef>345</ProductRef>
  <ProductRef>289</ProductRef>
  <ProductRef>127</ProductRef>
  <ProductRef>234</ProductRef>
  <DiscountsApplied>
    <DiscountApplication>
      <DiscountType>WebCredit</DiscountType>
      <NumDiscountsApplied>23</NumDiscountsApplied>
      <NumDiscountsAvailable>0</NumDiscountsAvailable>
    </DiscountApplication>
    <DiscountApplication>
      <DiscountType>PromoCode</DiscountType>
      <NumDiscountsApplied>34</NumDiscountsApplied>
      <NumDiscountsAvailable>0</NumDiscountsAvailable>
    </DiscountApplication>
  </DiscountsApplied>
</Cart>";
                //reqSer.Serialize(reqWriter, inCart);
                textBox2.Text = stringInput;

                var movies = wcfClient1.ExecuteReservationPricingPipeline(stringInput);
                ((IClientChannel)wcfClient1).Close();
                resSer.Serialize(resWriter, movies);
                textBox1.Text = resWriter.ToString();
                return;
            }
            catch (Exception ex)
            {
                textBox1.Text = ex.ToString();
                return;
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            try
            {
                //start timer
                var myBinding = new WebHttpBinding();
                myBinding.SendTimeout = TimeSpan.MaxValue;
                myBinding.MaxReceivedMessageSize = int.MaxValue;
                textBox1.Text = string.Empty;
                XmlSerializer resSer = new XmlSerializer(typeof(ReservationResponse));
                //XmlSerializer reqSer = new XmlSerializer(typeof(PricedCart));
                StringWriter resWriter = new StringWriter(new StringBuilder());
                //StringWriter reqWriter = new StringWriter(new StringBuilder());
                //Change the endpoint address to point to the service URL
                var URL = ConfigurationManager.AppSettings["ReservationURL"];
                var myEndpoint =
                    new EndpointAddress(URL);
                var myChannelFactory =
                    new ChannelFactory<IReservationService>(
                        myBinding, myEndpoint);
                myChannelFactory.Endpoint.Behaviors.Add(new WebHttpBehavior());
                // Create a channel.
                var wcfClient1 = myChannelFactory.CreateChannel();
                //FileStream fs = new FileStream(@"D:\test.txt", FileMode.Open);
                //var inCart = new PricedCart()
                //{
                //    CardCVV = "234",
                //    CardId = "234",
                //    CartItem = new List<CartItems>(){
                //           {new CartItems(){ Discount=22, DiscountedPrice=23, ExtraPrice=23, Format="DVD", ImageUrl="", ItemStatus="Valid", Name="", Price=34, ProductRef="234", ProductType="Movie", Rating=Rating.G }},
                //           {new CartItems(){ Discount=34, DiscountedPrice=34, ExtraPrice=23, Format="BluRay", ImageUrl="", ItemStatus="Valid", Name="", Price=34, ProductRef="245", ProductType="Movie", Rating=Rating.G }}
                //    },
                //    DiscountedSubTotal = 23,
                //    GrandTotal = 45,
                //    Online = true,
                //    StoreRef = "234",
                //    SubTotal = 345,
                //    Tax = 23,
                //    UserId = "23"
                //};
                var inString = @"<?xml version=""1.0"" encoding=""utf-8""?>
<PricedCart xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">
  <UserId>23</UserId>
  <StoreRef>234</StoreRef>
  <Online>true</Online>
  <CardId>234</CardId>
  <CardCVV>234</CardCVV>
  <CartItems>
    <CartItem ProductRef=""234"" Name="""" ProductType=""Movie"" Price=""34"" ImageUrl="""" Discount=""22"" DiscountedPrice=""23"" ExtraPrice=""23"" Format=""DVD"" ItemStatus=""Valid"" Rating=""G"" />
    <CartItem ProductRef=""245"" Name="""" ProductType=""Movie"" Price=""34"" ImageUrl="""" Discount=""34"" DiscountedPrice=""34"" ExtraPrice=""23"" Format=""BluRay"" ItemStatus=""Valid"" Rating=""G"" />
  </CartItems>
  <SubTotal>345</SubTotal>
  <DiscountedSubTotal>23</DiscountedSubTotal>
  <GrandTotal>45</GrandTotal>
  <Tax>23</Tax>
</PricedCart>";
                //reqSer.Serialize(reqWriter, inCart);
                textBox2.Text = inString;

                var movies = wcfClient1.CheckOut(inString);
                ((IClientChannel)wcfClient1).Close();
                resSer.Serialize(resWriter, movies);
                textBox1.Text = resWriter.ToString();
                return;
            }
            catch (Exception ex)
            {
                textBox1.Text = ex.ToString();
                return;
            }
        }


    }
}

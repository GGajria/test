﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Redbox.OpenServices.Contracts;

namespace TestMvc.Models
{
    public class Movies
    {

        public List<MyMovies> getMovies()
        {
            var channel = ServiceCallerHelper.Helper.createChannel<IProductService>(typeof(Products), "http://devpsapp08/openservicesr3/products/");
            var products = channel.GetMovies();
            List<MyMovies> movies = new List<MyMovies>();
            foreach (var movie in products.Movie)
            {
                movies.Add(new MyMovies()
                {
                    isReleased = (DateTime.Parse(movie.RedboxReleaseDate) < DateTime.UtcNow).ToString(),
                    releaseDate = movie.RedboxReleaseDate,
                    title = movie.Title,
                    guid = movie.ProductId,
                    URL = movie.WebsiteUrl

                });
            }
            return movies;
        }

        public class MyMovies
        {
            public string URL;
            public string guid;
            public string title;
            public string releaseDate;
            public string isReleased;

        }



    }


}
﻿using System;
using System.IO;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Text;
using System.Xml.Serialization;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Schema;
using System.Net;

namespace ServiceCallerHelper
{
    public static class Helper
    {

        public static int createWebRequest(string URL, string method, string body,out String response)
        {
            HttpWebRequest request = WebRequest.Create(URL) as HttpWebRequest;
            request.Method = method;
            request.Timeout = int.MaxValue;
            
            //get gzipped data
            request.Headers = new WebHeaderCollection();
            request.Headers.Add(HttpRequestHeader.AcceptEncoding, "gzip");

            //request body
            if (method != "GET")
            {
                var reqStream = request.GetRequestStream();
                reqStream = convertToStream(body);
            }

            using (HttpWebResponse res = request.GetResponse() as HttpWebResponse)
            {
                if (res.StatusCode != HttpStatusCode.OK)
                {
                    var sr = new StreamReader(res.GetResponseStream());
                    response = sr.ReadToEnd();
                    return Convert.ToInt32(res.ContentLength);
                }
                response = String.Empty;
                return 0;
            }
        }
        
        
        
        /// <summary>
        /// Create WCF channel of type T
        /// </summary>
        /// <typeparam name="T">Service Interface</typeparam>
        /// <param name="type">Response Object</param>
        /// <param name="appSettingURL">Service URL</param>
        /// <returns></returns>
        public static T createChannel<T>(Type type, string appSettingURL)
        {
            //start timer
            var myBinding = new WebHttpBinding();
            myBinding.SendTimeout = TimeSpan.MaxValue;
            myBinding.MaxReceivedMessageSize = int.MaxValue;
            //Change the endpoint address to point to the service URL
            var myEndpoint =
                new EndpointAddress(appSettingURL);
            var myChannelFactory =
                new ChannelFactory<T>(
                    myBinding, myEndpoint);
            myChannelFactory.Endpoint.Behaviors.Add(new WebHttpBehavior());
            // Create a channel.
            return myChannelFactory.CreateChannel();
        }

        /// <summary>
        /// Serialize o of type T
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="o"></param>
        /// <returns></returns>
        public static string serialize<T>(Object o)
        {
            XmlSerializer Ser = new XmlSerializer(typeof(T));
            StringWriter Writer = new StringWriter(new StringBuilder());
            Ser.Serialize(Writer, (T)o);
            return Writer.ToString();
        }

        /// <summary>
        /// deserialize xml to T object
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="xml"></param>
        /// <returns></returns>
        public static object deserialize<T>(string xml)
        {
            MemoryStream stream = new MemoryStream();
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(xml);
            stream.Write(bytes, 0, bytes.Length);
            stream.Seek(0, 0);
            XmlSerializer ser = new XmlSerializer(typeof(T));
            return (T)ser.Deserialize(stream);
        }

        public static String convertToString(Stream stream)
        {
            return new StreamReader(stream).ReadToEnd();
        }

        public static Stream convertToStream(String str)
        {
            return new MemoryStream(Encoding.UTF8.GetBytes(str));
        }

        /// <summary>
        /// validate xml against xsd
        /// </summary>
        /// <param name="xml">input xml</param>
        /// <param name="schemas">a dictionary containing namespace and relative schema path</param>
        public static void validate(string xml, Dictionary<string, string> schemas)
        {
            //get the xml stream
            byte[] bArr = Encoding.Unicode.GetBytes(xml);
            MemoryStream ms = new MemoryStream(bArr);

            //add schemas required for validation
            XmlReaderSettings sett = new XmlReaderSettings();
            DirectoryInfo currDirectory = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);
            foreach (var schema in schemas)
            {
                XmlReader xr = XmlReader.Create(schema.Value);
                XmlSchema xs = XmlSchema.Read(xr, ValidationHandler);
                sett.Schemas.Add(xs);
            }
            sett.Schemas.Compile();
            sett.ValidationEventHandler += new ValidationEventHandler(ValidationHandler);
            sett.ValidationType = ValidationType.Schema;
            sett.ValidationFlags = XmlSchemaValidationFlags.ReportValidationWarnings;
            var xmlRead = XmlReader.Create(ms, sett);
            while (xmlRead.Read()) ;

            
        }

        public static StringBuilder validationFaults;
        public static int errCount=0;
        private static void ValidationHandler(object sender,
                                             ValidationEventArgs args)
        {
            validationFaults.Append(args.Message + " at line: " + args.Exception.LineNumber + ", char: " + args.Exception.LinePosition);
            errCount++;
        }
        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Redbox.OpenServices.Contracts;

namespace TestMvc.Models
{
    public class Stores
    {
        public List<MyStores> getStores()
        {
            var channel = ServiceCallerHelper.Helper.createChannel<IStoreService>(typeof(Stores), "http://devpsapp08/openservicesr3/Stores/");
            var storesResults = channel.GetStores();
            List<MyStores> stores = new List<MyStores>();
            foreach (var store in storesResults.Store)
            {
                stores.Add(new MyStores()
                {
                    banner = store.KioskBanner,
                    city = store.Location.City,
                    lat = store.Location.Lat,
                    lon = store.Location.Long,
                    state = store.Location.State,
                    status = store.KioskStatus,
                    label = store.KioskLabel,
                    guid = store.StoreId
                });
            }
            return stores;
        }
    }
    public class MyStores
    {
        public string lat;
        public string lon;
        public string city;
        public string status;
        public string banner;
        public string state;
        public string label;
        public string guid;

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TestMvc.Models;

namespace TestMvc.Controllers
{
    public class StoresController : Controller
    {
        //
        // GET: /Stores/

        public ActionResult Index()
        {
            return View(new Stores().getStores());
        }

        // POST: /Stores/Search
        public ActionResult Search(string searchField)
        {
            var a = new TestMvc.Models.Stores().getStores();
            var b = a.Where(x=>
                x.city.ToLowerInvariant().Contains(searchField.ToLowerInvariant()) ||
                x.banner.ToLowerInvariant().Contains(searchField.ToLowerInvariant())
                ).ToList();
            
            //foreach (var store in a)
            //{
            //    if (store.city.ToLowerInvariant().Contains(searchField.ToLowerInvariant()))
            //    filter.Add(store);
            //}

            return View("Index", b);
            
        }

    }
}

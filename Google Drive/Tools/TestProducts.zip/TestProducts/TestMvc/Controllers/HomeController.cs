﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TestMvc.Models;

namespace TestMvc.Controllers
{
    //public class HomeController : Controller
    //{

    //    private MoviesDBEntities _db = new MoviesDBEntities();
    //    public ActionResult Index()
    //    {
            
    //        return View(_db.Movies.ToList());
    //    }

    //    public ActionResult Details(int id)
    //    {
    //        var movie = (from m in _db.Movies
    //                     where m.Id == id
    //                     select m).First();
    //        return View(movie);
    //    }

    //    public ActionResult Create()
    //    {
    //        return View();
    //    } 

    //    [HttpPost]
    //    public ActionResult Create([Bind(Exclude="Id")] Movie movie)
    //    {
    //        if (!ModelState.IsValid)
    //            return View();
    //        _db.AddToMovies(movie);
    //        _db.SaveChanges();
    //        return RedirectToAction("Index");
    //    }
        
    //    public ActionResult Edit(int id)
    //    {
    //        var movie = (from m in _db.Movies 
    //                           where m.Id == id
    //                           select m).First();
    //        return View(movie);
    //    }

    //    [HttpPost]
    //    public ActionResult Edit(int id, Movie movie)
    //    {
    //        try
    //        {
    //            return RedirectToAction("Index");
    //        }
    //        catch
    //        {
    //            return View();
    //        }
    //    }

    //    public ActionResult Delete(int id)
    //    {
    //        var movie = (from m in _db.Movies
    //                     where m.Id == id
    //                     select m).First();
    //        return View(movie);
    //    }

    //    [HttpPost]
    //    public ActionResult Delete(int id, FormCollection collection)
    //    {
    //        try
    //        {
    //            return RedirectToAction("Index");
    //        }
    //        catch
    //        {
    //            return View();
    //        }
    //    }
    //}
}

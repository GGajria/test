﻿using System;
using System.Collections.Generic;
using System.Security.Principal;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Microsoft.IdentityModel.Claims;
using Microsoft.IdentityModel.Protocols.WSFederation;
using Microsoft.IdentityModel.Protocols.WSIdentity;
using Microsoft.IdentityModel.SecurityTokenService;
using Microsoft.IdentityModel.Web;
using Redbox.OpenServices.IdentityModel;
using Redbox.OpenServices.IdentityProvider.Endpoints.Security;
using Claim = Microsoft.IdentityModel.Claims.Claim;
using MicrosoftClaimTypes = Microsoft.IdentityModel.Claims.ClaimTypes;
using RedboxClaimTypes = Redbox.OpenServices.IdentityModel.ClaimTypes;

namespace Redbox.OpenServices.IdentityProvider.Endpoints.Controllers
{
    public class FedAuthController : Controller
    {
        #region Fields

        private static readonly RedboxSecurityTokenServiceConfiguration _securityTokenServiceConfiguration = new RedboxSecurityTokenServiceConfiguration(Certificates.SigningCertificate);
        private static readonly string _rootUrl = ""; //TODO:Build app root url here

        #endregion

        #region Passive Security Token Service Methods

        [Authorize]
        public ActionResult Issue(string id)
        {
            WSFederationMessage requestMessage = WSFederationMessage.CreateFromUri(HttpContext.Request.Url);

            if (requestMessage is SignInRequestMessage)
            {
                // Remove temporary forms auth cookie
                FormsAuthentication.SignOut();

                // Process sign in request
                IPrincipal principal = CreateClaimsPrincipal();
                SecurityTokenService securityTokenService = _securityTokenServiceConfiguration.CreateSecurityTokenService();
                SignInResponseMessage responseMessage = FederatedPassiveSecurityTokenServiceOperations.ProcessSignInRequest(requestMessage as SignInRequestMessage, principal, securityTokenService);
                string content = responseMessage.WriteFormPost();

                //TODO: Add SSO siign out cookie (using WIF API). 

                return new ContentResult
                {
                    Content = content
                };
            }
            else if (requestMessage is SignOutRequestMessage)
            {
                // Sign out user 
                //FederatedAuthentication.SessionAuthenticationModule.SignOut(); //use FederatedPassiveSecurityTokenServiceOperations.ProcessSignOutRequest

                //FormsAuthentication.SignOut();
                
                //FederatedPassiveSecurityTokenServiceOperations.ProcessSignOutRequest((SignOutRequestMessage)requestMessage, Thread.CurrentPrincipal, ((SignOutRequestMessage)requestMessage).Reply, ControllerContext.HttpContext.Response);


                SignOutRequestMessage requestSignOutUrl = (SignOutRequestMessage)WSFederationMessage.CreateFromUri(Request.Url);

                //WSFederationAuthenticationModule.GetFederationPassiveSignOutUrl(


                FederatedPassiveSecurityTokenServiceOperations.ProcessSignOutRequest(requestSignOutUrl, Thread.CurrentPrincipal, requestSignOutUrl.Reply, null);
                
                //pass in httpResponse 
                //redirect will be written to response and you won't need
                //the lines of code below

                string replyUrl = ((SignOutRequestMessage)requestMessage).Reply;
                string redirectUrl;

                if (!String.IsNullOrWhiteSpace(replyUrl))
                {
                    redirectUrl = replyUrl;
                }
                else
                {
                    redirectUrl = ""; //TODO: Build redirect URL to sign in page
                }

                return new RedirectResult(redirectUrl); //for this we may be able to just return null, the redirect will already be in the response, don't need to do it explicitly like above
            }
            else
            {
                //need to figure out what should be done if message doesn't match either, throw exception?
                throw new Exception("Incoming message is not a SignIn or SignOut Message");
            }
        }

        public ActionResult Validate(string id)
        {
            throw new NotImplementedException();
        }

        public ActionResult Renew(string id)
        {
            throw new NotImplementedException();
        }

        public ActionResult Cancel(string id)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region Federation Metadata Methods

        public ActionResult GenerateMetadata()
        {
            RedboxSecurityTokenServiceFederationMetadataGenerator metadataGenerator = new RedboxSecurityTokenServiceFederationMetadataGenerator(
                Certificates.SigningCertificate,
                new List<DisplayClaim>
                {
                    new DisplayClaim(MicrosoftClaimTypes.NameIdentifier) { Optional = false },
                    new DisplayClaim(RedboxClaimTypes.IdentityProvider) { Optional = false },
                    new DisplayClaim(MicrosoftClaimTypes.Name) { Optional = true },
                    new DisplayClaim(MicrosoftClaimTypes.Email) { Optional = true }
                },
                _rootUrl + "/wsfed",
                _rootUrl + "/wsfed"
            );

            string metaData = metadataGenerator.Generate();

            return new ContentResult
            {
                Content = metaData,
                ContentType = "text/xml"
            };
        }

        #endregion

        #region Helper Methods

        private IClaimsPrincipal CreateClaimsPrincipal()
        {
            IClaimsIdentity identity = new ClaimsIdentity(
                new List<Claim> 
                {
                    new Claim(RedboxClaimTypes.WebAccountID, Thread.CurrentPrincipal.Identity.Name)
                }
            );
            IClaimsPrincipal principal = new ClaimsPrincipal(new ClaimsIdentityCollection() { identity });
            return principal;
        }

        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Web;
using Redbox.OpenServices.IdentityModel ;

namespace Redbox.OpenServices.IdentityProvider.Endpoints.Security
{
    public static class Certificates
    {
        #region Fields

        public static readonly X509Certificate2 SigningCertificate;
        public static readonly X509Certificate2 EncryptingCertificate;

        #endregion

        #region Constructors

        static Certificates()
        {
            CertificateUtility.TryGet(StoreName.My, StoreLocation.LocalMachine, ConfigurationManager.AppSettings["SigningCertificate"], out SigningCertificate);
            CertificateUtility.TryGet(StoreName.My, StoreLocation.LocalMachine, ConfigurationManager.AppSettings["EncryptingCertificate"], out EncryptingCertificate);
        }

        #endregion
    }
}
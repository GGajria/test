﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Security.Cryptography.X509Certificates;

namespace Redbox.OpenServices.IdentityProvider.Endpoints.Security
{
    public static class CertificateUtility
    {
        #region Methods

        public static X509Certificate2 Get(StoreName name, StoreLocation location, string subjectName)
        {
            if (String.IsNullOrWhiteSpace(subjectName))
            {
                throw new ArgumentException("No subject name was specified.", "subjectName");
            }

            X509Store store = new X509Store(name, location);
            IEnumerable<X509Certificate2> certificates = null;

            try
            {
                store.Open(OpenFlags.ReadOnly);
                certificates = store.Certificates.Cast<X509Certificate2>();

                List<X509Certificate2> matchingCertificates = (
                    from certificate in certificates
                    where certificate.SubjectName.Name.Equals(subjectName, StringComparison.OrdinalIgnoreCase)
                    select certificate
                ).ToList();

                if (matchingCertificates.Count == 0)
                {
                    throw new ApplicationException(String.Format("No certificates were found with subject name \"{0}\".", subjectName));
                }
                else if (matchingCertificates.Count > 1)
                {
                    throw new ApplicationException(String.Format("Multiple certificates were found with subject name \"{0}\".", subjectName));
                }
                else
                {
                    return new X509Certificate2(matchingCertificates[0]);
                }
            }
            catch (Exception exception)
            {
                throw new ApplicationException(String.Format("Unable to retrieve a certificate with subject name \"{0}\".", subjectName), exception);
            }
            finally
            {
                if (certificates != null)
                {
                    foreach (X509Certificate2 certificate in certificates)
                    {
                        certificate.Reset();
                    }
                }

                store.Close();
            }
        }

        public static bool TryGet(StoreName name, StoreLocation location, string subjectName, out X509Certificate2 certificate)
        {
            try
            {
                certificate = Get(name, location, subjectName);
                return true;
            }
            catch
            {
                certificate = null;
                return false;
            }
        }

        #endregion
    }
}
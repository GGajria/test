﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Redbox.OpenServices.IdentityModel
{
    public static class ClaimTypes
    {
        // Note: this constant may exist as part of the Windows Azure SDK - I have not looked.
        public const string IdentityProvider = "http://schemas.microsoft.com/accesscontrolservice/2010/07/claims/identityprovider";

        public const string WebAccountID = "http://schemas.redbox.com/ws/2010/07/claims/webaccountid";
        public const string PartnerCorrelationKey = "http://schemas.redbox.com/ws/2010/07/claims/partnercorrelationkey";
        public const string PartnerID = "http://schemas.redbox.com/ws/2010/07/claims/partnerid";
    }
}
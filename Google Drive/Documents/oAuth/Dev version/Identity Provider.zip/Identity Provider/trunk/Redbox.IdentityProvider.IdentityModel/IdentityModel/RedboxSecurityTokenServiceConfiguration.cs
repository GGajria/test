﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using Microsoft.IdentityModel.Configuration;
using Microsoft.IdentityModel.SecurityTokenService;
using Microsoft.IdentityModel.Tokens;
using Redbox.Services.WebAccountServices.Client;
using Redbox.Common.Services;

namespace Redbox.OpenServices.IdentityModel
{
    public class RedboxSecurityTokenServiceConfiguration : SecurityTokenServiceConfiguration
    {
        #region Fields

        public const string DefaultIssuerName = "CN=SIPL166-PC";
        public readonly X509EncryptingCredentials EncryptingCredentials;
        public readonly WebAccount WebAccountService;

        #endregion

        #region Constructors

        public RedboxSecurityTokenServiceConfiguration(X509Certificate2 signingCertificate)
            : this(DefaultIssuerName, signingCertificate, null)
        {
        }

        public RedboxSecurityTokenServiceConfiguration(X509Certificate2 signingCertificate, X509Certificate2 encryptingCertificate)
            : this(DefaultIssuerName, signingCertificate, encryptingCertificate)
        {
        }

        public RedboxSecurityTokenServiceConfiguration(string issuerName, X509Certificate2 signingCertificate) 
            : this(issuerName, signingCertificate, null)
        {
        }

        public RedboxSecurityTokenServiceConfiguration(string issuerName, X509Certificate2 signingCertificate, X509Certificate2 encryptingCertificate) 
            : base(issuerName, new X509SigningCredentials(signingCertificate), false)
        {
            if (encryptingCertificate != null)
            {
                EncryptingCredentials = new X509EncryptingCredentials(encryptingCertificate);
            }

            DefaultTokenType = SecurityTokenTypes.OasisWssSaml2TokenProfile11;
            SecurityTokenService = typeof(RedboxSecurityTokenService);
            //WebAccountService = ServiceLocator.Resolve<WebAccount>();
            WebAccountService = new WebAccount("http://lab01-app04/webaccountsvctr01/", int.MaxValue, ".mvc");
        }

        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;
using System.Text;
using System.Xml;
using Microsoft.IdentityModel.Claims;
using Microsoft.IdentityModel.Configuration;
using Microsoft.IdentityModel.Protocols.WSFederation.Metadata;
using Microsoft.IdentityModel.Protocols.WSIdentity;
using Microsoft.IdentityModel.SecurityTokenService;
using Microsoft.IdentityModel.Tokens;
using SecurityKeyIdentifier = System.IdentityModel.Tokens.SecurityKeyIdentifier;
using X509RawDataKeyIdentifierClause = System.IdentityModel.Tokens.X509RawDataKeyIdentifierClause;
using X509SecurityToken = System.IdentityModel.Tokens.X509SecurityToken;

namespace Redbox.OpenServices.IdentityModel
{
    public class RedboxSecurityTokenServiceFederationMetadataGenerator
    {
        #region Fields

        private readonly string _issuerName;
        private readonly X509Certificate2 _signingCertificate;
        private readonly IEnumerable<DisplayClaim> _claimsOffered;
        private readonly string _securityTokenServiceEndpoint;
        private readonly string _passiveRequestorEndpoint;

        #endregion
        
        #region Constructors

        public RedboxSecurityTokenServiceFederationMetadataGenerator(X509Certificate2 signingCertificate, IEnumerable<DisplayClaim> claimsOffered, string securityTokenServiceEndpoint, string passiveRequestorEndpoint)
            : this(RedboxSecurityTokenServiceConfiguration.DefaultIssuerName, signingCertificate, claimsOffered, securityTokenServiceEndpoint, passiveRequestorEndpoint)
        {
        }

        public RedboxSecurityTokenServiceFederationMetadataGenerator(string issuerName, X509Certificate2 signingCertificate, IEnumerable<DisplayClaim> claimsOffered, string securityTokenServiceEndpoint, string passiveRequestorEndpoint)
        {
            #region Argument Validation

            if (String.IsNullOrWhiteSpace(issuerName))
            {
                throw new ArgumentException("No value was specified for the issuer name.", "issuerName");
            }

            if (signingCertificate == null)
            {
                throw new ArgumentNullException("signingCertificate");
            }

            Uri uriToValidate;

            if (String.IsNullOrWhiteSpace(securityTokenServiceEndpoint))
            {
                throw new ArgumentException("No value was specified for the security token service endpoint.", "securityTokenServiceEndpoint");
            }

            if (!Uri.TryCreate(securityTokenServiceEndpoint, UriKind.Absolute, out uriToValidate))
            {
                throw new ArgumentException(String.Format("The value specified for the security token service endpoint, \"{0}\", does not represent a valid absolute URI.", securityTokenServiceEndpoint), "securityTokenServiceEndpoint");
            }

            if (uriToValidate.Scheme != Uri.UriSchemeHttps)
            {
                throw new ArgumentException("An HTTPS scheme is required for the security token service endpoint.", "securityTokenServiceEndpoint");
            }

            if (String.IsNullOrWhiteSpace(passiveRequestorEndpoint))
            {
                throw new ArgumentException("No value was specified for the passive requestor endpoint.", "passiveRequestorEndpoint");
            }

            if (!Uri.TryCreate(passiveRequestorEndpoint, UriKind.Absolute, out uriToValidate))
            {
                throw new ArgumentException(String.Format("The value specified for the passive requestor endpoint, \"{0}\", does not represent a valid absolute URI.", passiveRequestorEndpoint), "passiveRequestorEndpoint");
            }

            if (uriToValidate.Scheme != Uri.UriSchemeHttps)
            {
                throw new ArgumentException("An HTTPS scheme is required for the passive requestor endpoint.", "passiveRequestorEndpoint");
            } 

            #endregion

            _issuerName = issuerName;
            _signingCertificate = signingCertificate;
            _claimsOffered = claimsOffered;
            _securityTokenServiceEndpoint = securityTokenServiceEndpoint;
            _passiveRequestorEndpoint = passiveRequestorEndpoint;
        }

        #endregion

        #region Methods

        public Stream GenerateStream()
        {
            EntityDescriptor entityDescriptor = new EntityDescriptor(new EntityId(_issuerName));
            entityDescriptor.SigningCredentials = new X509SigningCredentials(_signingCertificate);
            
            SecurityTokenServiceDescriptor roleDescriptor = new SecurityTokenServiceDescriptor();
            roleDescriptor.ProtocolsSupported.Add(new Uri("http://docs.oasis-open.org/wsfed/federation/200706"));
            roleDescriptor.TokenTypesOffered.Add(new Uri(SecurityTokenTypes.OasisWssSaml2TokenProfile11));

            if (_claimsOffered != null)
            {
                _claimsOffered.ToList().ForEach(c => roleDescriptor.ClaimTypesOffered.Add(c));
            }

            roleDescriptor.SecurityTokenServiceEndpoints.Add(new EndpointAddress(_securityTokenServiceEndpoint));
            roleDescriptor.PassiveRequestorEndpoints.Add(new EndpointAddress(_passiveRequestorEndpoint));
            roleDescriptor.Keys.Add(new KeyDescriptor(new SecurityKeyIdentifier(new X509SecurityToken(_signingCertificate).CreateKeyIdentifierClause<X509RawDataKeyIdentifierClause>())));

            entityDescriptor.RoleDescriptors.Add(roleDescriptor);

            MemoryStream stream = new MemoryStream();
            XmlTextWriter writer = new XmlTextWriter(stream, Encoding.UTF8);
            MetadataSerializer serializer = new MetadataSerializer();
            serializer.WriteMetadata(writer, entityDescriptor);
            stream.Position = 0;
            
            return stream;
        }

        public string Generate()
        {
            using (StreamReader reader = new StreamReader(GenerateStream()))
            {
                return reader.ReadToEnd();
            }
        }

        #endregion
    }
}

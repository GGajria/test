﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IdentityModel.Tokens;
using System.Linq;
using System.Security.Principal;
using System.Web;
using Microsoft.IdentityModel.Claims;
using Microsoft.IdentityModel.Configuration;
using Microsoft.IdentityModel.Protocols.WSIdentity;
using Microsoft.IdentityModel.Protocols.WSTrust;
using Microsoft.IdentityModel.SecurityTokenService;
using Microsoft.IdentityModel.Tokens;
using MicrosoftClaimTypes = Microsoft.IdentityModel.Claims.ClaimTypes;
using RedboxClaimTypes = Redbox.OpenServices.IdentityModel.ClaimTypes;
using SecurityTokenTypes = Microsoft.IdentityModel.Tokens.SecurityTokenTypes;
using WebAccount = Redbox.Services.WebAccountServices.Shared.DomainObjects.WebAccount;
using Redbox.Common.Services;

namespace Redbox.OpenServices.IdentityModel
{
    public class RedboxSecurityTokenService : SecurityTokenService
    {
        #region Constructors

        public RedboxSecurityTokenService(RedboxSecurityTokenServiceConfiguration configuration) : base(configuration)
        {
        } 

        #endregion

        #region Properties

        new RedboxSecurityTokenServiceConfiguration SecurityTokenServiceConfiguration
        {
            get { return (RedboxSecurityTokenServiceConfiguration) base.SecurityTokenServiceConfiguration; }
        }

        #endregion

        #region SecurityTokenService Members

        protected override Scope GetScope(IClaimsPrincipal principal, RequestSecurityToken request)
        {
            var s = request.Context.Split('&');
            var s1 = s[2].Substring(3).Replace("%3f", "?").Replace("%3d", "=").Replace("%26", "&").Replace("%3a", ":").Replace("%2f","/").Replace("%252f","\\");
            Scope scope = new Scope
            {
                AppliesToAddress = request.AppliesTo.Uri.OriginalString,
                SigningCredentials = SecurityTokenServiceConfiguration.SigningCredentials,
                ReplyToAddress = request.AppliesTo.Uri.OriginalString + s1
            };

            

            if (SecurityTokenServiceConfiguration.EncryptingCredentials != null)
            {
                scope.EncryptingCredentials = SecurityTokenServiceConfiguration.EncryptingCredentials;
            }
            else
            {
                scope.TokenEncryptionRequired = false;
                scope.SymmetricKeyEncryptionRequired = false;
            }


            return scope;
        }

        protected override IClaimsIdentity GetOutputClaimsIdentity(IClaimsPrincipal principal, RequestSecurityToken request, Scope scope)
        {
            if (principal == null)
            {
                throw new ArgumentNullException("principal");
            }

            IClaimsIdentity incomingIdentity = principal.Identity as IClaimsIdentity;

            if (incomingIdentity == null)
            {
                throw new ArgumentNullException("principal.Identity");
            }

            Claim webAccountIdClaim = incomingIdentity.Claims.FirstOrDefault(c => c.ClaimType.Equals(RedboxClaimTypes.WebAccountID, StringComparison.OrdinalIgnoreCase));

            if (webAccountIdClaim == null)
            {
                throw new FailedRequiredClaimsException(String.Format("The {0} claim is required.", RedboxClaimTypes.WebAccountID));
            }

            int webAccountId;

            if (!Int32.TryParse(webAccountIdClaim.Value, out webAccountId))
            {
                throw new FailedRequiredClaimsException(String.Format("\"{0}\" is not a valid {1} claim value.", webAccountIdClaim.Value ?? "<NULL>", RedboxClaimTypes.WebAccountID));
            }

            WebAccount webAccount;
            ClientCommandResult result = SecurityTokenServiceConfiguration.WebAccountService.Get(webAccountId, out webAccount);

            if (webAccount == null)
            {
                throw new FailedRequiredClaimsException(String.Format("The value for the {0} claim, \"{1}\", does not represent a valid web account.", RedboxClaimTypes.WebAccountID, webAccountIdClaim.Value));
            }

            IClaimsIdentity outgoingClaimsIdentity = new ClaimsIdentity(
                new List<Claim>
                {
                    new Claim(MicrosoftClaimTypes.NameIdentifier, webAccount.WebAccountID.ToString()),
                    //new Claim(MicrosoftClaimTypes.Name, (webAccount.Personalization.Attributes["FirstName"] ?? String.Empty + webAccount.Personalization.Attributes["LastName"] ?? String.Empty).Trim()),
                    new Claim(MicrosoftClaimTypes.Email, webAccount.EmailAddress)
                }
            );

            return outgoingClaimsIdentity;
        }

        #endregion
    }
}
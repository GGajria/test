﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Redbox.AuthServer.Models;

namespace Redbox.AuthServer.Helper
{
    public class DBRepository
    {
        /// <summary>
        /// Find the application for the given client id
        /// </summary>
        /// <param name="clientId">Client Id value</param>
        public ClientApplication findApplication(string clientId)
        {
            return new ClientApplication();
        }

        public UserGrant findGrant(string userId, ClientApplication app)
        {
            return new UserGrant();
        }

        public void SaveGrant(string userId, string application, string permission)
        {
            //save the grant object into the DB
        }

        public void AuditGrant(string userId, string p, string p_2)
        {
            //log the user grant
        }

        public class ClientApplication
        {

            public bool ExemptFromGrant { get; set; }
        }

        public class UserGrant
        {
            public bool Granted { get; set; }
            public bool Approved { get; set; }
            public DateTime ExpiresOn { get; set; }
        }
    }
}
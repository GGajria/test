﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;


namespace Redbox.AuthServer
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

    public class MvcApplication : System.Web.HttpApplication
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }

        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            //route mapping for perm request form
            routes.MapRoute("GetForm",
                "v1/permission",
                new { controller = "Auth", action = "GetForm", scope = UrlParameter.Optional, state = UrlParameter.Optional },
                //new { httpMethod = new HttpMethodConstraint("GET") },
                new string[] { "Redbox.AuthServer.Controllers" });
                //new { controller = "Auth", action = "GetForm", redirect_uri = (string)null, scope = (string)null, state = (string)null, request_type = (string)null, requestvalidationtoken = (string)null });

            //AS2: Process the Permission Form
            //POST: /Auth/PostForm
            //      /v1/permission
            routes.MapRoute("ProcessForm",
                "v1/permission/",
                new { controller = "Auth", action = "PostForm" },
                new { httpMethod = new HttpMethodConstraint("POST") });


            //AS3: Authorize SAML token
            //POST: /Auth/AuthorizeSaml
            //      /v1/authorizeSAML

            routes.MapRoute("AuthorizeSAMLToken",
                "v1/authorizeSAML",
                new { controller = "Auth", action = "AuthorizeSaml" });
            
            //AS4: Authorize refresh
            //GET: /Auth/AuthorizeRefresh
            //     /v1/authorizeRefresh?client_id={client_id}&customer_number={customer_number}&scope={scope}&requestvalidationtoken={requestvalidationtoken}

            routes.MapRoute("AuthorizeRefresh",
                "v1/authorizeRefresh",
                new { controller = "Auth", action = "AuthorizeRefresh",scope = UrlParameter.Optional});
                
            

            //default mapping
            routes.MapRoute(
                "Default", // Route name
                "{controller}/{action}/{id}", // URL with parameters
                new { controller = "Home", action = "Index", id = UrlParameter.Optional }, // Parameter defaults
                new string[] { "Redbox.AuthServer.Controllers" } 
            );

        }

        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();

            RegisterGlobalFilters(GlobalFilters.Filters);
            RegisterRoutes(RouteTable.Routes);
        }
    }
}
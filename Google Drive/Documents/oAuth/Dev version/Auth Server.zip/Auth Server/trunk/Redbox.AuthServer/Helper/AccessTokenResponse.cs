﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace Redbox.AuthServer.Helper
{
    [XmlRoot("AccessTokenResponse", Namespace = "http://oauth2.redbox.com/v1/Authorization")]
    public class AccessTokenResponse
    {
        [XmlElement("access_token")]
        public string AccessToken { get; set; }
        [XmlElement("token_type")]
        public string TokenType { get; set; }
        [XmlElement("expires_in")]
        public string ExpiresIn { get; set; }
        [XmlElement("refresh_token")]
        public string RefreshToken { get; set; }
        [XmlElement("scope")]
        public string Scope { get; set; }
        [XmlElement("customer_number")]
        public string CustomerNumber { get; set; }
    }
}
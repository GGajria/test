﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Redbox.AuthServer.Models.Entity
{
    public class AffiliateApplication
    {
        public virtual int AffiliateApplicationId { get; set; }
        public virtual int AffiliateId { get; set; }
        public virtual string ApplicationName { get; set; }
        public virtual string Description { get; set; }
        public virtual string EffectiveDate { get; set; }
        public virtual string ExpirationDate { get; set; }
        public virtual string ConsentPreApprovalFlag { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Redbox.AuthServer.Models
{
    //auth view model
    public class Auth
    {
        public string client_id { get; set; }
        public string rurl { get; set; }
        public string scope { get; set; }
        public string state { get; set; }
        public string type { get; set; }
        public string rvt { get; set; }
        public string timeStamp { get; set; }
        public string formSignature { get; set; }
        public string permissionResult { get; set; }

    }

   
}
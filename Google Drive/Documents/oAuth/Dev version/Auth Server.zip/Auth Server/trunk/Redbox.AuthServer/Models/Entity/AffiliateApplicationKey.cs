﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Redbox.AuthServer.Models.Entity
{
    public class AffiliateApplicationKey
    {
        public virtual int AffiliateApplicationKeyId { get; set; }
        public virtual int ApplicationId { get; set; }
        public virtual string ApigeeKey { get; set; }
        public virtual int DeviceType { get; set; }
    }   
}
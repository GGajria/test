﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.IO;
using System.Text;
using System.Security.Cryptography;
using System.Configuration;
using System.Xml.Serialization;
using System.Runtime.Serialization.Json;

namespace Redbox.AuthServer.Helper
{
    public class Generic
    {
        /// <summary>
        /// Creates a web request
        /// </summary>
        /// <param name="url">URL to hit</param>
        /// <param name="method">HTTP method(GET, POST)</param>
        /// <param name="contentType">Content type of the request body</param>
        /// <param name="requestBody">Request body</param>
        /// <param name="response">Response body</param>
        /// <returns>Status code of the call</returns>
        public static int webRequest(string url, string method, string contentType, string requestBody, out string response)
        {
            HttpWebRequest request = WebRequest.Create(url) as HttpWebRequest;

            if (!String.IsNullOrEmpty(method))
                request.Method = method;
            
            //set the timeout here
            request.Timeout = int.MaxValue;

            if (!String.IsNullOrEmpty(requestBody))
            {
                //set the content type here
                request.ContentType = contentType;
                request.ContentLength = requestBody.Length;
                
                //request body being attached
                using (Stream reqStream = request.GetRequestStream())
                {
                    var bytes = Encoding.Default.GetBytes(requestBody);
                    reqStream.Write(bytes, 0, bytes.Length);
                    reqStream.Close();
                }
            }
            try
            {
                using (HttpWebResponse result = request.GetResponse() as HttpWebResponse)
                {
                    //response stream being read
                    using (Stream resStream = result.GetResponseStream())
                    {
                        StreamReader sr = new StreamReader(resStream);
                        response = sr.ReadToEnd();
                    }
                    return (int)result.StatusCode;
                }
            }
            catch (Exception)
            {
                throw;
            }

        }

        /// <summary>
        /// Get a SHA256 hash 
        /// </summary>
        /// <param name="input">String to be hashed</param>
        /// <returns>Hash Value</returns>
        public static string getSHA256Hash(string input)
        {
            HMAC a = HMACSHA256.Create();
            a.Key = Encoding.Default.GetBytes(ConfigurationManager.AppSettings["SHAHashKey"]);
            MemoryStream ms = convertToStream(input, Encoding.Default);
            var hashValue = a.ComputeHash(ms);
            return Encoding.Default.GetString(hashValue);
        }

        /// <summary>
        /// Convert the given string into a memory stream
        /// </summary>
        /// <param name="input">String to convert</param>
        /// <param name="encodingScheme">Encoding scheme to use</param>
        /// <returns>The memory stream</returns>
        public static MemoryStream convertToStream(string input, Encoding encodingScheme)
        {
            MemoryStream ms = new MemoryStream();
            var bytes = encodingScheme.GetBytes(input);
            ms.Write(bytes, 0, bytes.Length);
            return ms;
        }

        /// <summary>
        /// Deserializes XML string back into object
        /// </summary>
        /// <typeparam name="T">Type of object</typeparam>
        /// <param name="xml">XML string</param>
        /// <returns>The deserialized object (needs to be type cast)</returns>
        public static object deserializeXML<T>(string xml)
        {
            MemoryStream stream = new MemoryStream();
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(xml);
            stream.Write(bytes, 0, bytes.Length);
            stream.Seek(0, 0);
            XmlSerializer ser = new XmlSerializer(typeof(T));
            return (T)ser.Deserialize(stream);
        }

        /// <summary>
        /// Serialize XML object into a string
        /// </summary>
        /// <typeparam name="T">Type of the Object</typeparam>
        /// <param name="o">XML Object</param>
        /// <returns>Serialized XML string</returns>
        public static string serializeXML<T>(Object o)
        {
            XmlSerializer Ser = new XmlSerializer(typeof(T));
            StringWriter Writer = new StringWriter(new StringBuilder());
            Ser.Serialize(Writer, (T)o);
            return Writer.ToString();
        }

        public static object deserializeJSON<T>(string json)
        {
            DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(T));
            MemoryStream stream = new MemoryStream();
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(json);
            stream.Write(bytes, 0, bytes.Length);
            stream.Seek(0, 0);
            return serializer.ReadObject(stream);
        }
        
    }
}
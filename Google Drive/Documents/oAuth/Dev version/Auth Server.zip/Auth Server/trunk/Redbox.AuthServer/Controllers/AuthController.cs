﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Configuration;
using Redbox.AuthServer.Models;
using Redbox.AuthServer.Helper;

namespace Redbox.AuthServer.Controllers
{
    [ValidateInput(false)]
    public class AuthController : Controller
    {

        // AS1: Get the Permissions Page
        // GET: /Auth/GetForm
        //      /v1/permission?client_id={client_id}&redirect_uri={redirect_uri}&scope={scope}&state={state}&request_type={request_type}&requestvalidationtoken={requestvalidationtoken}

        [Authorize]
        public ActionResult GetForm(string client_id, string redirect_uri, string scope, string state, string request_type, string requestvalidationtoken)
        {


            /*
            //call Apigee AV1
            var validation = WebRequest("ApigeeAV1");
            
            //if bad request throw it out
            if (validation == 400)
                HttpContext.Response.StatusCode = 400;

            //get the application and user grants from the DB
            var UserId = Page.User.Name;
            var App = db.FindApplicaionByClientId(client_id);
            var UserGrant = db.FindGrant(UserId, App);

            var userGrantExists = false;
            if (UserGrant != null && UserGrant.Approved == true && UserGrant.ExpiresOn > Now()){
                userGrantExists = true;
            }

             
            //if exempt from permission or already granted
            if (App.IsExemptFromGrant || userGrantExists)
                IssueToken();
            else
            {
                Timestamp = Now();
                FormSignature = SHA256 Hash of (Client_id, Request_Type, Redirect_URI, 	Scope, State, Timestamp);
                Anti-RequestForgeryToken = provided by ASP.NET MVC
                Render Permission View();
            }
           */

            //get the userId
            
            string response;
            //make a call to AV1
            int status = Generic.webRequest(ConfigurationManager.AppSettings["AV1"], "GET", null, null, out response);
            if (status == 200)
            {
                var db = new DBRepository();
                var userId = HttpContext.User.Identity.Name;
                var app = db.findApplication(client_id); 
                var user = db.findGrant(userId, app);
                
                //timestamp 
                var time = DateTime.Now.ToString();
                bool userGrantExists = false; 
                if (user != null && user.Granted && user.ExpiresOn > DateTime.UtcNow)
                {
                    userGrantExists = true;
                }
                
                if (userGrantExists && app.ExemptFromGrant)
                {
                    var impl = new Impl();
                    impl.IssueToken(redirect_uri, request_type, scope, state, userGrantExists && app.ExemptFromGrant);
                    return null;
                }
                else
                {
                    var signature = Generic.getSHA256Hash(client_id + request_type + redirect_uri + scope + state + time);
                    var auth = new Auth()
                    {
                        client_id = client_id,
                        rurl = redirect_uri,
                        rvt = requestvalidationtoken,
                        scope = scope,
                        state = state,
                        type = request_type,
                        timeStamp = time,
                        formSignature = signature
                    };
                    return View("PermissionsPage", auth);
                    
                }
            }
            else
            {//failed from AV1
                HttpContext.Response.StatusCode = 400;
                return null;
            }
        }


        //AS2: Process the Permission Form
        //POST: /Auth/PostForm
        //      /v1/permission
        [HttpPost]
        [ValidateAntiForgeryToken]
        public void PostForm(Auth model)
        {
            /*
            //ASP.NET MVC will validate the Anti-RequestForgeryToken before the page loads
            // Validate that hidden parameters have not been tampered with by recomputing the form signature.
            var ThisFormSignature = SHA256 Hash of (Client_id, Request_Type, Redirect_URI, Scope, State, Timestamp);

            //Validate the signature
            if (ThisFormSignature != model.formsignature){
                log("warning");
                // Per section 4.2.2.1 of OAuth2.0 spec Draft 13
                if (model.type == "token") 
                { 
	                HttpContext.Response.StatusCode = 302;
                    return null;
                }
		        // Per section 4.1.2.1
                else
                {
                    HttpContext.Response.StatusCode = 302;
                    return null;
                }
            }
		    
            // Validate that the form was rendered recently – to protect against replay
            if (DateTime.Now – model.timestamp > Convert.ToInt64(ConfigurationManager.AppSettings["TimeLimit"]))  // time limit from configuration
            {
                log("warning");
                // Per section 4.2.2.1 of OAuth2.0 spec Draft 13
                if (model.type == "token")
                {
                    HttpContext.Response.StatusCode = 302;
                    return null;
                }
		        // Per section 4.1.2.1
                else// request_type is Code
                {
                    HttpContext.Response.StatusCode = 302;
                    return null;
                }
		    }

            //Validate the user action
            if (model.permissionResult == false)
            {
	            log("INFO");
	            // Per section 4.2.2.1 of OAuth2.0 spec Draft 13
                if (model.type == "token")
                {
                    HttpContext.Response.StatusCode = 302;
                    return null;
                }
		        // Per section 4.1.2.1
                else// request_type is Code
                {
                    HttpContext.Response.StatusCode = 302;
                    return null;
                }
            }
            //All validations passed

            //get the app
            var App = db.FindApplicaionByClientId(client_id);

            //get the userid
            var UserId = Page.User.Name;

            //save the grant in db
            grant = new UserGrant(userId, App, permissionResult);
            db.SaveGrant(grant);

            //perform required auditing
            Audit Grant;
            */

            var calcHash = Generic.getSHA256Hash(model.client_id + model.client_id + model.rurl + model.scope + model.state + model.timeStamp);
            
            //Validate the signature 
            if (model.formSignature != calcHash)
            {
                //log("warning");
                Response.RedirectLocation = model.rurl + "#error=access_denied";
                Response.StatusCode = 302;
                return;
            }

            var diff = (DateTime.Now - DateTime.Parse(model.timeStamp)).Milliseconds;

            //Validate that the form was rendered recently – to protect against replay
            if ( diff > Convert.ToInt32(ConfigurationManager.AppSettings["TimeLimit"]))  
            {
                //log("warning");
                Response.RedirectLocation = model.rurl + "#error=access_denied";
                Response.StatusCode = 302;
                return;
		    }

            //Validate the user action
            if (Convert.ToBoolean(model.permissionResult) == false)
            {
                //log("INFO");
                Response.RedirectLocation = model.rurl + "#error=access_denied";
                Response.StatusCode = 302;
                return;
            }

            //get the app
            var db = new DBRepository();
            var app = db.findApplication(model.client_id);
            var userId = HttpContext.User.Identity.Name;

            //save the grant in db
            db.SaveGrant(userId, app.ToString(), model.permissionResult );

            //perform required auditing
            db.AuditGrant(userId, app.ToString(), model.permissionResult);

        }

        //AS3: Authorize SAML token
        //POST: /Auth/AuthorizeSaml
        //      /v1/authorizeSAML
        [HttpPost]
        public void AuthorizeSaml()
        {
            /*
            Validaition = Make REST WS call to Apigee AV1 (requestvalidationtoken, requestingclient_id=client_id, and the client_id & secret of the Permissions Page)

            IF (validation = 400)
            THEN
	            Return 400 – Unrecognized request

            // Validate SAML request per OAuth SAML Bearer Tokens spec

            IF (SAML is INVALID)
            THEN
	            LOG WARN
	            Return 400

            // Create New AuthorizationResult
            authResult = new AuthorizationResult();
            authResult.Authorization.authorized = true;
            authResult.Authorization.authorizedBy = ‘user’;
            authResult.Authorization.refreshAllowed = false;
            etc….
            authResult.AuthorizationContext.UserIdentity.CustomerNumber = subject from SAML token;
            // map each attribute assertion in SAML into Claims 
            etc…

            Return HTTP 200 with authResult as payload
             
             */

            var auth = new Impl().getDummyAuthResult();

            XmlResult result = new XmlResult(auth);
            result.ExecuteResult(this.ControllerContext);




        }


        //AS4: Authorize refresh
        //GET: /Auth/AuthorizeRefresh
        //     /v1/authorizeRefresh?client_id={client_id}&customer_number={customer_number}&scope={scope}&requestvalidationtoken={requestvalidationtoken}
        [HttpGet]
        [ValidateInput(false)]
        public void AuthorizeRefresh(string client_id, string customer_number, string scope, string requestvalidationtoken)
        {
            /*
            Validaition = Make REST WS call to Apigee AV1 (requestvalidationtoken, requestingclient_id=client_id, and the client_id & secret of the Permissions Page)

            IF (validation = 400)
            THEN
	            Return 400 – Unrecognized request

            // Retrieve User-Grant from repository
            Grant = db.FindGrantByUserAndApp(customer_number, client_id)

            IF (Grant == NULL)
            THEN
	            Bool authorized = false;
            ELSE
	            authorized = Grant.Authorized;

            // Create New AuthorizationResult
            authResult = new AuthorizationResult();
            authResult.Authorization.authorized = authorized;
            authResult.Authorization.authorizedBy = ‘user’;
            etc….
            authResult.AuthorizationContext.UserIdentity.CustomerNumber = customer_number;

            Return HTTP 200 with authResult as payload
             * */
            var auth = new Impl().getDummyAuthResult();

            XmlResult result = new XmlResult(auth);
            result.ExecuteResult(this.ControllerContext);
        }


    }
}

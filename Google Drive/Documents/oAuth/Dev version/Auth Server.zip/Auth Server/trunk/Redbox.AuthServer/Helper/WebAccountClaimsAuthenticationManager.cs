﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.IdentityModel.Claims;
using Redbox.IdentityModel;
using Redbox.Services.WebAccountServices.Shared.DomainObjects;
using MicrosoftClaimTypes = Microsoft.IdentityModel.Claims.ClaimTypes;
using RedboxClaimTypes = Redbox.IdentityModel.ClaimTypes;

namespace Redbox.AuthServer.Helper
{
    public class WebAccountClaimsAuthenticationManager : ClaimsAuthenticationManager
    {
        #region ClaimsAuthenticationManager Members

        /*public override IClaimsPrincipal Authenticate(string resourceName, IClaimsPrincipal incomingPrincipal)
        {
            if (incomingPrincipal == null)
            {
                throw new ArgumentNullException("incomingPrincipal");
            }

            IClaimsPrincipal outgoingPrincipal;
            IEnumerable<Claim> incomingClaims = GetIncomingClaims(incomingPrincipal);
            IEnumerable<Claim> outgoingClaims = TransformClaims(incomingClaims);

            if (outgoingClaims.Count() > 0)
            {
                outgoingPrincipal = new ClaimsPrincipal(new List<IClaimsIdentity> { new ClaimsIdentity(outgoingClaims) });
            }
            else
            {
                outgoingPrincipal = ClaimsPrincipal.AnonymousPrincipal;
            }

            return outgoingPrincipal;
        }

        #endregion

        #region Helper Methods

        private IEnumerable<Claim> GetIncomingClaims(IClaimsPrincipal incomingPrincipal)
        {
            if (incomingPrincipal.Identity.IsAuthenticated)
            {
                IClaimsIdentity identity = incomingPrincipal.Identity as IClaimsIdentity;

                if (identity != null)
                {
                    return identity.Claims;
                }
            }
                
            return new List<Claim>();
        }

        private IEnumerable<Claim> TransformClaims(IEnumerable<Claim> incomingClaims)
        {
            List<Claim> outgoingClaims = new List<Claim>();
            Claim identityProvider = incomingClaims.FirstOrDefault(c => c.ClaimType.Equals(RedboxClaimTypes.IdentityProvider, StringComparison.OrdinalIgnoreCase));
            Claim nameIdentifier = incomingClaims.FirstOrDefault(c => c.ClaimType.Equals(MicrosoftClaimTypes.NameIdentifier, StringComparison.OrdinalIgnoreCase));

            if ((identityProvider != null) && (nameIdentifier != null))
            {
                WebAccount webAccount = ResolveWebAccount(identityProvider.Value, nameIdentifier.Value);

                if (webAccount != null)
                {
                    // Establish web account id claim
                    outgoingClaims.Add(new Claim(RedboxClaimTypes.WebAccountID, webAccount.WebAccountID.ToString()));

                    // Establish role claims
                    webAccount.Roles.ForEach(role => outgoingClaims.Add(new Claim(MicrosoftClaimTypes.Role, role)));

                    // Transform name claim into given name claim
                    Claim name = incomingClaims.FirstOrDefault(c => c.ClaimType.Equals(MicrosoftClaimTypes.Name, StringComparison.OrdinalIgnoreCase));
                    if (name != null)
                    {
                        outgoingClaims.Add(new Claim(MicrosoftClaimTypes.GivenName, name.Value));
                    }

                    // Pass through email claim
                    Claim email = incomingClaims.FirstOrDefault(c => c.ClaimType.Equals(MicrosoftClaimTypes.Email, StringComparison.OrdinalIgnoreCase));
                    if (email != null)
                    {
                        outgoingClaims.Add(email);
                    }

                    // Additional provider-specific claim transformations
                    if (identityProvider.Value == OriginalIssuers.Verizon)
                    {
                        // TODO: Transform identity provider claim into partner id claim using Customer Profile API (Redbox.IdentityModel.ClaimTypes.PartnerID)
                        // TODO: Transform web account id into correlation key claim using Customer Profile API (Redbox.IdentityModel.ClaimTypes.PartnerCorrelationKey)
                    }
                }
            }

            return outgoingClaims;
        }

        private WebAccount ResolveWebAccount(string identityProvider, string nameIdentifier)
        {
            WebAccount webAccount = null;
            var service = new Redbox.Services.WebAccountServices.Client.WebAccount("http://lab01-app04/webaccountsvctr01/", 600000, ".mvc");
            Redbox.Services.WebAccountServices.Shared.Enums.WebAccountCreateResult result;

            if (identityProvider.Equals(RedboxSecurityTokenServiceConfiguration.DefaultIssuerName, StringComparison.OrdinalIgnoreCase))
            {
                int webAccountId;

                if (Int32.TryParse(nameIdentifier, out webAccountId))
                {

                    ServiceResult<WebAccount> result = service.Get(webAccountId);

                    if (result.Success)
                    {
                        webAccount = result.Data;
                    }
                }
            }
            else
            {
                // TODO: resolve web account using Customer Profile API. Web account is hardcoded below for POC
                ServiceResult<WebAccount> pocResult = service.Get(2074591);

                if (pocResult.Success)
                {
                    webAccount = pocResult.Data;
                }
            }

            return webAccount;
        }
        */
        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Redbox.AuthServer.Helper
{
    using System.Linq;
    using System.IdentityModel.Tokens;
    using Microsoft.IdentityModel.Tokens;
    using System.Xml.Linq;
    using System.Collections.Generic;


    public class TrustedIssuerNameRegistry : IssuerNameRegistry
    {
        public override string GetIssuerName(SecurityToken securityToken)
        {
            
            X509SecurityToken x509Token = securityToken as X509SecurityToken;
            return x509Token.Certificate.SubjectName.Name;
            //if (x509Token != null)
            //{
            //    XElement root = XElement.Load(Constants.TrustedIssuersStorePath);
            //    IEnumerable<XElement> entry =
            //        from el in root.Elements("Issuer")
            //        where (string)el.Attribute("SubjectName") == x509Token.Certificate.SubjectName.Name
            //        select el;
            //    if (entry.Count() != 0)
            //    {
            //        return x509Token.Certificate.SubjectName.Name;
            //    }
            //}

            //throw new SecurityTokenException("Untrusted issuer.: " + x509Token.Certificate.SubjectName.Name);
        }
    }
}
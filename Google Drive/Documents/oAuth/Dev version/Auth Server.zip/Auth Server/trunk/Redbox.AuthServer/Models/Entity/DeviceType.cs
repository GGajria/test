﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Redbox.AuthServer.Models.Entity
{
    public class DeviceType
    {
        public virtual int DeviceTypeId { get; set; }
        public virtual string DeviceName { get; set; }
        public virtual string Description { get; set; }
    }
}
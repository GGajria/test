﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Redbox.AuthServer.Models.Entity
{
    public class Affiliate
    {
        public virtual int AffiliateId { get; set; }
        public virtual string AffiliateName { get; set; }
        public virtual string ContactName { get; set; }
        public virtual string ContactEmail { get; set; }
        public virtual string ContactPhone { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Redbox.AuthServer.Helper
{
    public static class OriginalIssuers
    {
        public const string Redbox = "Redbox";
        public const string Verizon = "Verizon";
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Redbox.AuthServer.Models.Entity
{
    public class Scope
    {
        public virtual int ScopeId { get; set; }
        public virtual string ScopeName { get; set; }
        public virtual string Description { get; set; }
        public virtual string Visible { get; set; }
    }
}
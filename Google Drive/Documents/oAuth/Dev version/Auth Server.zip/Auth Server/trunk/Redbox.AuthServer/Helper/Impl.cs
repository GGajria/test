﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Web;
using System.Xml.Serialization;

namespace Redbox.AuthServer.Helper
{
    public class Impl
    {
        public void IssueToken(string redirectTo, string requestType, string scope, string state,bool authorization)
        {
            /*IF (authorization == false)
            THEN
	            LOG INFO
	            IF (request_type = ‘token’) 
	            THEN
		            Return error code “access_denied” in HTTP302 
		            // Per section 4.2.2.1 of OAuth2.0 spec Draft 13
	            ELSE // request_type is Code
		            Return errorcode = “access_denied” in HTTP302
		            // Per section 4.1.2.1

            //ELSE
            // Create New AuthorizationResult
            authResult = new AuthorizationResult();
            authResult.Authorization.authorized = authorization;
            etc…

            IF (request_type == ‘code’)
            result = Call REST WS to AV3 (getting back a xml object)
            // render result as HTTP302 to redirect_uri
            // Per Section 4.1.2


            IF (request_type == ‘token’)
            result = Call REST WS to AV2 (getting back an json object)
            // render as HTTP302 to redirect_uri
            // Per Section 4.2.2 of OAuth2.0 spec Draft 13
             * */

            if (authorization == false)
            {
                HttpContext.Current.Response.RedirectLocation = redirectTo + "#error=access_denied";
                HttpContext.Current.Response.StatusCode = 302;
            }

            
            if (requestType == "code")
            {
                string body = "";
                string response = "";
                int status = Generic.webRequest(ConfigurationManager.AppSettings["AV3"], "POST", "application/x-www-form-urlencoded", body, out response);
                if (status == 200)
                {
                    var authCode = (AuthCode)Generic.deserializeXML<AuthCode>(response);
                    var redirectUrl = String.Format("{0}?code={1}", authCode.RedirectUrl, authCode.AuthCodeValue);
                    HttpContext.Current.Response.RedirectLocation = redirectUrl;
                    HttpContext.Current.Response.StatusCode = 302;
                }
            }
            else
            {
                string body = "";
                string response = ""; ;
                int status = Generic.webRequest(ConfigurationManager.AppSettings["AV2"], "POST", "application/x-www-form-urlencoded", body, out response);
                if (status == 200)
                {
                    var token = (AccessTokenResponse)Generic.deserializeJSON<AccessTokenResponse>(response);
                    var redirectUrl = String.Format("{0}#access_token={1}&token_type={2}&expires_in={3}", 
                                                     redirectTo,
                                                     token.AccessToken,
                                                     token.TokenType,
                                                     token.RefreshToken);
                    HttpContext.Current.Response.RedirectLocation = redirectUrl;
                    HttpContext.Current.Response.StatusCode = 302;
                }
            }




        }


        /// <summary>
        /// Generates a hardcoded sample AuthorizationResult
        /// </summary>
        /// <returns></returns>
        public AuthorizationResult getDummyAuthResult()
        {
            var auth = new AuthorizationResult();

            //Authorization
            auth.Authorization = new Authorization();
            auth.Authorization.authorizationEffectiveInstant = DateTime.Now.ToLongTimeString();
            auth.Authorization.authorizedBy = "User";
            auth.Authorization.authorized = "true";
            auth.Authorization.extensions = String.Empty;
            auth.Authorization.refreshAllowed = "false";
            auth.Authorization.refreshCount = "0";
            auth.Authorization.refreshTokenLifetime = "P396DT1H1M1S";
            auth.Authorization.scopeAuthorized = "scopesAuthorized1";
            auth.Authorization.tokenExpiresOn = DateTime.Now.AddDays(3).ToLongTimeString();
            auth.Authorization.tokenLifetime = "P396DT1H1M1S";

            //AuthorizationContext
            auth.AuthorizationContext = new Redbox.AuthServer.Helper.AuthorizationContext1();
            auth.AuthorizationContext.extensions = String.Empty;
            auth.AuthorizationContext.redirect_uri = "someuri";
            auth.AuthorizationContext.requestedTokenType = "code";
            auth.AuthorizationContext.requestingClientId = "clientId";
            auth.AuthorizationContext.scopesRequested = "scope";
            auth.AuthorizationContext.state = "state";

            auth.AuthorizationContext.UserIdentity = new UserIdentity();
            auth.AuthorizationContext.UserIdentity.customerNumber = "234234234";
            auth.AuthorizationContext.UserIdentity.extensions = String.Empty; 

            //Claims
            auth.AuthorizationContext.UserIdentity.Claims = new List<AuthorizationClaim>();
            auth.AuthorizationContext.UserIdentity.Claims.Add(new AuthorizationClaim() { name = "name1", value = "value1" });
            auth.AuthorizationContext.UserIdentity.Claims.Add(new AuthorizationClaim() { name = "name2", value = "value2" });
            return auth;
        }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Redbox.AuthServer.Models.Entity
{
    public class UserConsentAudit
    {
        public virtual UserConsentAuditId UserConsentAuditId { get; set; }
        public virtual int Granted { get; set; }
        public virtual int AuditDate { get; set; }
    }

    [Serializable]
    public class UserConsentAuditId
    {
        public virtual long UserId { get; set; }
        public virtual long ApplicationId { get; set; }
        
        //to match equality (required by nHibernate)
        public override bool Equals(object obj)
        {
            UserConsentAuditId a = obj as UserConsentAuditId;
            if ((UserId == a.UserId) &&
                 (ApplicationId == a.ApplicationId)
                )
            {
                return true;
            }
            else
                return false;
        }

        //return hashcode (required by nHibernate)
        public override int GetHashCode()
        {
            return (this.UserId.ToString() + "|" +
                    this.ApplicationId.ToString()).GetHashCode();
        }
    }
}
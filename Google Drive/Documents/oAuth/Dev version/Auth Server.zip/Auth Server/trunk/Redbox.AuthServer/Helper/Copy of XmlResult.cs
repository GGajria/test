﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.IdentityModel.Web;
using Microsoft.IdentityModel.Protocols.WSFederation;

namespace Redbox.AuthServer.Helper
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public sealed class AuthenticateAndAuthorizeAttribute1 :
                           FilterAttribute, IAuthorizationFilter
    {
        // ...

        public void OnAuthorization(AuthorizationContext filterContext)
        {


            if (!filterContext.HttpContext.User.Identity.IsAuthenticated)
            {
                AuthenticateUser(filterContext);
            }
            else
            {
                this.AuthorizeUser(filterContext);
            }

            // ...
        }
        private static void AuthenticateUser(AuthorizationContext context)
        {
                var returnUrl = context.RequestContext.HttpContext.Request.Url;

                var fam =
                    FederatedAuthentication.WSFederationAuthenticationModule;

                var signIn =
                    new SignInRequestMessage(new Uri(fam.Issuer), fam.Realm)
                    {
                        Context = returnUrl.ToString(),
                        HomeRealm = context.RequestContext.HttpContext.Request.UserHostName
                    };

                context.Result =
                              new RedirectResult(signIn.WriteQueryString());
            }
        
        private void AuthorizeUser(AuthorizationContext context)
        {
            if (HttpContext.Current.User.Identity.IsAuthenticated)
            {
                var s = HttpContext.Current.User.Identity.Name;
            }
    return;


        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace Redbox.AuthServer.Helper
{
    [XmlRoot("AuthCode", Namespace = "http://oauth2.redbox.com/v1/Authorization")]
    public class AuthCode 
    {
        [XmlElement("authCode")]
        public string AuthCodeValue { get; set; }
        [XmlElement("redirectUrl")]
        public string RedirectUrl { get; set; }

    }
}
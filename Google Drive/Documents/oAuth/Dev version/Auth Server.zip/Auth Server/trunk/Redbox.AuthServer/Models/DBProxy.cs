﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NHibernate.Cfg;
using NHibernate;

namespace Redbox.AuthServer.Models
{
    public class DBProxy
    {        
        #region privateMembers

        /// <summary>
        /// Holds instance for nhibernate environment
        /// </summary>
        static Configuration environmentCfg = null;

        /// <summary>
        /// Holds valid session for executing querry or store procedure against
        /// </summary>
        static ISessionFactory sessionFactory = null;

        /// <summary>
        /// Contructor to initialise the configuration environment of nhibernate
        /// </summary>
        #region Constructors

        public DBProxy()
        {
            environmentCfg = new Configuration();
            environmentCfg.AddAssembly(typeof(Models.Entity.Affiliate).Assembly);
            environmentCfg.Configure();
        }

        #endregion

        /// <summary>
        /// Creating a session object to execute the querry with respect to the initialised configuration
        /// </summary>
        /// <returns>ISessionFactory</returns>
        public static ISessionFactory createSession()
        {
            if (environmentCfg != null)
            {
                return environmentCfg.BuildSessionFactory();
            }
            return null;
        }

        /// <summary>
        /// returns a session factory
        /// </summary>
        /// <returns>ISession</returns>
        private static ISession CheckSessionFactory()
        {
            if (sessionFactory == null)
                sessionFactory = createSession();
            if (sessionFactory != null)
            {
                ISession session = sessionFactory.OpenSession();
                return session;
            }
            return null;
        }

        #endregion

        #region publicMembers

        #endregion
    }
}
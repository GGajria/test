﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Redbox.AuthServer.Models.Entity
{
    public class UserConsent
    {
        public virtual int UserConsentId { get; set; }
        public virtual int UserId { get; set; }
        public virtual int ApplicationId { get; set; }
        public virtual string Granted { get; set; }
    }
}
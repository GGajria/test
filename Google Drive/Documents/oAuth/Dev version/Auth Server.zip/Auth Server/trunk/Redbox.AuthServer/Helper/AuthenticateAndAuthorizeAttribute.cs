﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.IdentityModel.Web;
using Microsoft.IdentityModel.Protocols.WSFederation;

namespace Redbox.AuthServer.Helper
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public sealed class AuthenticateAndAuthorizeAttribute :
                           FilterAttribute, IAuthorizationFilter
    {
        // ...

        public void OnAuthorization(AuthorizationContext filterContext)
        {
            if (!filterContext.HttpContext.User.Identity.IsAuthenticated)
            {
                AuthenticateUser(filterContext);
            }
            else
            {
                this.AuthorizeUser(filterContext);
            }

            // ...
        }
        private static void AuthenticateUser(AuthorizationContext context)
        {


            var returnUrl = context.RequestContext.HttpContext.Request.Url;

            var fam =
                FederatedAuthentication.WSFederationAuthenticationModule;

            var signIn =
                new SignInRequestMessage(new Uri(fam.Issuer), fam.Realm)
                {
                    Context = returnUrl.ToString(),
                    HomeRealm = context.RequestContext.HttpContext.Request.UserHostName
                };

            context.Result =
                          new RedirectResult(signIn.WriteQueryString());

        }


        private void AuthorizeUser(AuthorizationContext context)
        {
            if (context.RequestContext.HttpContext.User.Identity.IsAuthenticated)
            {
                var s = context.RequestContext.HttpContext.User.Identity.Name;
            }
        }
    }
}
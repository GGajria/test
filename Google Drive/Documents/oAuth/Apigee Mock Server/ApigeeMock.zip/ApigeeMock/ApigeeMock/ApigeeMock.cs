﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel.Activation;
using System.IO;

namespace ApigeeMock
{
    
    [AspNetCompatibilityRequirements(RequirementsMode=AspNetCompatibilityRequirementsMode.Allowed)]
    public class ApigeeMock : IApigeeMock
    {

        public ValidationTokenResponse Validate(string rvt, string rcid, string client_id, string client_secret)
        {
            return null;
        }

        public AccessTokenResponse TokenApproval(string clientid, string clientsecret, AuthorizationResult authorizationResult)
        {
            return new AccessTokenResponse()
            {
                AccessToken = "S1AV32hkKG",
                CustomerNumber = "1234-2587-3698",
                ExpiresIn = "3600",
                RefreshToken = "8xLOxBtZp6",
                Scope = "MetadataRead RedboxProfile",
                TokenType = "BEARER"
            };
        }

        public AuthCodeResponse CodeApproval(string clientid, string clientsecret, AuthorizationResult authorizationResult)
        {

            return new AuthCodeResponse()
            {
                AuthCode = "authcode1",
                RedirectUrl = "HTTP://WWW.redirectURL.COM"
            };
        }

        
    }
    
}
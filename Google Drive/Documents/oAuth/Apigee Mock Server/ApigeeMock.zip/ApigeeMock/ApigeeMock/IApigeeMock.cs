﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Xml.Serialization;

namespace ApigeeMock
{
    [ServiceContract]
    
    public interface IApigeeMock
    {

        //AV1
        [XmlSerializerFormat]
        [WebGet(UriTemplate="/validaterequestvalidationtoken?requestvalidationtoken={rvt}&requestingclient_id={rcid}&client_id={client_id}&client_secret={client_secret}")]
        ValidationTokenResponse Validate(string rvt, string rcid, string client_id, string client_secret);

        //AV2
        //[XmlSerializerFormat]
        [WebInvoke(Method="POST",
            //UriTemplate = "/tokenaccessapproval")]
                   UriTemplate="/tokenaccessapproval?client_id={clientid}&client_secret={clientsecret}",
                   ResponseFormat=WebMessageFormat.Json
                   )]
        AccessTokenResponse TokenApproval(string clientid, string clientsecret, AuthorizationResult authorizationResult);

        //AV3
        [XmlSerializerFormat]
        [WebInvoke(Method="POST",
                   UriTemplate="/codeaccessapproval?client_id={clientid}&client_secret={clientsecret}",
                   ResponseFormat=WebMessageFormat.Xml)]
        AuthCodeResponse CodeApproval(string clientid, string clientsecret, AuthorizationResult authorizationResult);
        
        
    }

    
    [XmlRoot("ValidationTokenResponse", Namespace = "http://oauth2.redbox.com/v1/Authorization")]
    public class ValidationTokenResponse
    {
    }

    //[XmlRoot("AccessTokenResponse", Namespace="http://oauth2.redbox.com/v1/Authorization")]
    
    [DataContract]
    public class AccessTokenResponse
    {
        //[XmlElement("access_token")]
        [DataMember]
        public string AccessToken {get;set;}
        //[XmlElement("token_type")]
        [DataMember]
        public string TokenType {get;set;}
        //[XmlElement("expires_in")]
        [DataMember]
        public string ExpiresIn {get;set;}
        //[XmlElement("refresh_token")]
        [DataMember]
        public string RefreshToken {get;set;}
        //[XmlElement("scope")]
        [DataMember]
        public string Scope {get;set;}
        //[XmlElement("customer_number")]
        [DataMember]
        public string CustomerNumber {get;set;}

    }

    [XmlRoot("AuthCode", Namespace="http://oauth2.redbox.com/v1/Authorization")]
    public class AuthCodeResponse
    {
        [XmlElement("authCode")]
        public string AuthCode {get;set;}

        [XmlElement("redirectUrl")]
        public string RedirectUrl {get;set;}
            
    }

}

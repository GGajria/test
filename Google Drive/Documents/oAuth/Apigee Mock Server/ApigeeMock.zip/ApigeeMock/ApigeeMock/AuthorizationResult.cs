﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;
using System.Runtime.Serialization;

namespace ApigeeMock
{
    [DataContract(Namespace="http://oauth2.redbox.com/v1/Authorization")]
    [XmlRoot("AuthorizationResult", Namespace = "http://oauth2.redbox.com/v1/Authorization")]
    public class AuthorizationResult
    {
        [XmlElement("Authorization")]
        public Authorization Authorization { get; set; }
        [XmlElement("AuthorizationContext")]
        public AuthorizationContext1 AuthorizationContext { get; set; }
    }


    public class Authorization
    {
        [XmlAttribute]
        public string authorized { get; set; }
        [XmlAttribute]
        public string authorizedBy { get; set; }
        [XmlAttribute]
        public string authorizationEffectiveInstant { get; set; }
        [XmlAttribute]
        public string scopeAuthorized { get; set; }
        [XmlAttribute]
        public string tokenLifetime { get; set; }
        [XmlAttribute]
        public string tokenExpiresOn { get; set; }
        [XmlAttribute]
        public string refreshAllowed { get; set; }
        [XmlAttribute]
        public string refreshCount { get; set; }
        [XmlAttribute]
        public string refreshTokenLifetime { get; set; }
        [XmlElement("Extensions")]
        public string extensions { get; set; }
    }

    public class AuthorizationContext1
    {
        [XmlAttribute]
        public string scopesRequested { get; set; }
        [XmlAttribute]
        public string requestedTokenType { get; set; }
        [XmlAttribute("requestingClient_id")]
        public string requestingClientId { get; set; }
        [XmlAttribute]
        public string state { get; set; }
        [XmlAttribute]
        public string redirect_uri { get; set; }
        [XmlElement("UserIdentity")]
        public UserIdentity UserIdentity { get; set; }
        [XmlElement("Extensions")]
        public string extensions { get; set; }
    }

    public class UserIdentity
    {
        [XmlElement("CustomerNumber")]
        public string customerNumber { get; set; }
        [XmlArray("Claims")]
        [XmlArrayItem("Claim")]
        public List<AuthorizationClaim> Claims { get; set; }
        [XmlElement("Extensions")]
        public string extensions { get; set; }
    }

    public class AuthorizationClaim
    {
        [XmlAttribute]
        public string name { get; set; }
        [XmlAttribute]
        public string value { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ServiceModel;
using System.ServiceModel.Description;
using oAuthService.Contracts;
using System.Configuration;
using oAuth.Mvc.Models;

namespace oAuth.Mvc.Controllers
{
    public class AuthController : Controller
    {
        //
        // GET: /Auth/
        //permission?client_id={client_id}&redirect_uri={rurl}&scope={scope}&state={state}&request_type={type}&requestvalidationtoken={rvt}


        //getting the Request form
        public ActionResult GetForm(string client_id, string redirect_uri, string scope, string state, string request_type, string requestvalidationtoken)
        {
            //create a service client
            var channel = createChannel<IOAuthService>(typeof(string), ConfigurationManager.AppSettings["AuthService"]).CreateChannel();

            //build the service request object
            var serviceAuth = new oAuthService.Contracts.Auth()
            {
                client_id = client_id,
                rurl = redirect_uri,
                rvt = requestvalidationtoken,
                scope = scope,
                state = state,
                type = request_type
            };

            //call the service and pass the request object
            var perm = channel.GetPermissionForm(serviceAuth);
            
            //if success show the perm form
            if (perm == "true")
            {
                var auth = new oAuth.Mvc.Models.Auth()
                {
                    client_id = client_id,
                    rurl = redirect_uri,
                    rvt = requestvalidationtoken,
                    scope = scope,
                    state = state,
                    type = request_type
                };

                return View("PermissionsPage", auth);
            }
                //else show the auth failure form
            else
            {
                return View("NotAuthenticated");
            }
        }

        
        //Permission Response
        //Form Posted to this action
        [HttpPost]
        public ActionResult PostForm([Bind(Prefix="Auth")]oAuth.Mvc.Models.Auth model)
        {
            //create a service client
            var channel = createChannel<IOAuthService>(typeof(string), ConfigurationManager.AppSettings["AuthService"]).CreateChannel();
            
            //form the req object
            var newModel = new oAuthService.Contracts.Auth()
            {
                client_id = Request.Form["client_id"],
                rurl = Request.Form["rurl"],
                rvt = Request.Form["rvt"],
                scope = Request.Form["scope"],
                state = Request.Form["state"],
                type = Request.Form["type"]
            };

            //call the service and pass the request object
            var resp = channel.CheckPermissionForm(newModel);
            
            //if success show granted msg
            if (resp == "true")
            {
                return View("PermissionResponse", new PermissionResponse(){message = "Permission Granted"});
            }
            //else show denied message
            else
            {
                return View("PermissionResponse", new PermissionResponse() { message = "Permission Denied" });
            }
        }


        //helper method for service client creation
        private static ChannelFactory<T> createChannel<T>(Type type, string appSettingURL)
        {
            //start timer
            var myBinding = new WebHttpBinding();
            myBinding.SendTimeout = TimeSpan.MaxValue;
            myBinding.MaxReceivedMessageSize = int.MaxValue;
            //Change the endpoint address to point to the service URL
            var myEndpoint =
                new EndpointAddress(appSettingURL);
            var myChannelFactory =
                new ChannelFactory<T>(
                    myBinding, myEndpoint);
            myChannelFactory.Endpoint.Behaviors.Add(new WebHttpBehavior());
            // Create a channel.
            return myChannelFactory;//.CreateChannel();
        }
    }
}

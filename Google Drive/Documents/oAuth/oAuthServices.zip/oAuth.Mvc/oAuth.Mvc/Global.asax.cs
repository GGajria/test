﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using oAuth.Mvc.Models;

namespace oAuth.Mvc
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

    public class MvcApplication : System.Web.HttpApplication
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }

        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            //route mapping for perm request form
            routes.MapRoute("GetForm",
                "Auth/getform/client_id={client_id}&redirect_uri={redirect_uri}&scope={scope}&state={state}&request_type={request_type}&requestvalidationtoken={requestvalidationtoken}",
                null);
                //new { controller = "Auth", action = "GetForm", redirect_uri = (string)null, scope = (string)null, state = (string)null, request_type = (string)null, requestvalidationtoken = (string)null });

            //route mapping for perm response form
            routes.MapRoute("PostForm",
                "v1/permission/",
                new { Controller = "Auth", action = "PostForm" }
                );
            
            
            

            //default mapping
            routes.MapRoute(
                "Default", // Route name
                "{controller}/{action}/{id}", // URL with parameters
                new { controller = "Home", action = "Index", id = UrlParameter.Optional } // Parameter defaults
            );

        }

        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();

            RegisterGlobalFilters(GlobalFilters.Filters);
            RegisterRoutes(RouteTable.Routes);
        }
    }
}
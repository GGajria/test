﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace oAuth.Mvc.Models
{
    //auth view model
    public class Auth
    {
        public string client_id;
        public string rurl;
        public string scope;
        public string state;
        public string type;
        public string rvt;
    }

    //perm view model
    public class PermissionResponse
    {
        public string message;
    }
}
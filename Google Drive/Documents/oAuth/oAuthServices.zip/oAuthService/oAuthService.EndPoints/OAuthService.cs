﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using oAuthService.Contracts;
using System.ServiceModel.Activation;


namespace oAuthService.EndPoints
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class OAuthService : IOAuthService
    {
        public string GetPermissionForm(Auth auth)
        {

            //perform validaion before sending back the perm form
            //for now checking if client_id = valid or not
            if (auth.client_id == "valid")
            {
                return "true";
            }
            else
            {
                return "false";
            }
        }


        public string CheckPermissionForm(Auth auth)
        {
            //perform processing of the submitted perm form


            //for now checking if clientid is valid
            if (auth.client_id == "valid")
                return "true";
            else
                return "false";
        }

        public string AuthorizeSAML()
        {
            //not implemented
            return null;
        }

        public string RefreshToken(string client_id, string customernum, string scope, string rvt)
        {
            //not implemented
            return null;
        }
    }
}


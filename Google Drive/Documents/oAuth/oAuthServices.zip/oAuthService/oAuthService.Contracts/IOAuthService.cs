﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Xml.Serialization;

namespace oAuthService.Contracts
{
    
    //Service Contract
    [ServiceContract]
    [XmlSerializerFormat]
    public interface IOAuthService
    {

        
        //request for permission form
        [WebInvoke(Method="POST",
                   UriTemplate = "/permission/get")]
        string GetPermissionForm(Auth auth);


        //check the posted back permission form
        [WebInvoke(Method="POST",
                   UriTemplate="/permission")]
        string CheckPermissionForm(Auth auth);

        
        [WebInvoke(Method="POST",
                   UriTemplate="/authorizeSAML")]
        string AuthorizeSAML();


        [WebGet(UriTemplate = "/authorizeRefresh?client_id={client_id}&customer_number={customernum}&scope={scope}&requestvalidationtoken={rvt}")]
        string RefreshToken(string client_id, string customernum, string scope, string rvt);
    }


    //Auth Data Contract
    public class Auth
    {
        public string client_id;
        public string rurl;
        public string scope;
        public string state;
        public string type;
        public string rvt;
    }

    
}

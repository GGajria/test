﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading;
using Microsoft.IdentityModel.Protocols.WSFederation;
using Microsoft.IdentityModel.Claims;
using System.Web.UI.HtmlControls;
using System.Configuration;

namespace TestRP
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            Uri issuer = new Uri(ConfigurationManager.AppSettings["Issuer"]);
            string returnURL = ConfigurationManager.AppSettings["ReturnURL"];
            string realm = ConfigurationManager.AppSettings["Realm"];

            if (HttpContext.Current.User.Identity.IsAuthenticated)
            {
                signinlink.Visible = false;
                signoutlink.Visible = true;

                
                SignOutRequestMessage a = new SignOutRequestMessage(issuer, returnURL);
                a.SetParameter("wtrealm", realm);
                //building the link using the wif helper
                signoutlink.HRef = a.WriteQueryString();


                foreach (var claim in ((IClaimsIdentity)HttpContext.Current.User.Identity).Claims)
                {
                    var row = new HtmlTableRow();

                    HtmlTableCell claimName = new HtmlTableCell();
                    claimName.InnerText = claim.ClaimType;
                    row.Controls.Add(claimName);

                    HtmlTableCell claimValue = new HtmlTableCell();
                    claimValue.InnerText = claim.Value;
                    row.Controls.Add(claimValue);

                    claimTable.Rows.Add(row);
                }
            }
            else
            {
                //building the link using the wif helper
                SignInRequestMessage sigIn = new SignInRequestMessage(issuer, realm, returnURL);
                signinlink.HRef = sigIn.WriteQueryString();
                signinlink.Visible = true;
                signoutlink.Visible = false;
            }
        }
    }
}

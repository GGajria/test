package Pagination;

import java.io.StringWriter;
import java.util.Iterator;
import java.util.Map;

import javax.xml.namespace.NamespaceContext;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.sonoa.services.messaging.component.primitive.javacallout.spi.JavaCalloutLogger;
import com.sonoa.services.messaging.component.primitive.javacallout.spi.JavaCalloutTask;
import com.sonoa.services.messaging.component.primitive.javacallout.spi.MessageContext;
import com.sonoa.services.messaging.component.primitive.javacallout.spi.MessagingException;

public class ProductPaginate implements JavaCalloutTask{
	enum SEARCHTYPE{
		EXACT, 
		CONTAINS, 
		STARTSWITH
	};  
	static String NAMESPACE = "http://api.redbox.com/v3/Products";
	static String ATOM = "http://www.w3.org/2005/Atom";
	static int DEFAULTPAGESIZE = 10;
	/**
	 * @param args
	 */
	public static void main(String[] args) {

		//current page number
		int pageNumber = Integer.parseInt("1");

		//results per page
		int pageSize = Integer.parseInt("2");

		//comma separated list of product ids
		String productIds = ""; 

		//comma separated list of product types
		String productTypes = "movIE";

		//search query
		String searchQuery = "Red";

		//source page URI
		String sourceURI = "http://50.18.22.174:1779/v3/products/movies/metrics?apiKey=93040871d531b12b5d892d19fec2e0fa&pageNumber=2&pageSize=5&searchQuery=a";

		//operation name
		String operName="P3";

		//search operator
		String searchOper = "";

		//incoming message 
		String xmlString ="<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
				"<Products xmlns=\"http://api.redbox.com/v3/Products\">"+
				"<Movie productId=\"1\" format=\"DVD\"><UppercaseTitle>RedBOX</UppercaseTitle></Movie>" +
				"<Movie productId=\"2\" format=\"DVD\"><UppercaseTitle>REDBOX</UppercaseTitle></Movie>" +
				"<Movie productId=\"3\" format=\"Game\"><UppercaseTitle>RedBOX</UppercaseTitle></Movie>" +
				"<Game productId=\"4\" format=\"Game\"><UppercaseTitle>RED</UppercaseTitle></Game>" +
				"<Movie productId=\"5\" format=\"DVD\"><UppercaseTitle>TEST2</UppercaseTitle></Movie>" +
				"<Movie productId=\"6\" format=\"DVD\"><UppercaseTitle>TEST2</UppercaseTitle></Movie>" +
				"<Movie productId=\"7\" format=\"DVD\"><UppercaseTitle>TEST7</UppercaseTitle></Movie>" +
				"<Game productId=\"8\" format=\"BlueRay\"><UppercaseTitle>TEST8</UppercaseTitle></Game>" +
				"<Movie productId=\"9\" format=\"DVD\"><UppercaseTitle>TEST9</UppercaseTitle></Movie>" +
				"</Products>";



		Document doc = getXMLDocfromString(xmlString);
		Document finalDoc = doc;
		finalDoc.getDocumentElement().setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns:atom", "http://www.w3.org/2005/Atom");
		finalDoc.setXmlStandalone(true);

		if (operName == "P1" || operName == "P4"  ){//Movies, Games, Movies Metrics, Games Metrics (only pagination)
			NodeList nodeList;
			if (operName == "P1"){
				nodeList = getFilteredList(doc, "/:Products/*");
			}
			else {
				nodeList = getFilteredList(doc, "/:ProductsMetrics/*");
			}  
			while (finalDoc.getDocumentElement().hasChildNodes()) {
				finalDoc.getDocumentElement().removeChild(finalDoc.getDocumentElement().getFirstChild());
			}
			finalDoc = paginate(finalDoc, pageNumber, pageSize, nodeList, sourceURI);	
		}
		else if (operName == "P2") {//List of productIds 
			if (productIds.isEmpty())
			{
				productIds = "null";
			}
			String productIdsXpath = getXpathCondition(productIds, "./@productId", SEARCHTYPE.EXACT);
			NodeList nodeList = getFilteredList(doc, "/:Products/*[" + productIdsXpath + "]");// + productIdsXpath + "]");
			while (finalDoc.getDocumentElement().hasChildNodes()) {
				finalDoc.getDocumentElement().removeChild(finalDoc.getDocumentElement().getFirstChild());
			}
			finalDoc = paginate(finalDoc, pageNumber, pageSize, nodeList, sourceURI);
		}
		else if (operName == "P3") {//Search for products with title and product type
			String productTypeXpath = "";
			String searchQueryXpath = "";
			SEARCHTYPE searchType = SEARCHTYPE.CONTAINS;

			//search operator
			if (searchOper.toUpperCase().equals("CONTAINS")){
				searchType = SEARCHTYPE.CONTAINS;
			}
			else if (searchOper.toUpperCase().equals("STARTSWITH")) {
				searchType = SEARCHTYPE.STARTSWITH;
			}

			//search query
			if (!searchQuery.isEmpty()){
				searchQueryXpath = getXpathCondition(searchQuery.toUpperCase(), "./:UppercaseTitle", searchType);
			}

			//product type
			if (!productTypes.isEmpty())
			{
				if (productTypes.toLowerCase().contains("movie") && productTypes.toLowerCase().contains("game")){
					productTypeXpath = "*";
				}
				else if (productTypes.toLowerCase().contains("movie")) {
					productTypeXpath = ":Movie";
				}
				else if (productTypes.toLowerCase().contains("game")) {
					productTypeXpath = ":Game";
				}
			}

			//xpath condition
			String condition ="";
			if (!searchQueryXpath.isEmpty()){
				condition += "(" + searchQueryXpath + ")";
			}
//			if (!productTypeXpath.isEmpty()){
//				if (!condition.isEmpty()) {
//					condition += " and (" + productTypeXpath + ")";
//				}
//				else {
//					condition += productTypeXpath;
//				}
//			}
			if (!condition.isEmpty()){
				condition = "[" + condition + "]";
			}

			System.out.println("/:Products/"+productTypeXpath+condition);
			NodeList nodeList = getFilteredList(doc, "/:Products/"+productTypeXpath+condition );

			while (finalDoc.getDocumentElement().hasChildNodes()) {
				finalDoc.getDocumentElement().removeChild(finalDoc.getDocumentElement().getFirstChild());
			}

			finalDoc = paginate(finalDoc, pageNumber, pageSize, nodeList, sourceURI);
		}
		System.out.println(getStringfromXMLDoc(finalDoc));
	}
	/**
	 * Creates a xPath condition for a comma separated list
	 * @param csvInput
	 * @param attrib
	 * @param searchType
	 * @return A valid xPath expression string 
	 */
	private static String getXpathCondition(String csvInput, String attrib, SEARCHTYPE searchType) {
		String xpathStr = "";
		if (!csvInput.isEmpty()) {
			String[] lstOfVals = csvInput.split(",");
			int i = 0;

			//exact match
			if (searchType == SEARCHTYPE.EXACT) {
				while (i < lstOfVals.length-1) {
					xpathStr +=  attrib + "='" + lstOfVals[i++] + "' or ";
				}
				if (lstOfVals.length > 0)
				{
					xpathStr +=  attrib + "='" + lstOfVals[lstOfVals.length-1] + "'";
				}
			}
			//contains
			else if (searchType == SEARCHTYPE.CONTAINS) {
				while (i < lstOfVals.length-1) {
					xpathStr +=  "contains(" + attrib + ",'" + lstOfVals[i++] + "') or ";
				}
				if (lstOfVals.length > 0)
				{
					xpathStr +=  "contains(" +attrib + ",'" + lstOfVals[lstOfVals.length-1] + "')";
				}
			}
			//starts with
			else if (searchType == SEARCHTYPE.STARTSWITH) {
				while (i < lstOfVals.length-1) {
					xpathStr +=  "starts-with(" + attrib + ",'" + lstOfVals[i++] + "') or ";
				}
				if (lstOfVals.length > 0)
				{
					xpathStr +=  "starts-with(" +attrib + ",'" + lstOfVals[lstOfVals.length-1] + "')";
				}
			}
		}
		return xpathStr;
	}


	/**
	 * Extract the filtered set from the Doc by using the supplied xPath 
	 * @param doc
	 * @param xpathStr
	 * @return Filtered set in a NodeList
	 */
	private static NodeList getFilteredList(Document doc, String xpathStr) {
		XPathFactory xpathFact = XPathFactory.newInstance();
		XPath xpath = xpathFact.newXPath();
		NamespaceContext nsc = getNSContext();
		xpath.setNamespaceContext(nsc);
		NodeList nodeList = (NodeList)eval(doc, xpathStr, XPathConstants.NODESET, xpath);
		return nodeList;
	}

	/**
	 * Get the Namespace context for xPath evaluation against doc.
	 * Uses global variable NAMESPACE for the URI
	 * @return
	 */
	private static NamespaceContext getNSContext() {
		NamespaceContext nsc = new NamespaceContext() {

			@Override
			public Iterator getPrefixes(String arg0) {
				return null;
			}

			@Override
			public String getPrefix(String arg0) {
				return null;
			}

			@Override
			public String getNamespaceURI(String arg0) {
				return NAMESPACE;
			}
		};
		return nsc;
	}

	/**
	 * Create a empty document
	 * @return
	 */
	private static Document createDomDocument() {
		try {
			DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			Document doc = builder.newDocument();
			return doc;
		} catch (ParserConfigurationException e) {
		}
		return null;
	}

	/**
	 * Create a doc from xml string
	 * @param xmlString
	 * @return
	 */
	private static Document getXMLDocfromString(String xmlString) {
		Document doc = null;
		DocumentBuilderFactory xmlFact = DocumentBuilderFactory
				.newInstance();
		xmlFact.setNamespaceAware(true);
		DocumentBuilder builder;
		try {
			builder = xmlFact.newDocumentBuilder();
			doc = builder.parse(new java.io.ByteArrayInputStream(xmlString.getBytes()));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return doc;
	}

	/**
	 * Get xml string from a Document
	 * @param doc
	 * @return
	 */
	public static String getStringfromXMLDoc(Document doc) 
	{
		DOMSource domSource = new DOMSource(doc);
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = null;
		try {
			transformer = tf.newTransformer();
		} catch (TransformerConfigurationException e1) {
			e1.printStackTrace();
		}
		try {
			transformer.transform(domSource, result);
		} catch (TransformerException e) {
			e.printStackTrace();
		}
		return writer.toString();
	}

	/**
	 * Restricts the result set from the Nodelist items and adds the pagination elements
	 * @param doc
	 * @param pageNumber
	 * @param pageSize
	 * @param resultList
	 * @param sourceURI
	 * @return FinalDoc
	 */
	private static Document paginate(Document doc,  int pageNumber, int pageSize, NodeList resultList, String URI) {
		int startIndex = (pageNumber - 1) * pageSize;
		int lastIndex = startIndex + pageSize;
		if(lastIndex > resultList.getLength()){
			lastIndex = resultList.getLength();
		}
		if (startIndex > lastIndex){
			startIndex = lastIndex = 0;
		}

		//setup totNumPages
		int totNumOfPages =  resultList.getLength()/pageSize;
		if (resultList.getLength()%pageSize>0){
			totNumOfPages = totNumOfPages + 1;
		}

		//restrict results within boundary
		for (int i = startIndex; i < lastIndex; i++) {
			doc.getDocumentElement().appendChild(resultList.item(i));
		}

		//paging element
		Element pagingElement = doc.createElementNS(NAMESPACE, "Paging");

		//pagingElement.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns", NAMESPACE);
		pagingElement.setAttribute("pageNum", String.valueOf(pageNumber));
		pagingElement.setAttribute("pageSize", String.valueOf(pageSize));
		pagingElement.setAttribute("totalNumItems", String.valueOf(resultList.getLength()));
		pagingElement.setAttribute("pageCount", String.valueOf(totNumOfPages));

		if (totNumOfPages==0){
			totNumOfPages++;
		}

		String[] path = URI.toLowerCase().split("[?]");
		String[] queryParams = path[1].split("&");

		//first link
		createLinkElement(doc, pageSize, "first", buildPath(path[0], updateQueryParam("pagenumber", 1, queryParams)), pagingElement);

		if (pageNumber > 1 && pageNumber <=  totNumOfPages )
		{
			//prev link
			queryParams = updateQueryParam("pagenumber", pageNumber-1, queryParams);
			createLinkElement(doc, pageSize, "prev", buildPath(path[0], updateQueryParam("pagenumber", pageNumber-1, queryParams)), pagingElement);
		}

		if (pageNumber < totNumOfPages)
		{
			//next link
			createLinkElement(doc, pageSize, "next", buildPath(path[0], updateQueryParam("pagenumber", pageNumber+1, queryParams)), pagingElement);
		}

		//last link
		createLinkElement(doc, pageSize, "last", buildPath(path[0], updateQueryParam("pagenumber", totNumOfPages, queryParams)), pagingElement);
		doc.getDocumentElement().appendChild(pagingElement);
		return doc;
	}
	
	/**
	 * Builds a path and attaches the query parameters
	 * @param path
	 * @param queryParams
	 * @return The full path after attaching the query vars
	 */
	private static String buildPath(String path, String[] queryParams) {
		String pathParams ="";
		for (int i = 0; i < queryParams.length; i++) {
			if (i==(queryParams.length-1)){
				pathParams += queryParams[i];
			}
			else {
				pathParams += queryParams[i] + "&";
			}
		}
		return path +"?"+ pathParams;
	}
	
	/**
	 * Update array containing the name key with a value
	 * @param name
	 * @param value
	 * @param queryParams
	 * @return Updated queryParams array if match found, else returns the same array
	 */
	private static String[] updateQueryParam(String name, int value, String[] queryParams) {
		for (int i = 0; i < queryParams.length; i++) {
			if (queryParams[i].contains(name)){
				queryParams[i] = name+"="+value;
				return queryParams;
			}
		}
		return queryParams;
	}

	/**
	 * Creates a Link element (first, last, next, prev)
	 * @param doc
	 * @param pageSize
	 * @param rel
	 * @param URI
	 * @param pagingElement
	 */
	private static void createLinkElement(Document doc, int pageSize,String rel, String URI, Element pagingElement) {
		Element link = doc.createElementNS(ATOM, "atom:link");
		link.setAttribute("rel", rel);
		link.setAttribute("href", URI);
		pagingElement.appendChild(link);
	}

	/**
	 * Evaluate xPath expression against a Doc returning a nodelist
	 * @param doc
	 * @param expression
	 * @param returnType
	 * @param xPath
	 */
	public static Object eval(Document doc, String expression, QName returnType, XPath xPath) 
	{
		XPathExpression xPathExpression;
		try {
			xPathExpression = xPath.compile(expression);
			return xPathExpression.evaluate(doc, returnType);
		} catch (XPathExpressionException e) {
			e.printStackTrace();
		}
		return null;
	}

	JavaCalloutLogger logger;
	@Override
	public void execute(MessageContext arg0, Map<String, Object> arg1)
			throws JavaCalloutException {
		int pageNumber = 0;
		int pageSize = DEFAULTPAGESIZE;
		String productIds = null;
		String productTypes = null;
		String searchQuery = null;
		String sourceURI = null;
		String operName = null;
		String searchOper = null;
		String xmlString = null;
		try {
			//current page number
			pageNumber = Integer.parseInt(arg0.getFlowVariableAsString("pageNumber"));

			//results per page
			if (!arg0.getFlowVariableAsString("pageSize").isEmpty()){
				pageSize = Integer.parseInt(arg0.getFlowVariableAsString("pageSize"));
			}

			//comma separated list of product ids
			productIds = arg0.getFlowVariableAsString("productIds").toUpperCase(); 

			//comma separated list of product types
			productTypes = arg0.getFlowVariableAsString("productTypes");

			//search query
			searchQuery = arg0.getFlowVariableAsString("searchQuery").toUpperCase();

			//source page URI
			sourceURI = arg0.getFlowVariableAsString("sourceURI");

			//operation name
			operName= arg0.getFlowVariableAsString("operName");

			//search operator
			searchOper = arg0.getFlowVariableAsString("searchOper");

			//incoming message 
			xmlString = arg0.getMessageContentAccessor().getContent();
		} catch (MessagingException e) {
			logger.debug("Failed at getting input arguments");
			e.printStackTrace();
		}

		Document doc = getXMLDocfromString(xmlString);
		Document finalDoc = doc;

		//set atom namespace up top
		finalDoc.getDocumentElement().setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns:atom", "http://www.w3.org/2005/Atom");
		finalDoc.setXmlStandalone(true);

		if (operName == "P1" || operName == "P4"  ){//Movies, Games, Movies Metrics, Games Metrics (only pagination)
			NodeList nodeList;
			if (operName == "P1"){
				nodeList = getFilteredList(doc, "/:Products/*");
			}
			else {
				nodeList = getFilteredList(doc, "/:ProductsMetrics/*");
			}  
			while (finalDoc.getDocumentElement().hasChildNodes()) {
				finalDoc.getDocumentElement().removeChild(finalDoc.getDocumentElement().getFirstChild());
			}
			finalDoc = paginate(finalDoc, pageNumber, pageSize, nodeList, sourceURI);	
		}
		else if (operName == "P2") {//List of productIds 
			if (productIds.isEmpty())
			{
				productIds = "null";
			}
			String productIdsXpath = getXpathCondition(productIds, "./@productId", SEARCHTYPE.EXACT);
			NodeList nodeList = getFilteredList(doc, "/:Products/*[" + productIdsXpath + "]");// + productIdsXpath + "]");
			while (finalDoc.getDocumentElement().hasChildNodes()) {
				finalDoc.getDocumentElement().removeChild(finalDoc.getDocumentElement().getFirstChild());
			}
			finalDoc = paginate(finalDoc, pageNumber, pageSize, nodeList, sourceURI);
		}
		else if (operName == "P3") {//Search for products with title and product type
			String productTypeXpath = "";
			String searchQueryXpath = "";
			SEARCHTYPE searchType = SEARCHTYPE.CONTAINS;

			//search operator
			if (searchOper.toUpperCase().equals("CONTAINS")){
				searchType = SEARCHTYPE.CONTAINS;
			}
			else if (searchOper.toUpperCase().equals("STARTSWITH")) {
				searchType = SEARCHTYPE.STARTSWITH;
			}

			//search query
			if (!searchQuery.isEmpty()){
				searchQueryXpath = getXpathCondition(searchQuery, "./:UppercaseTitle", searchType);
			}

			//product type
			if (!productTypes.isEmpty())
			{
				if (productTypes.toLowerCase().contains("movie") && productTypes.toLowerCase().contains("game")){
					productTypeXpath = "*";
				}
				else if (productTypes.toLowerCase().contains("movie")) {
					productTypeXpath = ":Movie";
				}
				else if (productTypes.toLowerCase().contains("game")) {
					productTypeXpath = ":Game";
				}
			}

			//xpath condition
			String condition ="";
			if (!searchQueryXpath.isEmpty()){
				condition += "(" + searchQueryXpath + ")";
			}
//			if (!productTypeXpath.isEmpty()){
//				if (!condition.isEmpty()) {
//					condition += " and (" + productTypeXpath + ")";
//				}
//				else {
//					condition += productTypeXpath;
//				}
//			}
			if (!condition.isEmpty()){
				condition = "[" + condition + "]";
			}

			NodeList nodeList = getFilteredList(doc, "/:Products/"+ productTypeXpath + condition );

			while (finalDoc.getDocumentElement().hasChildNodes()) {
				finalDoc.getDocumentElement().removeChild(finalDoc.getDocumentElement().getFirstChild());
			}

			finalDoc = paginate(finalDoc, pageNumber, pageSize, nodeList, sourceURI);
		}
		try {
			arg0.getMessageContentAccessor().setContent(getStringfromXMLDoc(finalDoc));
		} catch (MessagingException e) {
			logger.debug("Failed to set content");
			e.printStackTrace();
		} 

	}
	@Override
	public boolean isBlockingTask() {
		// TODO Auto-generated method stub
		return false;
	}
}

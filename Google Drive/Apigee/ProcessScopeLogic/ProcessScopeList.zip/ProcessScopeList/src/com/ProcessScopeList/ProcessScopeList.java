package com.ProcessScopeList;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

import org.w3c.dom.Document;

import com.sonoa.services.messaging.component.primitive.javacallout.spi.JavaCalloutLogger;
import com.sonoa.services.messaging.component.primitive.javacallout.spi.JavaCalloutTask;
import com.sonoa.services.messaging.component.primitive.javacallout.spi.MessageContext;
import com.sonoa.services.messaging.component.primitive.javacallout.spi.MessagingException;

import pack.XMLHelper.XMLHelper;

public class ProcessScopeList implements JavaCalloutTask {
	static String UC = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	static String LC = "abcdefghijklmnopqrstuvwxyz";
	
	static String KMS_URL = "http://184.169.255.158:8080/scope/list";
	static String AUTH = "Basic YXBpZ2VlOmFwaWdlZTEyMw==";
	static String passedScope = "";
	
	public static void main(String[] args){
		KMS_URL = "http://184.169.255.158:8080/scope/list";
		passedScope = "RENTALHISTORY PROFILE";
		String returnVal = checkScopes(null);
		System.out.println(returnVal);
		
		
	}

	private static String checkScopes(JavaCalloutLogger logger) {
		if  ( logger!= null ) logger.debug("KMS_URL" + KMS_URL);
		if  ( logger!= null ) logger.debug("AUTH" + AUTH);
		String scopeXML = getURL(KMS_URL, AUTH);
		if  ( logger!= null ) logger.debug("After calling response " + scopeXML);
		Document doc = XMLHelper.getXMLDocfromString(scopeXML);
		
		String[] passedScopeArr = passedScope.split(" ");
		String returnVal = "";
		for (int i = 0; i < passedScopeArr.length; i++) {
			String scope = passedScopeArr[i];
			if  ( logger!= null ) logger.debug(scope);
			if (i == passedScopeArr.length-1){
			returnVal += XMLHelper.getValue(doc.getDocumentElement(), 
					"/scopes/scope[ " + translate2Upper("./name") + "='" + scope.toUpperCase() + "']/description");
			}
			else{
				returnVal += XMLHelper.getValue(doc.getDocumentElement(), 
						"/scopes/scope[ " + translate2Upper("./name") + "='" + scope.toUpperCase() + "']/description") + " ";
			}
			
		}
		return returnVal;
	}
	
	private static String translate2Upper(String attribute){
		return "translate(" + attribute + ",'" + LC + "','" + UC + "')";
	}
	

	private static String getURL(String url, String authString) {
		BufferedReader reader = null;
		String out ="";
		try{
			HttpURLConnection conn = null;
			conn = (HttpURLConnection) new URL(url).openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Authorization", authString );
			InputStream response = null;
			response = conn.getInputStream();
			reader = new BufferedReader(new InputStreamReader(response));
			for (String line; (line = reader.readLine()) != null;) {
				out += line;
			}
		} catch (Exception e) {
			out = e.getMessage();
		}
		finally {
			if (reader != null) try { reader.close(); } catch (IOException logOrIgnore) {}
		}
		return out;
	}
	JavaCalloutLogger logger;
	@Override
	public void execute(MessageContext arg0, Map<String, Object> arg1)
			throws JavaCalloutException {
		
		try{
		logger = arg0.getLogger();
		if (!arg0.getFlowVariableAsString("KMS_URL").isEmpty()){
			KMS_URL = arg0.getFlowVariableAsString("KMS_URL");
		}
		
		if (!arg0.getFlowVariableAsString("AUTH").isEmpty()){
			AUTH = arg0.getFlowVariableAsString("AUTH");
		}
		
		if (!arg0.getFlowVariableAsString("scope").isEmpty()){
			passedScope = arg0.getFlowVariableAsString("scope");
		}
		}catch(Exception e){
			logger.debug("Error getting params");
			logger.debug(e.getMessage());
			e.printStackTrace();
		}
		
		String returnVal = checkScopes(logger);
		
		try {
			arg0.setFlowVariable("keyScope", returnVal);
		} catch (MessagingException e) {
 			e.printStackTrace();
		}
		
		}
	
	
	
		
		
 
		
	

	@Override
	public boolean isBlockingTask() {
		// TODO Auto-generated method stub
		return false;
	}
}



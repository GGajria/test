package pack.XMLHelper;

import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.util.Iterator;

import javax.xml.namespace.NamespaceContext;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class XMLHelper {

	public static String getValue(Object node, String xPath)
	{
		XPathFactory factory = XPathFactory.newInstance();
		XPath xpath = factory.newXPath();
		String s ="";
		try {
			s = (String)xpath.evaluate(xPath, node, XPathConstants.STRING);
		} catch (XPathExpressionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
	}

	public static String getValue(Object node, String xPath, NamespaceContext nsc)
	{
		XPathFactory factory = XPathFactory.newInstance();
		XPath xpath = factory.newXPath();
		xpath.setNamespaceContext(nsc);
		String s ="";
		try {
			s = (String)xpath.evaluate(xPath, node, XPathConstants.STRING);
		} catch (XPathExpressionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
	}

	public static Node getNode(Object node, String xPath)
	{
		XPathFactory factory = XPathFactory.newInstance();
		XPath xpath = factory.newXPath();

		Node s = null;
		try {
			s = (Node)xpath.evaluate(xPath, node, XPathConstants.NODE);
		} catch (XPathExpressionException e) {
			e.printStackTrace();
		}
		return s;
	}

	public static Node getNode(Object node, String xPath, NamespaceContext nsc)
	{
		XPathFactory factory = XPathFactory.newInstance();
		XPath xpath = factory.newXPath();
		xpath.setNamespaceContext(nsc);
		Node s = null;
		try {
			s = (Node)xpath.evaluate(xPath, node, XPathConstants.NODE);
		} catch (XPathExpressionException e) {
			e.printStackTrace();
		}
		return s;
	}

	public static NodeList getNodeList(Object node, String xPath)
	{
		XPathFactory factory = XPathFactory.newInstance();
		XPath xpath = factory.newXPath();
		NodeList s = null;
		try {
			s = (NodeList)xpath.evaluate(xPath, node, XPathConstants.NODESET);
		} catch (XPathExpressionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
	}

	public static NodeList getNodeList(Object node, String xPath, NamespaceContext nsc)
	{
		XPathFactory factory = XPathFactory.newInstance();
		XPath xpath = factory.newXPath();
		xpath.setNamespaceContext(nsc);
		NodeList s = null;
		try {
			s = (NodeList)xpath.evaluate(xPath, node, XPathConstants.NODESET);
		} catch (XPathExpressionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
	}

	public static Document createDomDocument() {
		try {
			DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			Document doc = builder.newDocument();
			return doc;
		} catch (ParserConfigurationException e) {
		}
		return null;
	}

	public static Document getXMLDocfromString(String xmlString) {
		Document doc = null;
		DocumentBuilderFactory xmlFact = DocumentBuilderFactory
				.newInstance();
		xmlFact.setNamespaceAware(true);
		DocumentBuilder builder;
		try {
			builder = xmlFact.newDocumentBuilder();

			//forcing utf 8
			ByteArrayInputStream bais = new java.io.ByteArrayInputStream(xmlString.getBytes());
			Reader reader = new InputStreamReader(bais,"UTF-8");
			InputSource is = new InputSource(reader);
			is.setEncoding("UTF-8");
			//forcing utf 8

			doc = builder.parse(is);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return doc;
	}

	/**
	 * Extract the filtered set from the Doc by using the supplied xPath 
	 * @param doc
	 * @param xpathStr
	 * @return Filtered set in a NodeList
	 */
	public static NodeList getFilteredList(Document doc, String xpathStr) {

		XPathFactory xpathFact = XPathFactory.newInstance();
		XPath xpath = xpathFact.newXPath();
		NodeList nodeList = (NodeList)eval(doc, xpathStr, XPathConstants.NODESET, xpath);
		return nodeList;
	}

	/**
	 * Extract the filtered set from the Doc by using the supplied xPath 
	 * @param doc
	 * @param xpathStr
	 * @param nsc Name space context
	 * @return Filtered set in a NodeList
	 */
	public static NodeList getFilteredList(Document doc, String xpathStr, NamespaceContext nsc) {

		XPathFactory xpathFact = XPathFactory.newInstance();
		XPath xpath = xpathFact.newXPath();
		xpath.setNamespaceContext(nsc);
		NodeList nodeList = (NodeList)eval(doc, xpathStr, XPathConstants.NODESET, xpath);
		return nodeList;
	}

	/**
	 * Evaluate xPath expression against a Doc returning a nodelist
	 * @param doc
	 * @param expression
	 * @param returnType
	 * @param xPath
	 */
	public static Object eval(Object doc, String expression, QName returnType, XPath xPath) 
	{
		XPathExpression xPathExpression;
		try {
			xPathExpression = xPath.compile(expression);
			return xPathExpression.evaluate(doc, returnType);
		} catch (XPathExpressionException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Get the Namespace context for xPath evaluation against doc.
	 * Uses global variable NAMESPACE for the URI
	 * @return
	 */
	public static NamespaceContext getNSContext(String namespace) {
		NamespaceContext nsc = new NamespaceContext() {

			@Override
			public Iterator getPrefixes(String arg0) {
				return null;
			}

			@Override
			public String getPrefix(String arg0) {
				return null;
			}

			@Override
			public String getNamespaceURI(String arg0) {
				return arg0;
			}
		};
		return nsc;
	}

	/**
	 * Get xml string from a Document
	 * @param doc
	 * @return
	 */
	public static String getStringfromXMLDoc(Document doc) 
	{
		DOMSource domSource = new DOMSource(doc);
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = null;
		try {
			transformer = tf.newTransformer();
		} catch (TransformerConfigurationException e1) {
			e1.printStackTrace();
		}
		try {
			transformer.transform(domSource, result);
		} catch (TransformerException e) {
			e.printStackTrace();
		}
		return writer.toString();
	}
	
	/**
	 * Create a XML Document 
	 * @param rootName
	 * @param namespace
	 * @return Created XML document
	 */
	public static Document createDomDocument(String rootName, String namespace ) {
		try {
			DocumentBuilderFactory xmlFact = DocumentBuilderFactory.newInstance();
			xmlFact.setNamespaceAware(true);
			DocumentBuilder builder = xmlFact.newDocumentBuilder();
			DOMImplementation domImpl = builder.getDOMImplementation();
			return domImpl.createDocument(namespace, rootName, null);
		} catch (ParserConfigurationException e) {
		}
		return null;
	}
	
	/**
	 * Restricts the result set from the Nodelist items and adds the pagination elements
	 * @param doc
	 * @param pageNumber
	 * @param pageSize
	 * @param resultList
	 * @param URI
	 * @param includePagingElement
	 * @return FinalDoc
	 */
	public static Document paginate(Document doc,  int pageNumber, int pageSize, NodeList resultList, 
			String URI, boolean includePagingElement, String docNS, String atomNS, int totalLength) {
		int startIndex, lastIndex, totNumOfPages=0;
		//setup totNumPages

		totNumOfPages =  totalLength/pageSize;
		if (totalLength%pageSize>0){
			totNumOfPages = totNumOfPages + 1;
		}
		startIndex=0;
		lastIndex = resultList.getLength();

		//restrict results within boundary
		for (int i = startIndex; i < lastIndex; i++) {
			Node node = doc.importNode(resultList.item(i), true);
			doc.getDocumentElement().appendChild(node);
		}

		if (includePagingElement){
			//paging element
			Element pagingElement = doc.createElementNS(docNS, "Paging");

			pagingElement.setAttribute("pageNum", String.valueOf(pageNumber));
			pagingElement.setAttribute("pageSize", String.valueOf(pageSize));
			pagingElement.setAttribute("totalNumItems", String.valueOf(totalLength));
			pagingElement.setAttribute("pageCount", String.valueOf(totNumOfPages));

			if (totNumOfPages==0){
				totNumOfPages++;
			}

			String[] path = URI.toLowerCase().split("[?]");
			String[] queryParams = path[1].split("&");

			//first link
			createLinkElement(doc, pageSize, "first", buildPath(path[0], updateQueryParam("pagenum", 1, queryParams)), pagingElement, atomNS);

			if (pageNumber > 1 && pageNumber <=  totNumOfPages )
			{
				//prev link
				queryParams = updateQueryParam("pagenum", pageNumber-1, queryParams);
				createLinkElement(doc, pageSize, "prev", buildPath(path[0], updateQueryParam("pagenum", pageNumber-1, queryParams)), pagingElement, atomNS);
			}

			if (pageNumber < totNumOfPages)
			{
				//next link
				createLinkElement(doc, pageSize, "next", buildPath(path[0], updateQueryParam("pagenum", pageNumber+1, queryParams)), pagingElement, atomNS);
			}

			//last link
			createLinkElement(doc, pageSize, "last", buildPath(path[0], updateQueryParam("pagenum", totNumOfPages, queryParams)), pagingElement, atomNS);
			doc.getDocumentElement().appendChild(pagingElement);
		}
		return doc;
	}
	
	/**
	 * Update array containing the name key with a value
	 * @param name
	 * @param value
	 * @param queryParams
	 * @return Updated queryParams array if match found, else returns the same array
	 */
	private static String[] updateQueryParam(String name, int value, String[] queryParams) {
		for (int i = 0; i < queryParams.length; i++) {
			if (queryParams[i].contains(name)){
				queryParams[i] = name+"="+value;
				return queryParams;
			}
		}
		return queryParams;
	}
	
	/**
	 * Builds a path and attaches the query parameters
	 * @param path
	 * @param queryParams
	 * @return The full path after attaching the query vars
	 */
	private static String buildPath(String path, String[] queryParams) {
		String pathParams ="";
		for (int i = 0; i < queryParams.length; i++) {
			if (i==(queryParams.length-1)){
				pathParams += queryParams[i];
			}
			else {
				pathParams += queryParams[i] + "&";
			}
		}
		return path +"?"+ pathParams;
	}
	
	/**
	 * Creates a Link element (first, last, next, prev)
	 * @param doc
	 * @param pageSize
	 * @param rel
	 * @param URI
	 * @param pagingElement
	 */
	private static void createLinkElement(Document doc, int pageSize,String rel, String URI, Element pagingElement, String atomNS) {
		Element link = doc.createElementNS(atomNS, "atom:link");
		link.setAttribute("rel", rel);
		link.setAttribute("href", URI);
		pagingElement.appendChild(link);
	}
}

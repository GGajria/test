from datetime import datetime, date, time
messageContext.variables['clientIp'] = messageContext.variables['_flow.clientip']
messageContext.variables['requestUri'] = messageContext.variables['_flow.client.request.uriwithqueryparams']
messageContext.variables['activityId'] = messageContext.variables['_flow.client.request.header.X-Redbox-ActivityID']
messageContext.variables['dateTime'] = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S")
messageContext.variables['sourceURI'] = messageContext.variables['_flow.client.request.uriwithqueryparams']


#parse uri query params
uri = str()
uri = messageContext.variables['requestUri']
path = uri.lower().split("?")
queryParams = path[1].split("&")
queryParamsList = []
for param in queryParams:
    queryParamsList.append(param.split("="))
for qParam in queryParamsList:
    if qParam[0] == 'apikey':
        messageContext.variables['apiKey'] = qParam[1]
    if qParam[0] == 'products':
        messageContext.variables['productIds'] = qParam[1]
    if qParam[0] == 'pagenum':
        messageContext.variables['pageNumber'] = qParam[1]
    if qParam[0] == 'pagesize':
        messageContext.variables['pageSize'] = qParam[1]
    if qParam[0] == 'radius':
        messageContext.variables['radius'] = qParam[1]
    if qParam[0] == 'count':
        messageContext.variables['count'] = qParam[1]
    if qParam[0] == 'retailer':
        messageContext.variables['retailer'] = qParam[1]
    if qParam[0] == 'sortby':
        messageContext.variables['sortBy'] = qParam[1]
    if qParam[0] == 'sortdir':
        messageContext.variables['sortDir'] = qParam[1]
    

a = str()
a = messageContext.variables['requestUri']

if (a.upper().find("/LATLONG")>0):
    messageContext.variables['operName'] = "I5"
    messageContext.variables['lat']= messageContext.variables['_flow.msgvar.lat']
    messageContext.variables['long']= messageContext.variables['_flow.msgvar.long']
elif (a.upper().find("/POSTALCODE")>0):
    messageContext.variables['operName'] = "I6"
    messageContext.variables['zipCode']= messageContext.variables['_flow.msgvar.zipCode']
    
 #reset Nones to blanks
if (messageContext.variables['productIds'] == "None"):
    messageContext.variables['productIds'] = ""
if (messageContext.variables['pageNumber']== "None"):
    messageContext.variables['pageNumber'] = ""
if (messageContext.variables['pageSize']== "None"):
    messageContext.variables['pageSize'] = ""
if (messageContext.variables['radius'] == "None"):    
    messageContext.variables['radius'] = ""
if (messageContext.variables['count'] == "None"):    
    messageContext.variables['count'] = ""
if (messageContext.variables['retailer'] == "None"):    
    messageContext.variables['retailer'] = ""    
if (messageContext.variables['sortBy'] == "None"):    
    messageContext.variables['sortBy'] = ""
if (messageContext.variables['sortDir'] == "None"):    
    messageContext.variables['sortDir'] = ""    

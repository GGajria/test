package com.InventoryTransformation;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Map;
import java.util.logging.Logger;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.sonoa.services.messaging.component.primitive.javacallout.spi.JavaCalloutLogger;
import com.sonoa.services.messaging.component.primitive.javacallout.spi.JavaCalloutTask;
import com.sonoa.services.messaging.component.primitive.javacallout.spi.MessageContext;
import com.sonoa.services.messaging.component.primitive.javacallout.spi.MessagingException;


import pack.NamespaceResolver.NamespaceResolver;
import pack.XMLHelper.XMLHelper;

public class InventoryTransformationOld implements JavaCalloutTask {
	public static String ATOM = "http://www.w3.org/2005/Atom";
	public static String storesS3Endpoint = "http://50.18.22.174:1779/stores/latlong/";
	public static String storesS6Endpoint = "http://50.18.22.174:1779/stores/postalcode/";
	public static String invEndpoint = "http://50.18.22.174:1779/v3/inventory/stores/";
	public static String apiKey = "254c5d8786ffcd1d662a3418ffcf4f34";
	public static String InventoryNS = "http://api.redbox.com/v3/Inventory";
	
	JavaCalloutLogger logger;
	
	public static void main(String[] args) throws IOException{
		long start = System.currentTimeMillis();
		//collect values
		String sourceURI = "http://50.18.22.174:1779/v3/inventory/stores/latlong/38.9,76.8?products=&pageNum=1&pageSize=10&radius=50&count=10&retailer=&sortBy=banner&sortDir=ascending";
		double lat = 39.2;
		double lon = -94.6;
		String productIds = "";
		int pageNum = 1;
		int pageSize = 20;
		int radius = 50;
		int count = 10;
		String retailer = "";
		String sortBy = "";
		String sortDir = "";
		String operName = "I5";
		String zipCode = "32.9";
		
		//call stores with the passed in criteria
		///stores/latlong/{lat},{longt}?apiKey={key}&radius={r}&count={c}&retailer={ret}&sortBy={sB}&sortDir={asc/desc}&pageNum={pN}&pageSize={pS}	
		String storesURL="";
		if (operName=="I5"){
			storesURL = prepareS3URL(lat, lon, radius, count, retailer, sortBy, sortDir);
		}
		else if (operName=="I6") {
			storesURL = prepareS6URL(zipCode, radius, count, retailer, sortBy, sortDir);
		}
		System.out.println(storesURL);
		
		//get store
		String xmlString = getURL(storesURL);
		Document storesDoc =  XMLHelper.getXMLDocfromString(xmlString);
		NodeList storeList = XMLHelper.getNodeList(storesDoc, "/*/:Store", new NamespaceResolver(storesDoc));
		
		//loop thru to get inventory per store
		Document tempDoc = loopOut(productIds, storeList, pageNum, pageSize, null);
		
		Document finalDoc = XMLHelper.createDomDocument("Inventory", InventoryNS);
		finalDoc = XMLHelper.paginate(finalDoc, pageNum, pageSize,tempDoc.getDocumentElement().getChildNodes(),sourceURI, pageNum>0, InventoryNS, ATOM, storeList.getLength());

		System.out.println(XMLHelper.getStringfromXMLDoc(finalDoc));
		long stop = System.currentTimeMillis();
		System.out.println("Total for not changed: " + (stop-start));
		
	}

	private static Document loopOut(String productIds, NodeList storeList, int pageNumber, int pageSize, JavaCalloutLogger logger) {
		
		int startIndex, lastIndex;
		if (pageNumber>0){
			startIndex = (pageNumber - 1) * pageSize;
			lastIndex = startIndex + pageSize;
			if(lastIndex > storeList.getLength()){
				lastIndex = storeList.getLength();
			}
			if (startIndex > lastIndex){
				startIndex = lastIndex = 0;
			}
		}
		else{
			startIndex=0;
			lastIndex = storeList.getLength();
		}
		

		ArrayList<Node> invList = new ArrayList<Node>();
		for ( int i = startIndex; i < lastIndex; i++ ) {
			Node item = storeList.item(i);
			String invUrl = prepareInvURL( XMLHelper.getValue( item, "@storeId" ), productIds );
			
			System.out.println(invUrl);
			
			if (logger!=null){
				logger.debug("Calling :" + invUrl);
			}
			//call inventory / storeId extracted
			String invString = getURL( invUrl );
			if (logger!=null){
				logger.debug("Got response from :" + invUrl);
			}
			
			//System.out.println(invString);
			Document invDoc =  XMLHelper.getXMLDocfromString( invString );
			Node invNode = XMLHelper.getNode(invDoc, "/*/:StoreInventory" , new NamespaceResolver(invDoc));
			invList.add(invNode);
		}

		Document finalDoc = XMLHelper.createDomDocument("Inventory", InventoryNS);
		for (int i = 0; i < invList.size(); i++) {
			Node invNode = invList.get(i);
			invNode = finalDoc.importNode(invNode, true);
			finalDoc.getDocumentElement().appendChild(invNode);
		}
		return finalDoc;
	}

	private static String prepareInvURL(String storeId, String productIds) {
		String URL="";
		if (!productIds.isEmpty()) {
			URL+="&productIds="+productIds;
		}
		return invEndpoint  + storeId + "?apiKey=" + apiKey + URL;
	}

	private static String prepareS3URL(double lat, double lon, int radius, int count,
			String retailer, String sortBy, String sortDir) {
		String URL="";
		
		if (radius>0) {
			URL+="&radius="+radius;
		}
		
		if (count>0) {
			URL+="&count="+count;
		}
		
		if (!retailer.isEmpty()) {
			URL+="&retailer="+retailer;
		}
		
		if (!sortBy.isEmpty()) {
			URL+="&sortBy="+sortBy;
		}
		
		if (!sortDir.isEmpty()) {
			URL+="&sortDir="+sortDir;
		}
		
		return storesS3Endpoint  + lat + "," + lon + "?apiKey=" + apiKey + URL;
	}
	
	private static String prepareS6URL(String zipCode, int radius, int count,
			String retailer, String sortBy, String sortDir) {
		String URL="";
		
		if (radius>0) {
			URL+="&radius="+radius;
		}
		
		if (count>0) {
			URL+="&count="+count;
		}
		
		if (!retailer.isEmpty()) {
			URL+="&retailer="+retailer;
		}
		
		if (!sortBy.isEmpty()) {
			URL+="&sortBy="+sortBy;
		}
		
		if (!sortDir.isEmpty()) {
			URL+="&sortDir="+sortDir;
		}
		
		return storesS6Endpoint   + zipCode +  "?apiKey=" + apiKey + URL;
	}

	/**
	 * 
	 * @param url
	 * @return
	 */
	private static String getURL(String url) {
		BufferedReader reader = null;
		String out ="";
		try{
			HttpURLConnection conn = null;
			conn = (HttpURLConnection) new URL(url).openConnection();
			conn.setRequestMethod("GET");
			InputStream response = null;
			response = conn.getInputStream();
			reader = new BufferedReader(new InputStreamReader(response));
			for (String line; (line = reader.readLine()) != null;) {
				out += line;
			}
		} catch (Exception e) {
			out = e.getMessage();
		}
		finally {
			if (reader != null) try { reader.close(); } catch (IOException logOrIgnore) {}
		}
		return out;
	}

	
	
	@Override
	public void execute(MessageContext arg0, Map<String, Object> arg1)
			throws JavaCalloutException {
		// //collect values
		String sourceURI="";
		double lat = 0;
		double lon = 0;
		String productIds = "";
		int pageNum = 0;
		int pageSize = 10;
		int radius = 50;
		int count = 100;
		String retailer = "";
		String sortBy = "";
		String sortDir = "";
		String operName="";
		String zipCode = "";
		try {
			logger = arg0.getLogger();
			sourceURI = arg0.getFlowVariableAsString("sourceURI");
			operName = arg0.getFlowVariableAsString("operName");
			
			logger.debug("Classified as " + operName);
			logger.debug("PageNumber " + pageNum);
			
			if (!arg0.getFlowVariableAsString("pageNumber").isEmpty()){
				pageNum = Integer.parseInt(arg0.getFlowVariableAsString("pageNumber"));
			}
			
			if (!arg0.getFlowVariableAsString("lat").isEmpty()){
				lat = Double.parseDouble(arg0.getFlowVariableAsString("lat"));
			}

			if (!arg0.getFlowVariableAsString("long").isEmpty()){
				lon = Double.parseDouble(arg0.getFlowVariableAsString("long"));
			}
			if (!arg0.getFlowVariableAsString("zipCode").isEmpty()){
				zipCode = arg0.getFlowVariableAsString("zipCode");
			}
			if (!arg0.getFlowVariableAsString("productIds").isEmpty()){
				productIds = arg0.getFlowVariableAsString("productIds");
			}

			if (!arg0.getFlowVariableAsString("pageSize").isEmpty()){
				pageSize = Integer.parseInt(arg0.getFlowVariableAsString("pageSize"));
			}
			if (!arg0.getFlowVariableAsString("radius").isEmpty()){
				radius = Integer.parseInt(arg0.getFlowVariableAsString("radius"));
			}
			if (!arg0.getFlowVariableAsString("count").isEmpty()){
				count = Integer.parseInt(arg0.getFlowVariableAsString("count"));
			}
			if (!arg0.getFlowVariableAsString("retailer").isEmpty()){
				retailer = arg0.getFlowVariableAsString("retailer");
			}
			if (!arg0.getFlowVariableAsString("sortBy").isEmpty()){
				sortBy = arg0.getFlowVariableAsString("sortBy");
			}
			
			if (!arg0.getFlowVariableAsString("sortDir").isEmpty()){
				sortDir = arg0.getFlowVariableAsString("sortDir");
			}
			
		} catch (MessagingException e) {
			logger.debug("Failed to collect params");
			e.printStackTrace();
		}

		//call stores with the passed in criteria
		///stores/latlong/{lat},{longt}?apiKey={key}&radius={r}&count={c}&retailer={ret}&sortBy={sB}&sortDir={asc/desc}&pageNum={pN}&pageSize={pS}	
		logger.debug("preparing stores URL");
		String storesURL="";
		if (operName=="I5"){
			storesURL = prepareS3URL(lat, lon, radius, count, retailer, sortBy, sortDir);
		}
		else if (operName=="I6") {
			storesURL = prepareS6URL(zipCode, radius, count, retailer, sortBy, sortDir);
		}
		
		logger.debug("Calling : " + storesURL);
		
		//get store
		String xmlString = getURL(storesURL);
		logger.debug("Got response from : " + storesURL);
		Document storesDoc =  XMLHelper.getXMLDocfromString(xmlString);
		NodeList storeList = XMLHelper.getNodeList(storesDoc, "/*/:Store", new NamespaceResolver(storesDoc));
		
		//loop thru to get inventory per store
		Document tempDoc = loopOut(productIds, storeList, pageNum, pageSize, logger);
		logger.debug("Done looping thru inventory endpoint");
		
		Document finalDoc = XMLHelper.createDomDocument("Inventory", InventoryNS);
		
		finalDoc = XMLHelper.paginate(finalDoc, pageNum, pageSize,tempDoc.getDocumentElement().getChildNodes(),
				sourceURI, pageNum>0, InventoryNS, ATOM, storeList.getLength());
		logger.debug("Done Paging");
		try {
			arg0.getMessageContentAccessor().setContent(XMLHelper.getStringfromXMLDoc(finalDoc));
		} catch (MessagingException e) {
			logger.debug("failed to set content");
			e.printStackTrace();
		}
		
	}

	@Override
	public boolean isBlockingTask() {
		// TODO Auto-generated method stub
		return true;
	}


}
